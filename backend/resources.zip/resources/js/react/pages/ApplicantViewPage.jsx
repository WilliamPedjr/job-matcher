import React from 'react'
import { useEffect, useState } from "react"
import "../styles/ApplicantViewPage.css"

function parseSkills(skillsText) {
  const value = Array.isArray(skillsText)
    ? skillsText.join(",")
    : typeof skillsText === "string"
      ? skillsText
      : skillsText == null
        ? ""
        : String(skillsText)

  const normalized = value.trim()
  if (!normalized) return []

  if (normalized.startsWith("[") && normalized.endsWith("]")) {
    try {
      const parsed = JSON.parse(normalized)
      if (Array.isArray(parsed)) {
        return parsed.map((s) => String(s).trim()).filter(Boolean)
      }
    } catch {
      // Fall through to delimiter parsing.
    }
  }

  return normalized
    .split(/[,;\n|]+/)
    .map((s) => s.trim())
    .filter(Boolean)
}

function parseMissingSkills(skillsText) {
  const value = Array.isArray(skillsText)
    ? skillsText.join(",")
    : typeof skillsText === "string"
      ? skillsText
      : skillsText == null
        ? ""
        : String(skillsText)

  const normalized = value.trim()
  if (!normalized) return []

  if (normalized.startsWith("[") && normalized.endsWith("]")) {
    try {
      const parsed = JSON.parse(normalized)
      if (Array.isArray(parsed)) {
        return parsed.map((s) => String(s).trim()).filter(Boolean)
      }
    } catch {
      // Fall through to delimiter parsing.
    }
  }

  return normalized
    .split(/[,;\n|]+/)
    .map((s) => s.trim())
    .filter(Boolean)
}

function extractEducationLines(text) {
  const source = (text || "").replace(/\r/g, "\n")
  const lines = source
    .split(/\n+/)
    .map((line) => line.trim())
    .filter(Boolean)

  const directMatches = lines
    .filter((line) => /(university|college|school|institute|academy)/i.test(line))
    .slice(0, 6)

  if (directMatches.length) {
    return directMatches
  }

  const compact = source.replace(/\s+/g, " ").trim()
  const chunks = compact
    .split(/(?=\b(?:elementary|high school|college|university|institute|academy|bachelor|master|phd|associate)\b)/i)
    .map((chunk) => chunk.trim())
    .filter((chunk) => /(school|college|university|institute|academy|bachelor|master|phd|associate)/i.test(chunk))
    .map((chunk) => chunk.replace(/\s*(work history|experience|skills|summary)\b.*/i, "").trim())
    .filter(Boolean)

  return Array.from(new Set(chunks)).slice(0, 6)
}

function extractExperienceLines(text) {
  const source = (text || "").replace(/\r/g, "\n")
  const lines = source
    .split(/\n+/)
    .map((line) => line.trim())
    .filter(Boolean)

  const experienceHeaderPattern = /^(work\s+experience|professional\s+experience|employment|employment\s+history|work\s+history|experience)\s*:?\s*$/i
  const stopHeaderPattern = /^(education|skills?|projects?|certifications?|summary|profile|references)\s*:?\s*$/i
  const dateRangePattern = /\b(?:(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\s+\d{4}|\d{4})\s*(?:-|–|to)\s*(?:present|current|now|(?:(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\s+\d{4}|\d{4}))\b/i
  const titlePattern = /\b(?:software|frontend|front-end|backend|full[-\s]?stack|web|mobile|qa|test|data|product|project|systems?)?\s*(?:engineer|developer|analyst|manager|lead|specialist|consultant|intern|assistant|architect|administrator|officer|designer)\b/i
  const companyPattern = /\b(?:at|with)\s+[A-Z][A-Za-z0-9&.,\- ]{1,80}\b|\b[A-Z][A-Za-z0-9&.,\- ]+\s(?:inc\.?|corp\.?|llc|ltd)\b/i
  const yearsPattern = /\d+\+?\s*years?/i
  const bulletActionPattern = /^(created|developed|implemented|designed|optimized|built|improved|maintained|led|managed|automated|deployed|integrated)\b/i

  const sectionLines = []
  let inExperienceSection = false
  for (const line of lines) {
    if (experienceHeaderPattern.test(line)) {
      inExperienceSection = true
      continue
    }
    if (stopHeaderPattern.test(line)) {
      inExperienceSection = false
      continue
    }
    if (inExperienceSection) {
      sectionLines.push(line)
    }
  }

  const pool = sectionLines.length ? sectionLines : lines
  const results = []
  const seen = new Set()

  for (let i = 0; i < pool.length; i += 1) {
    const line = pool[i]
    const isAnchor = dateRangePattern.test(line) || titlePattern.test(line) || companyPattern.test(line) || yearsPattern.test(line)
    if (!isAnchor || line.length < 8) continue

    let entry = line
    const next = pool[i + 1]
    if (next && bulletActionPattern.test(next) && next.length > 12) {
      entry = `${entry} | ${next}`
      i += 1
    }

    const normalized = entry.toLowerCase()
    if (!seen.has(normalized)) {
      seen.add(normalized)
      results.push(entry)
    }
    if (results.length >= 8) break
  }

  return results
}

function normalizeLines(value) {
  if (Array.isArray(value)) {
    return value.map((item) => String(item || "").trim()).filter(Boolean)
  }

  const text = String(value || "").replace(/\r/g, "\n").trim()
  if (!text) return []

  return text
    .split(/\n+/)
    .map((line) => line.trim())
    .filter(Boolean)
}

function scoreValue(...values) {
  for (const value of values) {
    if (value == null || value === "") continue
    const number = Number(value)
    if (!Number.isNaN(number)) {
      return Math.max(0, Math.min(100, Math.round(number)))
    }
  }

  return null
}

function groupCandidateDetailLines(lines, type = "default") {
  const groups = []
  const normalizedLines = Array.isArray(lines) ? lines.map((line) => String(line || "").trim()).filter(Boolean) : []
  if (type === "training") {
    normalizedLines.forEach((line) => {
      const startsTrainingRecord = /^training\b/i.test(line)
      if (startsTrainingRecord || groups.length === 0) {
        groups.push([line])
        return
      }
      groups[groups.length - 1].push(line)
    })

    return groups
  }

  const detailPattern = type === "education"
    ? /^(graduation status rank|year graduated|academic honors|awards received)\b/i
    : /^(government service|monthly gross salary|monthly salary|salary|status of appointment|supervisor|reason for leaving|appointment|job grade|coe file)\b/i

  normalizedLines.forEach((line) => {
    const shouldAttach = groups.length > 0 && detailPattern.test(line)
    if (shouldAttach) {
      groups[groups.length - 1].push(line)
      return
    }
    groups.push([line])
  })

  return groups
}

function normalizeFileName(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ")
}

function findSupportingFileForLine(line, files) {
  const text = String(line || "")
  const labeledMatch = text.match(/\b((?:coe|certificate)\s+file):\s*(.+)$/i)
  const fallbackFileName = text.split("|").map((part) => part.trim()).filter(Boolean).pop()
  const fileName = normalizeFileName(labeledMatch ? labeledMatch[2] : fallbackFileName)
  if (!fileName) return null

  return (Array.isArray(files) ? files : []).find((file) => {
    const originalName = normalizeFileName(file?.original_name || file?.originalName || file?.name)
    return originalName === fileName
  }) || null
}

function ApplicantViewPage({
  viewItem,
  onBack,
  onReanalyze,
  readOnly = false,
  backLabel,
  headerActions = null
}) {
  const classificationLabel = (value, fallback = "Not Qualified") => {
    const label = String(value || "").trim()
    if (!label) return fallback
    return label.toLowerCase().includes("lowly") ? "Not Qualified" : label
  }

  const [supportingFiles, setSupportingFiles] = useState([])
  const [supportingError, setSupportingError] = useState("")
  const educationSource = normalizeLines(viewItem?.education_json)
  const experienceSource = normalizeLines(viewItem?.experience_json)
  const detectedEducation = educationSource.length
    ? educationSource
    : normalizeLines(viewItem?.education_text).length
      ? normalizeLines(viewItem?.education_text)
      : extractEducationLines(viewItem?.extracted_text)
  const detectedExperience = experienceSource.length ? experienceSource : extractExperienceLines(viewItem?.experience_text || viewItem?.extracted_text)
  const matchedSkills = parseSkills(viewItem?.matched_skills ?? viewItem?.matchedSkills)
  const missingSkills = parseMissingSkills(viewItem?.missing_skills ?? viewItem?.missingSkills)
  const matchedTraining = parseSkills(viewItem?.matched_training ?? viewItem?.matchedTraining)
  const missingTraining = parseMissingSkills(viewItem?.missing_training ?? viewItem?.missingTraining)
  const eligibilityLines = Array.isArray(viewItem?.eligibility_lines)
    ? viewItem.eligibility_lines
    : Array.isArray(viewItem?.eligibilityLines)
      ? viewItem.eligibilityLines
      : []
  const eligibilityFiles = Array.isArray(viewItem?.eligibility_files)
    ? viewItem.eligibility_files
    : Array.isArray(viewItem?.eligibilityFiles)
      ? viewItem.eligibilityFiles
      : []
  const trainingGroups = groupCandidateDetailLines(matchedTraining, "training")
  const educationGroups = groupCandidateDetailLines(detectedEducation, "education")
  const experienceGroups = groupCandidateDetailLines(detectedExperience, "experience")
  const eligibilityGroups = groupCandidateDetailLines(eligibilityLines)
  const overall = viewItem?.match_score != null ? Number(viewItem.match_score) : 0
  const totalSkillRequirements = matchedSkills.length + missingSkills.length
  const fallbackSkillsMatch = totalSkillRequirements > 0
    ? Math.round((matchedSkills.length / totalSkillRequirements) * 100)
    : 0
  const resolvedSkillsMatch = totalSkillRequirements > 0
    ? fallbackSkillsMatch
    : scoreValue(viewItem?.skills_match_score, viewItem?.skillsMatchScore, fallbackSkillsMatch)
  const totalTrainingRequirements = matchedTraining.length + missingTraining.length
  const fallbackTrainingMatch = totalTrainingRequirements > 0
    ? Math.round((matchedTraining.length / totalTrainingRequirements) * 100)
    : 0
  const skillsMatch = resolvedSkillsMatch ?? 0
  const trainingMatch = scoreValue(viewItem?.training_match_score, viewItem?.trainingMatchScore, viewItem?.project_score, fallbackTrainingMatch) ?? 0
  const educationMatch = scoreValue(viewItem?.education_match_score, viewItem?.educationMatchScore, detectedEducation.length ? 60 : 10) ?? 0
  const experienceMatch = scoreValue(viewItem?.experience_match_score, viewItem?.experienceMatchScore, detectedExperience.length ? 55 : 0) ?? 0
  const eligibilityMatch = scoreValue(
    viewItem?.eligibility_match_score,
    viewItem?.eligibilityMatchScore,
    viewItem?.resume_summary?.score_breakdown?.eligibility
  )
  const renderCandidateDetailLine = (line) => {
    const file = findSupportingFileForLine(line, [...supportingFiles, ...eligibilityFiles])
    if (!file?.id || !viewItem?.id) return line

    const match = String(line || "").match(/\b((?:coe|certificate)\s+file):\s*(.+)$/i)
    if (!match) {
      const parts = String(line || "").split("|").map((part) => part.trim()).filter(Boolean)
      const fileName = parts.pop()
      if (!fileName) return line

      return (
        <>
          {parts.length ? `${parts.join(" | ")} | ` : ""}
          <a
            className="candidate-file-link"
            href={file.preview_url || `/api/uploads/${viewItem.id}/supporting/${file.id}/preview`}
            target="_blank"
            rel="noreferrer"
          >
            {fileName}
          </a>
        </>
      )
    }

    const label = match[1]
    const fileName = match[2].trim()
    const prefix = String(line).slice(0, match.index)

    return (
      <>
        {prefix}{label}:{" "}
        <a
          className="candidate-file-link"
          href={file.preview_url || `/api/uploads/${viewItem.id}/supporting/${file.id}/preview`}
          target="_blank"
          rel="noreferrer"
        >
          {fileName}
        </a>
      </>
    )
  }

  useEffect(() => {
    if (!viewItem?.id) return
    let isMounted = true
    const fetchSupporting = async () => {
      try {
        setSupportingError("")
        const response = await fetch(`http://localhost:5000/uploads/${viewItem.id}/supporting`)
        if (!response.ok) {
          throw new Error("Failed to load supporting documents.")
        }
        const payload = await response.json()
        if (!isMounted) return
        setSupportingFiles(Array.isArray(payload?.files) ? payload.files : [])
      } catch (error) {
        if (!isMounted) return
        setSupportingError(error.message || "Failed to load supporting documents.")
        setSupportingFiles([])
      }
    }
    fetchSupporting()
    return () => {
      isMounted = false
    }
  }, [viewItem?.id])

  return (
    <section className="candidate-page">
      <div className="candidate-head">
        <div>
          <h2 className="candidate-name">{viewItem?.name || "(No name)"}</h2>
          <p className="candidate-role">
            Applied for <strong>{viewItem?.applied_job_title || viewItem?.matched_job_title || "No matched role yet"}</strong>
          </p>
        </div>
        {(onBack || (!readOnly && onReanalyze) || headerActions) && (
          <div className="candidate-actions">
            {onBack && (
              <button className="btn btn-secondary" onClick={onBack}>
                {backLabel || (readOnly ? "Back" : "Back to Applications")}
              </button>
            )}
            {!readOnly && onReanalyze && (
              <button className="btn btn-secondary" onClick={onReanalyze}>Re-Analyze</button>
            )}
            {headerActions}
          </div>
        )}
      </div>

      <div className="candidate-layout">
        <div className="candidate-left">
          <section className="candidate-card">
            <h3>Contact Information</h3>
            <p>ID Number: {viewItem?.idNumber || viewItem?.id_number || viewItem?.jobSeekerIdNumber || viewItem?.job_seeker_id_number || "-"}</p>
            <p>{viewItem?.email || "No email"}</p>
            <p>{viewItem?.phone || "No phone"}</p>
            <p>
              {viewItem?.original_name ? (
                <a
                  className="supporting-doc-link"
                  href={viewItem?.preview_url || `/api/uploads/${viewItem.id}/preview`}
                  target="_blank"
                  rel="noreferrer"
                >
                  {viewItem.original_name}
                </a>
              ) : (
                "-"
              )}
            </p>
          </section>

          <section className="candidate-card">
            <h3>Supporting Documents</h3>
            {supportingError && <p className="muted">{supportingError}</p>}
            {!supportingError && supportingFiles.length === 0 && (
              <p className="muted">No supporting documents uploaded.</p>
            )}
            {supportingFiles.length > 0 && (
              <ul className="supporting-docs-list">
                {supportingFiles.map((file) => (
                  <li key={file.id}>
                    <a
                      className="supporting-doc-link"
                      href={file.preview_url || `/api/uploads/${viewItem.id}/supporting/${file.id}/preview`}
                      target="_blank"
                      rel="noreferrer"
                    >
                      {file.original_name || "Supporting document"}
                    </a>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="candidate-card">
            <h3>Skills</h3>
            <p className="card-note">Matched against role skill requirements</p>
            <div className="skills-cloud">
              {matchedSkills.length ? (
                matchedSkills.map((item) => (
                  <span key={item} className="skill-pill">{item}</span>
                ))
              ) : (
                <span className="muted">No matched skills found.</span>
              )}
            </div>
          </section>

          <section className="candidate-card">
            <h3>Work Experience</h3>
            {experienceGroups.length ? (
              experienceGroups.map((group, idx) => (
                <div key={`${group.join("|")}-${idx}`} className="candidate-detail-group">
                  {group.map((line, lineIdx) => (
                    <p key={`${line}-${lineIdx}`} className="candidate-detail-line">{renderCandidateDetailLine(line)}</p>
                  ))}
                </div>
              ))
            ) : (
              <p className="muted">No clear work experience extracted.</p>
            )}
          </section>

          <section className="candidate-card">
            <h3>Education</h3>
            {educationGroups.length ? (
              educationGroups.map((group, idx) => (
                <div key={`${group.join("|")}-${idx}`} className="candidate-detail-group">
                  {group.map((line, lineIdx) => (
                    <p key={`${line}-${lineIdx}`} className="candidate-detail-line">{renderCandidateDetailLine(line)}</p>
                  ))}
                </div>
              ))
            ) : (
              <p className="muted">No education data extracted.</p>
            )}
          </section>

          <section className="candidate-card">
            <h3>Eligibility</h3>
            {eligibilityGroups.length ? (
              eligibilityGroups.map((group, idx) => (
                <div key={`${group.join("|")}-${idx}`} className="candidate-detail-group">
                  {group.map((line, lineIdx) => (
                    <p key={`${line}-${lineIdx}`} className="candidate-detail-line">{renderCandidateDetailLine(line)}</p>
                  ))}
                </div>
              ))
            ) : (
              <p className="muted">No eligibility document found.</p>
            )}
          </section>

          <section className="candidate-card">
            <h3>Training Evidence</h3>
            {trainingGroups.length ? (
              trainingGroups.map((group, idx) => (
                <div key={`${group.join("|")}-${idx}`} className="candidate-detail-group">
                  {group.map((line, lineIdx) => (
                    <p key={`${line}-${lineIdx}`} className="candidate-detail-line">{renderCandidateDetailLine(line)}</p>
                  ))}
                </div>
              ))
            ) : (
              <p className="muted">No matching training evidence found.</p>
            )}
          </section>

        </div>

        <div className="candidate-right">
          <section className="candidate-card">
            <h3>Qualification Status</h3>
            <p className={`status-chip ${(viewItem?.classification || "").toLowerCase().replace(/\s+/g, "-")}`}>
              {classificationLabel(viewItem?.classification)}
            </p>
            <div className="overall-box">
              <p className="overall-score">{`${overall.toFixed(0)}%`}</p>
              <p>Overall Match Score</p>
            </div>
          </section>

          <section className="candidate-card">
            <h3>Match Score Breakdown</h3>
            <div className="breakdown-list">
              <div className="bar-row">
                <div className="bar-label"><span>Skills Match</span><strong>{skillsMatch}%</strong></div>
                <div className="bar"><div style={{ width: `${skillsMatch}%` }} /></div>
              </div>
              <div className="bar-row">
                <div className="bar-label"><span>Training Match</span><strong>{trainingMatch}%</strong></div>
                <div className="bar"><div style={{ width: `${trainingMatch}%` }} /></div>
              </div>
              <div className="bar-row">
                <div className="bar-label"><span>Education Match</span><strong>{educationMatch}%</strong></div>
                <div className="bar"><div style={{ width: `${educationMatch}%` }} /></div>
              </div>
              <div className="bar-row">
                <div className="bar-label"><span>Experience Match</span><strong>{experienceMatch}%</strong></div>
                <div className="bar"><div style={{ width: `${experienceMatch}%` }} /></div>
              </div>
              {eligibilityMatch != null && (
                <div className="bar-row">
                  <div className="bar-label"><span>Eligibility Match</span><strong>{eligibilityMatch}%</strong></div>
                  <div className="bar"><div style={{ width: `${eligibilityMatch}%` }} /></div>
                </div>
              )}
            </div>
          </section>

          <section className="candidate-card">
            <h3>Missing Skills</h3>
            {missingSkills.length ? (
              <div className="skills-cloud">
                {missingSkills.map((item) => (
                  <span key={`missing-skill-${item}`} className="skill-pill">{item}</span>
                ))}
              </div>
            ) : (
              <p className="muted">No missing skill requirement detected.</p>
            )}
          </section>

          <section className="candidate-card">
            <h3>Missing Training</h3>
            {missingTraining.length ? (
              <div className="skills-cloud">
                {missingTraining.map((item) => (
                  <span key={`missing-${item}`} className="skill-pill">{item}</span>
                ))}
              </div>
            ) : (
              <p className="muted">No missing training requirement detected.</p>
            )}
          </section>
        </div>
      </div>
    </section>
  )
}

export default ApplicantViewPage
