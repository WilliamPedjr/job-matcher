import React, { useEffect, useMemo, useRef, useState } from 'react'
import '../styles/RatingsPage.css'
import ApplicantViewPage from './ApplicantViewPage'
import CustomDropdown from '../components/CustomDropdown'
import { getArchiveActorHeaders } from '../utils/archiveActor'

function formatInterviewDate(value) {
  if (!value) return '-'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) {
    return '-'
  }
  return date.toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' })
}

function getInterviewDateValue(item) {
  return item?.interview_date || item?.interviewDate || item?.evaluation_started_at || item?.evaluationStartedAt || item?.uploaded_at || item?.updated_at || item?.updatedAt
}

function getScheduledInterviewDateValue(item) {
  return item?.interview_date || item?.interviewDate
}

function getInterviewPlaceValue(item) {
  return item?.interview_place || item?.interviewPlace || ''
}

function getInterviewTimeValue(item) {
  return item?.interview_time || item?.interviewTime || ''
}

function getInterviewPreparationNotesValue(item) {
  return item?.interview_preparation_notes || item?.interviewPreparationNotes || ''
}

function getDemonstrationDateValue(item) {
  return item?.demonstration_date || item?.demonstrationDate
}

function getDemonstrationTimeValue(item) {
  return item?.demonstration_time || item?.demonstrationTime || ''
}

function getDemonstrationPlaceValue(item) {
  return item?.demonstration_place || item?.demonstrationPlace || ''
}

function getDemonstrationPreparationNotesValue(item) {
  return item?.demonstration_preparation_notes || item?.demonstrationPreparationNotes || ''
}

function getExaminationDateValue(item) {
  return item?.examination_date || item?.examinationDate
}

function getExaminationScoreLabel(item) {
  const score = item?.examination_score ?? item?.examinationScore
  if (score === null || score === undefined || score === '') return '-'
  const numericScore = Number(score)
  if (Number.isNaN(numericScore)) return '-'
  return `${numericScore.toFixed(Number.isInteger(numericScore) ? 0 : 2)}%`
}

function formatDateInputValue(value) {
  if (!value) return ''
  if (/^\d{4}-\d{2}-\d{2}$/.test(String(value))) return String(value)
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return ''
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}

function formatTimeLabel(value) {
  if (!value) return '-'
  const normalized = String(value).slice(0, 5)
  const [hourText, minuteText] = normalized.split(':')
  const hour = Number(hourText)
  const minute = Number(minuteText)
  if (Number.isNaN(hour) || Number.isNaN(minute)) return '-'
  const date = new Date()
  date.setHours(hour, minute, 0, 0)
  return date.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })
}

function getPosition(item) {
  return item.applied_job_title || item.appliedJobTitle || item.matched_job_title || 'No position selected'
}

function getEvaluationStatus(item) {
  return String(item?.evaluation_status || item?.evaluationStatus || '').toLowerCase()
}

function getEvaluationStatusLabel(item) {
  const status = getEvaluationStatus(item)
  if (status === 'hired' || status === 'rated') return 'Hired'
  if (status === 'interview' || status === 'for_evaluation') return 'Interview'
  return 'Shortlisted'
}

function buildApplicantEmailDraft(item, senderEmail = '') {
  const email = String(item?.email || '').trim().replace(/[\s<>()[\]\\,;:"]+/g, '')
  if (!email) return null
  const sender = String(senderEmail || '').trim()

  const applicantName = String(item?.name || '').trim()
  const jobTitle = getPosition(item)
  const subject = jobTitle && jobTitle !== 'No position selected'
    ? `Regarding your application for ${jobTitle}`
    : 'Regarding your job application'
  const greeting = applicantName ? `Hello ${applicantName},` : 'Hello,'
  const body = `${greeting}\n\nWe are contacting you about your application${jobTitle && jobTitle !== 'No position selected' ? ` for ${jobTitle}` : ''}.\n\nThank you,\nLNU-HiRe Personnel`

  return {
    email,
    gmail: `https://mail.google.com/mail/?view=cm&fs=1${sender ? `&authuser=${encodeURIComponent(sender)}` : ''}&to=${encodeURIComponent(email)}&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`,
    mailto: `mailto:${email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
  }
}

const defaultRatingCriteria = [
  'Appearance and Grooming',
  'Technical Knowledge and Mastery',
  'Confidence and Composure',
  'Job Knowledge and Competence',
  'Critical Thinking and Problem Solving',
  'Attitude and Professionalism',
  'Interpersonal Skills',
  'Adaptability and Flexibility',
  'Motivation and Interest in the Position',
  'Overall Interview Performance'
]

const ratingCriteriaStorageKey = 'ratingsCriteria'
const boardMembersStorageKey = 'ratingsBoardMembers'
const applicantsPageSize = 10

function loadRatingCriteria() {
  if (typeof window === 'undefined') return defaultRatingCriteria
  try {
    const stored = window.localStorage.getItem(ratingCriteriaStorageKey)
    const parsed = stored ? JSON.parse(stored) : null
    if (Array.isArray(parsed) && parsed.length === defaultRatingCriteria.length) {
      const cleaned = parsed.map((item) => String(item || '').trim())
      if (cleaned.every(Boolean)) return cleaned
    }
  } catch {
    // Use defaults when local storage is unavailable or invalid.
  }
  return defaultRatingCriteria
}

function loadBoardMembers() {
  if (typeof window === 'undefined') return []
  try {
    const stored = window.localStorage.getItem(boardMembersStorageKey)
    const parsed = stored ? JSON.parse(stored) : null
    if (Array.isArray(parsed)) {
      return Array.from(new Set(parsed.map((item) => String(item || '').trim()).filter(Boolean)))
    }
  } catch {
    // Use an empty list when local storage is unavailable or invalid.
  }
  return []
}

const ratingBands = [
  { label: 'Outstanding', range: '41 - 50', value: 5 },
  { label: 'Very Satisfactory', range: '31 - 40', value: 4 },
  { label: 'Satisfactory', range: '21 - 30', value: 3 },
  { label: 'Below Satisfactory', range: '11 - 20', value: 2 },
  { label: 'Unsatisfactory', range: '10 & below', value: 1 }
]

const demonstrationSections = [
  {
    key: 'teacher',
    label: 'A. Teacher',
    criteria: [
      'Mastery of Subject',
      'Organization of Lesson',
      'Class Management',
      'Methods and Techniques',
      'Personality / Grooming',
      'Awareness of Current Issues',
      'Promotion of desirable value habits',
      'Communication Skills',
      'Use of instructional materials'
    ]
  },
  {
    key: 'student',
    label: 'B. Student',
    criteria: [
      'Student-teacher interaction',
      'Preparedness',
      'Communication skills',
      'Awareness of current issues'
    ]
  },
  {
    key: 'learning-environment',
    label: 'C. Learning Environment',
    criteria: [
      'Free from distraction',
      'Ventilation',
      'Lighting',
      'Adequacy of facilities',
      'Housekeeping (orderliness & cleanliness)'
    ]
  }
]

const demonstrationRatingColumns = [
  ...ratingBands.map((band) => ({
    label: band.label,
    range: band.range,
    value: band.value
  })),
  { label: 'Not Applicable', range: 'NA', value: 'NA' }
]

const demonstrationDetailDefaults = {
  teacher: '',
  subject: '',
  building: '',
  matterLesson: '',
  date: '',
  time: '',
  room: '',
  observer: ''
}

const boardTypeOptions = [
  { value: 'personnel-selection-board', label: 'Personnel Selection Board' },
  { value: 'faculty-selection-board', label: 'Faculty Selection Board' }
]

function getDefaultBoardType(currentUser) {
  const role = String(currentUser?.role || '').trim().toLowerCase()
  return role === 'faculty' ? 'faculty-selection-board' : 'personnel-selection-board'
}

function getBoardTypeLabel(value) {
  return boardTypeOptions.find((option) => option.value === value)?.label || 'Personnel Selection Board'
}

function getDemonstrationCriterionKey(sectionKey, criterion) {
  return `${sectionKey}: ${criterion}`
}

function getDemonstrationDescription(mean) {
  if (!mean) return '-'
  if (mean >= 4.5) return 'Outstanding'
  if (mean >= 3.5) return 'Very Good'
  if (mean >= 2.5) return 'Good'
  if (mean >= 1.5) return 'Fair'
  return 'Poor'
}

function getSavedRatingFormType(rating) {
  const formType = String(rating?.formType || rating?.form_type || '').toLowerCase()
  if (formType === 'demonstration') return 'demonstration'
  if (formType === 'interview') return 'interview'

  const remarks = String(rating?.remarks || '').toLowerCase()
  const scoreKeys = Object.keys(rating?.scores || {})
  if (remarks.includes('applicant demonstration form') || scoreKeys.some((key) => key.includes(': '))) {
    return 'demonstration'
  }
  return 'interview'
}

function RatingsPage({ uploads = [], isLoading = false, currentUser = null, onRatingsChanged }) {
  const [searchTerm, setSearchTerm] = useState('')
  const [positionFilter, setPositionFilter] = useState('all')
  const [criteriaEditorOpen, setCriteriaEditorOpen] = useState(false)
  const [ratingCriteria, setRatingCriteria] = useState(loadRatingCriteria)
  const [criteriaDraft, setCriteriaDraft] = useState(() => loadRatingCriteria())
  const [boardMembers, setBoardMembers] = useState(loadBoardMembers)
  const [boardMembersDraft, setBoardMembersDraft] = useState(() => loadBoardMembers())
  const [boardMembersPage, setBoardMembersPage] = useState(1)
  const [applicantsPage, setApplicantsPage] = useState(1)
  const [selectedApplicant, setSelectedApplicant] = useState(null)
  const [ratingStarted, setRatingStarted] = useState(false)
  const [ratingFormType, setRatingFormType] = useState('interview')
  const [ratingScores, setRatingScores] = useState({})
  const [demonstrationDetails, setDemonstrationDetails] = useState(demonstrationDetailDefaults)
  const [ratingRemarks, setRatingRemarks] = useState('')
  const [actionsMenu, setActionsMenu] = useState(null)
  const [confirmRatingAction, setConfirmRatingAction] = useState(null)
  const [confirmSaveRating, setConfirmSaveRating] = useState(false)
  const [confirmSaveCriteria, setConfirmSaveCriteria] = useState(false)
  const [confirmDeleteBoardMember, setConfirmDeleteBoardMember] = useState(null)
  const [interviewDateModal, setInterviewDateModal] = useState(null)
  const [interviewDateDraft, setInterviewDateDraft] = useState('')
  const [interviewPlaceDraft, setInterviewPlaceDraft] = useState('')
  const [interviewTimeDraft, setInterviewTimeDraft] = useState('')
  const [interviewPreparationNotesDraft, setInterviewPreparationNotesDraft] = useState('')
  const [isSavingInterviewDate, setIsSavingInterviewDate] = useState(false)
  const [demonstrationDateModal, setDemonstrationDateModal] = useState(null)
  const [demonstrationDateDraft, setDemonstrationDateDraft] = useState('')
  const [demonstrationTimeDraft, setDemonstrationTimeDraft] = useState('')
  const [demonstrationPlaceDraft, setDemonstrationPlaceDraft] = useState('')
  const [demonstrationPreparationNotesDraft, setDemonstrationPreparationNotesDraft] = useState('')
  const [isSavingDemonstrationDate, setIsSavingDemonstrationDate] = useState(false)
  const [examinationModal, setExaminationModal] = useState(null)
  const [examinationDateDraft, setExaminationDateDraft] = useState('')
  const [examinationScoreDraft, setExaminationScoreDraft] = useState('')
  const [isSavingExamination, setIsSavingExamination] = useState(false)
  const [cancelledIds, setCancelledIds] = useState([])
  const [ratingNotice, setRatingNotice] = useState(null)
  const [selectedBoardMember, setSelectedBoardMember] = useState('')
  const [isBoardMemberOpen, setIsBoardMemberOpen] = useState(false)
  const [selectedBoardType, setSelectedBoardType] = useState(() => getDefaultBoardType(currentUser))
  const ratingNoticeTimer = useRef(null)
  const boardMemberRef = useRef(null)
  const loadedSavedRatingKeyRef = useRef('')

  const evaluationUploads = useMemo(() => (
    uploads.filter((item) => ['interview', 'for_evaluation', 'hired', 'rated'].includes(getEvaluationStatus(item)))
  ), [uploads])

  const positionOptions = useMemo(() => {
    const titles = Array.from(
      new Set(
        evaluationUploads
          .map((item) => getPosition(item))
          .filter((title) => title && title !== 'No position selected')
      )
    ).sort((a, b) => a.localeCompare(b))

    return [
      { value: 'all', label: 'All Positions' },
      ...titles.map((title) => ({ value: title, label: title }))
    ]
  }, [evaluationUploads])

  const filteredUploads = useMemo(() => {
    const query = searchTerm.trim().toLowerCase()
    return evaluationUploads.filter((item) => {
      if (cancelledIds.includes(item.id)) return false
      const position = getPosition(item)
      const matchesPosition = positionFilter === 'all' || position === positionFilter
      if (!matchesPosition) return false
      if (!query) return true

      const haystack = [
        item.name,
        item.email,
        item.phone,
        position
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase()

      return haystack.includes(query)
    })
  }, [cancelledIds, evaluationUploads, positionFilter, searchTerm])

  const applicantsPageCount = Math.max(1, Math.ceil(filteredUploads.length / applicantsPageSize))
  const paginatedUploads = useMemo(() => {
    const start = (applicantsPage - 1) * applicantsPageSize
    return filteredUploads.slice(start, start + applicantsPageSize)
  }, [applicantsPage, filteredUploads])
  const applicantsStart = filteredUploads.length === 0 ? 0 : ((applicantsPage - 1) * applicantsPageSize) + 1
  const applicantsEnd = Math.min(filteredUploads.length, applicantsPage * applicantsPageSize)

  useEffect(() => {
    setApplicantsPage(1)
  }, [positionFilter, searchTerm])

  useEffect(() => {
    setApplicantsPage((page) => Math.min(page, applicantsPageCount))
  }, [applicantsPageCount])

  useEffect(() => {
    if (!actionsMenu) return
    const handleClose = () => setActionsMenu(null)
    window.addEventListener('click', handleClose)
    window.addEventListener('resize', handleClose)
    window.addEventListener('scroll', handleClose, true)
    return () => {
      window.removeEventListener('click', handleClose)
      window.removeEventListener('resize', handleClose)
      window.removeEventListener('scroll', handleClose, true)
    }
  }, [actionsMenu])

  useEffect(() => () => {
    if (ratingNoticeTimer.current) {
      window.clearTimeout(ratingNoticeTimer.current)
    }
  }, [])

  useEffect(() => {
    setSelectedBoardType((current) => current || getDefaultBoardType(currentUser))
  }, [currentUser])

  useEffect(() => {
    if (!isBoardMemberOpen) return
    const onDocClick = (event) => {
      if (!boardMemberRef.current) return
      if (!boardMemberRef.current.contains(event.target)) {
        setIsBoardMemberOpen(false)
      }
    }
    document.addEventListener('mousedown', onDocClick)
    return () => document.removeEventListener('mousedown', onDocClick)
  }, [isBoardMemberOpen])

  const showRatingNotice = (type, message) => {
    if (ratingNoticeTimer.current) {
      window.clearTimeout(ratingNoticeTimer.current)
    }
    setRatingNotice({ type, message })
    ratingNoticeTimer.current = window.setTimeout(() => {
      setRatingNotice(null)
      ratingNoticeTimer.current = null
    }, 2800)
  }

  const openCriteriaEditor = () => {
    setCriteriaDraft(ratingCriteria)
    setBoardMembersDraft(boardMembers.length ? boardMembers : [''])
    setBoardMembersPage(1)
    setCriteriaEditorOpen(true)
  }

  const saveCriteriaDraft = async () => {
    const cleaned = criteriaDraft.map((item) => String(item || '').trim())
    if (cleaned.some((item) => !item)) {
      showRatingNotice('fail', 'Please complete all rating criteria.')
      return
    }
    const uniqueCount = new Set(cleaned.map((item) => item.toLowerCase())).size
    if (uniqueCount !== cleaned.length) {
      showRatingNotice('fail', 'Criteria names must be unique.')
      return
    }
    const cleanedBoardMembers = boardMembersDraft.map((item) => String(item || '').trim()).filter(Boolean)
    const uniqueBoardMemberCount = new Set(cleanedBoardMembers.map((item) => item.toLowerCase())).size
    if (uniqueBoardMemberCount !== cleanedBoardMembers.length) {
      showRatingNotice('fail', 'Board member names must be unique.')
      return
    }
    setRatingCriteria(cleaned)
    setBoardMembers(cleanedBoardMembers)
    window.localStorage.setItem(ratingCriteriaStorageKey, JSON.stringify(cleaned))
    window.localStorage.setItem(boardMembersStorageKey, JSON.stringify(cleanedBoardMembers))
    try {
      await fetch('http://localhost:5000/activity-logs', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getArchiveActorHeaders(currentUser)
        },
        body: JSON.stringify({
          event: 'rating.settings_updated',
          description: 'Edited rating form settings.',
          subjectType: 'rating_settings',
          subjectName: 'Rating form',
          metadata: {
            before: {
              criteria: ratingCriteria,
              boardMembers
            },
            after: {
              criteria: cleaned,
              boardMembers: cleanedBoardMembers
            },
            criteriaCount: cleaned.length,
            boardMemberCount: cleanedBoardMembers.length
          }
        })
      })
      await onRatingsChanged?.()
    } catch {
      // Keep local settings saved even if activity logging is temporarily unavailable.
    }
    setCriteriaEditorOpen(false)
    setConfirmSaveCriteria(false)
    showRatingNotice('success', 'Rating settings updated successfully.')
  }

  const requestSaveCriteriaDraft = () => {
    const cleaned = criteriaDraft.map((item) => String(item || '').trim())
    if (cleaned.some((item) => !item)) {
      showRatingNotice('fail', 'Please complete all rating criteria.')
      return
    }
    const uniqueCount = new Set(cleaned.map((item) => item.toLowerCase())).size
    if (uniqueCount !== cleaned.length) {
      showRatingNotice('fail', 'Criteria names must be unique.')
      return
    }
    const cleanedBoardMembers = boardMembersDraft.map((item) => String(item || '').trim()).filter(Boolean)
    const uniqueBoardMemberCount = new Set(cleanedBoardMembers.map((item) => item.toLowerCase())).size
    if (uniqueBoardMemberCount !== cleanedBoardMembers.length) {
      showRatingNotice('fail', 'Board member names must be unique.')
      return
    }
    setConfirmSaveCriteria(true)
  }

  const resetCriteriaDraft = () => {
    setCriteriaDraft(defaultRatingCriteria)
  }

  const deleteBoardMemberDraft = (index) => {
    const next = boardMembersDraft.filter((_, memberIndex) => memberIndex !== index)
    setBoardMembersDraft(next.length ? next : [''])
    setConfirmDeleteBoardMember(null)
  }

  const ratingBoardMemberOptions = useMemo(() => {
    const savedNames = boardMembers.map((item) => String(item || '').trim()).filter(Boolean)
    return Array.from(new Set(savedNames))
      .sort((a, b) => a.localeCompare(b))
      .map((name) => ({ value: name, label: name }))
  }, [boardMembers])

  const boardMembersPageSize = 5
  const boardMembersPageCount = Math.max(1, Math.ceil(boardMembersDraft.length / boardMembersPageSize))
  const pagedBoardMembersDraft = useMemo(() => {
    const start = (boardMembersPage - 1) * boardMembersPageSize
    return boardMembersDraft.slice(start, start + boardMembersPageSize).map((member, index) => ({
      member,
      index: start + index
    }))
  }, [boardMembersDraft, boardMembersPage])

  useEffect(() => {
    setBoardMembersPage((page) => Math.min(page, boardMembersPageCount))
  }, [boardMembersPageCount])

  const filteredBoardMemberOptions = useMemo(() => {
    const query = selectedBoardMember.trim().toLowerCase()
    if (!query) return ratingBoardMemberOptions
    return ratingBoardMemberOptions.filter((option) => option.label.toLowerCase().includes(query))
  }, [ratingBoardMemberOptions, selectedBoardMember])

  const openActionsMenu = (event, item) => {
    const rect = event.currentTarget.getBoundingClientRect()
    setActionsMenu({
      item,
      top: rect.bottom + 6,
      left: Math.max(12, rect.right - 150)
    })
  }

  const openApplicantView = (item) => {
    setSelectedApplicant(item)
    setRatingStarted(false)
    setRatingScores({})
    setDemonstrationDetails(demonstrationDetailDefaults)
    setRatingRemarks('')
    setSelectedBoardMember('')
    setSelectedBoardType(getDefaultBoardType(currentUser))
    setRatingFormType('interview')
    setActionsMenu(null)
  }

  const emailApplicant = (item) => {
    const draft = buildApplicantEmailDraft(item, currentUser?.email || '')
    if (!draft) {
      showRatingNotice('fail', 'This applicant has no email address.')
      return
    }

    const emailWindow = window.open(draft.gmail, '_blank', 'noopener,noreferrer')
    if (!emailWindow) {
      window.location.href = draft.mailto
    }
  }

  const openInterviewDateModal = (item) => {
    if (!item?.id) return
    setActionsMenu(null)
    setInterviewDateModal(item)
    setInterviewDateDraft(formatDateInputValue(getScheduledInterviewDateValue(item)))
    setInterviewPlaceDraft(getInterviewPlaceValue(item))
    setInterviewTimeDraft(String(getInterviewTimeValue(item)).slice(0, 5))
    setInterviewPreparationNotesDraft(getInterviewPreparationNotesValue(item))
  }

  const closeInterviewDateModal = () => {
    if (isSavingInterviewDate) return
    setInterviewDateModal(null)
    setInterviewDateDraft('')
    setInterviewPlaceDraft('')
    setInterviewTimeDraft('')
    setInterviewPreparationNotesDraft('')
  }

  const saveInterviewDate = async () => {
    if (!interviewDateModal?.id) return
    if (!interviewDateDraft) {
      showRatingNotice('fail', 'Please select an interview date.')
      return
    }

    setIsSavingInterviewDate(true)
    try {
      const response = await fetch(`/api/uploads/${interviewDateModal.id}/interview-date`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...getArchiveActorHeaders(currentUser)
        },
        body: JSON.stringify({
          interviewDate: interviewDateDraft,
          interviewPlace: interviewPlaceDraft.trim() || null,
          interviewTime: interviewTimeDraft || null,
          interviewPreparationNotes: interviewPreparationNotesDraft.trim() || null
        })
      })
      const payload = await response.json().catch(() => null)
      if (!response.ok) {
        throw new Error(payload?.message || 'Failed to set interview date.')
      }
      if (selectedApplicant?.id === interviewDateModal.id) {
        setSelectedApplicant(payload || selectedApplicant)
      }
      setInterviewDateModal(null)
      setInterviewDateDraft('')
      setInterviewPlaceDraft('')
      setInterviewTimeDraft('')
      setInterviewPreparationNotesDraft('')
      await onRatingsChanged?.()
      showRatingNotice('success', 'Interview date saved successfully.')
    } catch (error) {
      showRatingNotice('fail', error.message || 'Failed to set interview date.')
    } finally {
      setIsSavingInterviewDate(false)
    }
  }

  const openDemonstrationDateModal = (item) => {
    if (!item?.id) return
    setActionsMenu(null)
    setDemonstrationDateModal(item)
    setDemonstrationDateDraft(formatDateInputValue(getDemonstrationDateValue(item)))
    setDemonstrationTimeDraft(String(getDemonstrationTimeValue(item)).slice(0, 5))
    setDemonstrationPlaceDraft(getDemonstrationPlaceValue(item))
    setDemonstrationPreparationNotesDraft(getDemonstrationPreparationNotesValue(item))
  }

  const closeDemonstrationDateModal = () => {
    if (isSavingDemonstrationDate) return
    setDemonstrationDateModal(null)
    setDemonstrationDateDraft('')
    setDemonstrationTimeDraft('')
    setDemonstrationPlaceDraft('')
    setDemonstrationPreparationNotesDraft('')
  }

  const saveDemonstrationDate = async () => {
    if (!demonstrationDateModal?.id) return
    if (!demonstrationDateDraft) {
      showRatingNotice('fail', 'Please select a demo date.')
      return
    }

    setIsSavingDemonstrationDate(true)
    try {
      const response = await fetch(`/api/uploads/${demonstrationDateModal.id}/demonstration-date`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...getArchiveActorHeaders(currentUser)
        },
        body: JSON.stringify({
          demonstrationDate: demonstrationDateDraft,
          demonstrationTime: demonstrationTimeDraft || null,
          demonstrationPlace: demonstrationPlaceDraft.trim() || null,
          demonstrationPreparationNotes: demonstrationPreparationNotesDraft.trim() || null
        })
      })
      const payload = await response.json().catch(() => null)
      if (!response.ok) {
        throw new Error(payload?.message || 'Failed to set demo date.')
      }
      if (selectedApplicant?.id === demonstrationDateModal.id) {
        setSelectedApplicant(payload || selectedApplicant)
      }
      setDemonstrationDateModal(null)
      setDemonstrationDateDraft('')
      setDemonstrationTimeDraft('')
      setDemonstrationPlaceDraft('')
      setDemonstrationPreparationNotesDraft('')
      await onRatingsChanged?.()
      showRatingNotice('success', 'Demo date saved successfully.')
    } catch (error) {
      showRatingNotice('fail', error.message || 'Failed to set demo date.')
    } finally {
      setIsSavingDemonstrationDate(false)
    }
  }

  const openExaminationModal = (item) => {
    if (!item?.id) return
    setActionsMenu(null)
    setExaminationModal(item)
    setExaminationDateDraft(formatDateInputValue(getExaminationDateValue(item)))
    const score = item?.examination_score ?? item?.examinationScore
    setExaminationScoreDraft(score === null || score === undefined ? '' : String(score))
  }

  const closeExaminationModal = () => {
    if (isSavingExamination) return
    setExaminationModal(null)
    setExaminationDateDraft('')
    setExaminationScoreDraft('')
  }

  const saveExamination = async () => {
    if (!examinationModal?.id) return
    const numericScore = Number(examinationScoreDraft)
    if (examinationScoreDraft === '' || Number.isNaN(numericScore)) {
      showRatingNotice('fail', 'Please enter an exam score.')
      return
    }
    if (numericScore < 0 || numericScore > 100) {
      showRatingNotice('fail', 'Exam score must be from 0 to 100.')
      return
    }

    setIsSavingExamination(true)
    try {
      const response = await fetch(`/api/uploads/${examinationModal.id}/examination`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...getArchiveActorHeaders(currentUser)
        },
        body: JSON.stringify({
          examinationDate: examinationDateDraft || null,
          examinationScore: numericScore
        })
      })
      const payload = await response.json().catch(() => null)
      if (!response.ok) {
        throw new Error(payload?.message || 'Failed to save exam score.')
      }
      if (selectedApplicant?.id === examinationModal.id) {
        setSelectedApplicant(payload || selectedApplicant)
      }
      setExaminationModal(null)
      setExaminationDateDraft('')
      setExaminationScoreDraft('')
      await onRatingsChanged?.()
      showRatingNotice('success', 'Exam score saved successfully.')
    } catch (error) {
      showRatingNotice('fail', error.message || 'Failed to save exam score.')
    } finally {
      setIsSavingExamination(false)
    }
  }

  const demonstrationCriteria = useMemo(() => (
    demonstrationSections.flatMap((section) => (
      section.criteria.map((criterion) => getDemonstrationCriterionKey(section.key, criterion))
    ))
  ), [])

  const activeRatingCriteria = ratingFormType === 'demonstration' ? demonstrationCriteria : ratingCriteria
  const activeMaxScore = activeRatingCriteria.length * 5
  const totalRatingScore = useMemo(() => (
    activeRatingCriteria.reduce((total, criterion) => total + Number(ratingScores[criterion] || 0), 0)
  ), [activeRatingCriteria, ratingScores])
  const demonstrationApplicableScores = useMemo(() => (
    demonstrationCriteria
      .map((criterion) => Number(ratingScores[criterion]))
      .filter((score) => score > 0)
  ), [demonstrationCriteria, ratingScores])
  const demonstrationMean = demonstrationApplicableScores.length
    ? demonstrationApplicableScores.reduce((total, score) => total + score, 0) / demonstrationApplicableScores.length
    : 0

  const saveRating = async () => {
    if (!selectedApplicant?.id) return
    const boardMemberName = selectedBoardMember.trim()
    if (!boardMemberName) {
      showRatingNotice('fail', 'Please enter a board member name before saving.')
      return
    }
    if (hasBoardMemberRated(selectedApplicant, boardMemberName, ratingFormType)) {
      showRatingNotice('fail', `${boardMemberName} has already rated this applicant.`)
      return
    }
    const missingScore = activeRatingCriteria.some((criterion) => ratingScores[criterion] === undefined)
    if (missingScore) {
      showRatingNotice('fail', 'Please complete all rating criteria before saving.')
      return
    }

    const scores = activeRatingCriteria.reduce((payload, criterion) => ({
      ...payload,
      [criterion]: Number(ratingScores[criterion])
    }), {})

    try {
      const response = await fetch(`http://localhost:5000/uploads/${selectedApplicant.id}/ratings`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getArchiveActorHeaders(currentUser)
        },
        body: JSON.stringify({
          raterName: boardMemberName,
          raterEmail: '',
          boardMembers,
          boardType: selectedBoardType,
          formType: ratingFormType,
          scores,
          remarks: ratingRemarks.trim()
        })
      })
      const payload = await response.json().catch(() => null)
      if (!response.ok) {
        throw new Error(payload?.message || 'Failed to save rating.')
      }
      setSelectedApplicant(payload)
      setRatingScores({})
      setDemonstrationDetails(demonstrationDetailDefaults)
      setRatingRemarks('')
      setSelectedBoardMember('')
      setSelectedBoardType(getDefaultBoardType(currentUser))
      setRatingFormType('interview')
      setRatingStarted(false)
      onRatingsChanged?.()
      showRatingNotice('success', 'Rating saved successfully.')
    } catch (error) {
      showRatingNotice('fail', error.message || 'Failed to save rating.')
    }
  }

  const requestSaveRating = () => {
    const boardMemberName = selectedBoardMember.trim()
    if (!boardMemberName) {
      showRatingNotice('fail', 'Please enter a board member name before saving.')
      return
    }
    if (hasBoardMemberRated(selectedApplicant, boardMemberName, ratingFormType)) {
      showRatingNotice('fail', `${boardMemberName} has already rated this applicant.`)
      return
    }
    const missingScore = activeRatingCriteria.some((criterion) => ratingScores[criterion] === undefined)
    if (missingScore) {
      showRatingNotice('fail', 'Please complete all rating criteria before saving.')
      return
    }

    setConfirmSaveRating(true)
  }

  const cancelRating = async (item) => {
    if (!item?.id) return
    setActionsMenu(null)
    try {
      const response = await fetch(`http://localhost:5000/uploads/${item.id}/evaluation/cancel`, {
        method: 'PUT',
        headers: getArchiveActorHeaders(currentUser)
      })
      const payload = await response.json().catch(() => null)
      if (!response.ok) {
        throw new Error(payload?.message || 'Failed to cancel rating.')
      }
      setCancelledIds((prev) => Array.from(new Set([...prev, item.id])))
      if (selectedApplicant?.id === item.id) {
        setSelectedApplicant(null)
        setRatingStarted(false)
        setRatingScores({})
        setDemonstrationDetails(demonstrationDetailDefaults)
        setRatingRemarks('')
        setSelectedBoardMember('')
        setSelectedBoardType(getDefaultBoardType(currentUser))
        setRatingFormType('interview')
      }
      onRatingsChanged?.()
      showRatingNotice(
        'success',
        isRatedApplicant(item) ? 'Rating record deleted successfully.' : 'Interview rating cancelled successfully.'
      )
    } catch (error) {
      showRatingNotice('fail', error.message || 'Failed to cancel rating.')
    }
  }

  const exportRatingSummary = async (item) => {
    if (!item?.id) return
    setActionsMenu(null)
    try {
      const response = await fetch(`http://localhost:5000/uploads/${item.id}/rating-summary/export`, {
        headers: getArchiveActorHeaders(currentUser)
      })
      const blob = await response.blob()
      if (!response.ok) {
        const message = await blob.text().then((text) => {
          try {
            return JSON.parse(text)?.message
          } catch {
            return null
          }
        }).catch(() => null)
        throw new Error(message || 'Failed to export rating summary.')
      }

      const disposition = response.headers.get('content-disposition') || ''
      const filenameMatch = disposition.match(/filename="?([^"]+)"?/i)
      const filename = filenameMatch?.[1] || `rating-summary-${item.id}.xls`
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = filename
      document.body.appendChild(link)
      link.click()
      link.remove()
      window.URL.revokeObjectURL(url)
      await onRatingsChanged?.()
      showRatingNotice('success', 'Rating summary exported successfully.')
    } catch (error) {
      showRatingNotice('fail', error.message || 'Failed to export rating summary.')
    }
  }

  const exportDemonstrationSummary = async (item) => {
    if (!item?.id) return
    setActionsMenu(null)
    try {
      const response = await fetch(`http://localhost:5000/uploads/${item.id}/demonstration-summary/export`, {
        headers: getArchiveActorHeaders(currentUser)
      })
      const blob = await response.blob()
      if (!response.ok) {
        const message = await blob.text().then((text) => {
          try {
            return JSON.parse(text)?.message
          } catch {
            return null
          }
        }).catch(() => null)
        throw new Error(message || 'Failed to export demonstration summary.')
      }

      const disposition = response.headers.get('content-disposition') || ''
      const filenameMatch = disposition.match(/filename="?([^"]+)"?/i)
      const filename = filenameMatch?.[1] || `demonstration-summary-${item.id}.xls`
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = filename
      document.body.appendChild(link)
      link.click()
      link.remove()
      window.URL.revokeObjectURL(url)
      await onRatingsChanged?.()
      showRatingNotice('success', 'Demonstration summary exported successfully.')
    } catch (error) {
      showRatingNotice('fail', error.message || 'Failed to export demonstration summary.')
    }
  }

  const exportRatingsOverallSummary = async () => {
    try {
      const response = await fetch('http://localhost:5000/uploads/ratings-summary/export', {
        headers: getArchiveActorHeaders(currentUser)
      })
      const blob = await response.blob()
      if (!response.ok) {
        const message = await blob.text().then((text) => {
          try {
            return JSON.parse(text)?.message
          } catch {
            return null
          }
        }).catch(() => null)
        throw new Error(message || 'Failed to export ratings summary.')
      }

      const disposition = response.headers.get('content-disposition') || ''
      const filenameMatch = disposition.match(/filename="?([^"]+)"?/i)
      const filename = filenameMatch?.[1] || 'ratings-overall-summary.xls'
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = filename
      document.body.appendChild(link)
      link.click()
      link.remove()
      window.URL.revokeObjectURL(url)
      await onRatingsChanged?.()
      showRatingNotice('success', 'Ratings summary exported successfully.')
    } catch (error) {
      showRatingNotice('fail', error.message || 'Failed to export ratings summary.')
    }
  }

  const openCancelConfirmation = (item) => {
    if (!item?.id) return
    setActionsMenu(null)
    setConfirmRatingAction(item)
  }

  const closeCancelConfirmation = () => {
    setConfirmRatingAction(null)
  }

  const closeSaveConfirmation = () => {
    setConfirmSaveRating(false)
  }

  const isRatedApplicant = (item) => Boolean(item?.ratingCount || item?.rating_count || (Array.isArray(item?.ratings) && item.ratings.length))
  const hasSavedFormRating = (item, formType) => {
    const ratings = Array.isArray(item?.ratings) ? item.ratings : []
    return ratings.some((rating) => getSavedRatingFormType(rating) === formType)
  }
  const getSavedBoardMemberRating = (item, boardMember, formType = ratingFormType) => {
    const ratings = Array.isArray(item?.ratings) ? item.ratings : []
    const boardMemberName = String(boardMember || '').trim().toLowerCase()
    const targetFormType = formType === 'demonstration' ? 'demonstration' : 'interview'

    if (!boardMemberName) return null

    return ratings.find((rating) => {
      const raterName = String(rating.raterName || rating.rater_name || '').trim().toLowerCase()
      return raterName === boardMemberName && getSavedRatingFormType(rating) === targetFormType
    }) || null
  }
  const hasBoardMemberRated = (item, boardMember, formType = ratingFormType) => {
    return Boolean(getSavedBoardMemberRating(item, boardMember, formType))
  }

  const selectedBoardMemberSavedRating = useMemo(() => (
    getSavedBoardMemberRating(selectedApplicant, selectedBoardMember, ratingFormType)
  ), [selectedApplicant, selectedBoardMember, ratingFormType])
  const isViewingSavedBoardMemberRating = Boolean(selectedBoardMemberSavedRating)

  useEffect(() => {
    if (!ratingStarted) return

    if (selectedBoardMemberSavedRating) {
      const savedRatingKey = `${selectedBoardMemberSavedRating.id || selectedBoardMember}:${ratingFormType}`
      loadedSavedRatingKeyRef.current = savedRatingKey
      setRatingScores(selectedBoardMemberSavedRating.scores || {})
      setRatingRemarks(selectedBoardMemberSavedRating.remarks || '')
      setDemonstrationDetails(demonstrationDetailDefaults)
      return
    }

    if (loadedSavedRatingKeyRef.current) {
      loadedSavedRatingKeyRef.current = ''
      setRatingScores({})
      setRatingRemarks('')
      setDemonstrationDetails(demonstrationDetailDefaults)
    }
  }, [ratingFormType, ratingStarted, selectedBoardMember, selectedBoardMemberSavedRating])

  const ratingNoticeNode = ratingNotice ? (
    <div className={`toast toast-${ratingNotice.type}`} role="status" aria-live="polite">
      {ratingNotice.message}
    </div>
  ) : null

  const confirmationIsDelete = isRatedApplicant(confirmRatingAction)
  const ratingConfirmNode = confirmRatingAction ? (
    <div
      className="modal-overlay delete-confirm-overlay"
      onClick={(event) => {
        if (event.target === event.currentTarget) {
          closeCancelConfirmation()
        }
      }}
    >
      <div className="modal-card delete-confirm-card">
        <h3>{confirmationIsDelete ? 'Delete Rating' : 'Cancel Interview'}</h3>
        <p>
          {confirmationIsDelete
            ? `Are you sure you want to delete the rating record for ${confirmRatingAction.name || 'this applicant'}?`
            : `Are you sure you want to cancel the interview rating for ${confirmRatingAction.name || 'this applicant'}?`}
        </p>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={closeCancelConfirmation}>
            Cancel
          </button>
          <button
            type="button"
            className="btn btn-danger"
            onClick={async () => {
              const target = confirmRatingAction
              closeCancelConfirmation()
              await cancelRating(target)
            }}
          >
            {confirmationIsDelete ? 'Delete' : 'Cancel Interview'}
          </button>
        </div>
      </div>
    </div>
  ) : null

  const interviewDateNode = interviewDateModal ? (
    <div
      className="modal-overlay delete-confirm-overlay"
      onClick={(event) => {
        if (event.target === event.currentTarget) {
          closeInterviewDateModal()
        }
      }}
    >
      <div className="modal-card delete-confirm-card ratings-date-card">
        <h3>Set Interview Date</h3>
        <p>Select the interview date for {interviewDateModal.name || 'this applicant'}.</p>
        <label className="ratings-date-field">
          <span>Date of Interview</span>
          <input
            type="date"
            value={interviewDateDraft}
            onChange={(event) => setInterviewDateDraft(event.target.value)}
          />
        </label>
        <label className="ratings-date-field">
          <span>Time</span>
          <input
            type="time"
            value={interviewTimeDraft}
            onChange={(event) => setInterviewTimeDraft(event.target.value)}
          />
        </label>
        <label className="ratings-date-field">
          <span>Place</span>
          <input
            type="text"
            value={interviewPlaceDraft}
            onChange={(event) => setInterviewPlaceDraft(event.target.value)}
            placeholder="Interview venue"
            maxLength={255}
          />
        </label>
        <label className="ratings-date-field">
          <span>Notes to Prepare</span>
          <textarea
            value={interviewPreparationNotesDraft}
            onChange={(event) => setInterviewPreparationNotesDraft(event.target.value)}
            placeholder="Documents, requirements, or reminders for the applicant"
            maxLength={2000}
            rows={4}
          />
        </label>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={closeInterviewDateModal} disabled={isSavingInterviewDate}>
            Cancel
          </button>
          <button type="button" className="btn" onClick={saveInterviewDate} disabled={isSavingInterviewDate}>
            {isSavingInterviewDate ? 'Saving...' : 'Save Date'}
          </button>
        </div>
      </div>
    </div>
  ) : null

  const demonstrationDateNode = demonstrationDateModal ? (
    <div
      className="modal-overlay delete-confirm-overlay"
      onClick={(event) => {
        if (event.target === event.currentTarget) {
          closeDemonstrationDateModal()
        }
      }}
    >
      <div className="modal-card delete-confirm-card ratings-date-card">
        <h3>Set Demo Date</h3>
        <p>Select the demo date for {demonstrationDateModal.name || 'this applicant'}.</p>
        <label className="ratings-date-field">
          <span>Date of Demo</span>
          <input
            type="date"
            value={demonstrationDateDraft}
            onChange={(event) => setDemonstrationDateDraft(event.target.value)}
          />
        </label>
        <label className="ratings-date-field">
          <span>Time</span>
          <input
            type="time"
            value={demonstrationTimeDraft}
            onChange={(event) => setDemonstrationTimeDraft(event.target.value)}
          />
        </label>
        <label className="ratings-date-field">
          <span>Place</span>
          <input
            type="text"
            value={demonstrationPlaceDraft}
            onChange={(event) => setDemonstrationPlaceDraft(event.target.value)}
            placeholder="Demonstration venue"
            maxLength={255}
          />
        </label>
        <label className="ratings-date-field">
          <span>Notes to Prepare</span>
          <textarea
            value={demonstrationPreparationNotesDraft}
            onChange={(event) => setDemonstrationPreparationNotesDraft(event.target.value)}
            placeholder="Materials, equipment, or reminders for the applicant"
            maxLength={2000}
            rows={4}
          />
        </label>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={closeDemonstrationDateModal} disabled={isSavingDemonstrationDate}>
            Cancel
          </button>
          <button type="button" className="btn" onClick={saveDemonstrationDate} disabled={isSavingDemonstrationDate}>
            {isSavingDemonstrationDate ? 'Saving...' : 'Save Date'}
          </button>
        </div>
      </div>
    </div>
  ) : null

  const examinationNode = examinationModal ? (
    <div
      className="modal-overlay delete-confirm-overlay"
      onClick={(event) => {
        if (event.target === event.currentTarget) {
          closeExaminationModal()
        }
      }}
    >
      <div className="modal-card delete-confirm-card ratings-date-card">
        <h3>Add Examination Score</h3>
        <p>Add the exam details for {examinationModal.name || 'this applicant'}.</p>
        <label className="ratings-date-field">
          <span>Date of Exam</span>
          <input
            type="date"
            value={examinationDateDraft}
            onChange={(event) => setExaminationDateDraft(event.target.value)}
          />
        </label>
        <label className="ratings-date-field">
          <span>Exam Score</span>
          <input
            type="number"
            min="0"
            max="100"
            step="0.01"
            value={examinationScoreDraft}
            onChange={(event) => setExaminationScoreDraft(event.target.value)}
            placeholder="0 - 100"
          />
        </label>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={closeExaminationModal} disabled={isSavingExamination}>
            Cancel
          </button>
          <button type="button" className="btn" onClick={saveExamination} disabled={isSavingExamination}>
            {isSavingExamination ? 'Saving...' : 'Save Score'}
          </button>
        </div>
      </div>
    </div>
  ) : null

  if (criteriaEditorOpen) {
    const criteriaConfirmNode = confirmSaveCriteria ? (
      <div
        className="modal-overlay delete-confirm-overlay"
        onClick={(event) => {
          if (event.target === event.currentTarget) {
            setConfirmSaveCriteria(false)
          }
        }}
      >
        <div className="modal-card delete-confirm-card ratings-save-confirm-card">
          <h3>Save Rating Settings</h3>
          <p>Save these rating criteria and board member settings?</p>
          <div className="ratings-save-confirm-summary">
            <span>Criteria</span>
            <strong>{criteriaDraft.map((item) => String(item || '').trim()).filter(Boolean).length} items</strong>
            <span>Board Members</span>
            <strong>{boardMembersDraft.map((item) => String(item || '').trim()).filter(Boolean).length} names</strong>
          </div>
          <div className="modal-actions">
            <button type="button" className="btn btn-secondary" onClick={() => setConfirmSaveCriteria(false)}>
              Cancel
            </button>
            <button
              type="button"
              className="btn"
              onClick={async () => {
                await saveCriteriaDraft()
              }}
            >
              Confirm Save
            </button>
          </div>
        </div>
      </div>
    ) : null
    const boardMemberDeleteConfirmNode = confirmDeleteBoardMember ? (
      <div
        className="modal-overlay delete-confirm-overlay"
        onClick={(event) => {
          if (event.target === event.currentTarget) {
            setConfirmDeleteBoardMember(null)
          }
        }}
      >
        <div className="modal-card delete-confirm-card">
          <h3>Delete Board Member</h3>
          <p>
            Remove {confirmDeleteBoardMember.name || 'this board member'} from the rating settings?
          </p>
          <div className="modal-actions">
            <button type="button" className="btn btn-secondary" onClick={() => setConfirmDeleteBoardMember(null)}>
              Cancel
            </button>
            <button
              type="button"
              className="btn btn-danger"
              onClick={() => deleteBoardMemberDraft(confirmDeleteBoardMember.index)}
            >
              Delete
            </button>
          </div>
        </div>
      </div>
    ) : null

    return (
      <section className="ratings-criteria-page" aria-label="Edit rating criteria">
        {ratingNoticeNode}
        {criteriaConfirmNode}
        {boardMemberDeleteConfirmNode}
        <div className="ratings-form-header">
          <div>
            <button
              type="button"
              className="ratings-back-link"
              onClick={() => setCriteriaEditorOpen(false)}
            >
              Back to Ratings
            </button>
            <h2>Edit Rating Settings</h2>
            <p>Update the criteria and board members used in the interview rating form.</p>
          </div>
        </div>

        <div className="ratings-criteria-card">
          <div className="ratings-settings-section-head">
            <h3>Rating Criteria</h3>
            <span>{criteriaDraft.length} items</span>
          </div>
          {criteriaDraft.map((criterion, index) => (
            <label key={`criteria-${index}`} className="ratings-criteria-field">
              <span>Criteria {index + 1}</span>
              <input
                type="text"
                value={criterion}
                onChange={(event) => {
                  const next = [...criteriaDraft]
                  next[index] = event.target.value
                  setCriteriaDraft(next)
                }}
              />
            </label>
          ))}
        </div>

        <div className="ratings-criteria-card">
          <div className="ratings-settings-section-head">
            <h3>Board Members</h3>
            <span>{boardMembersDraft.filter((name) => String(name || '').trim()).length} names</span>
          </div>
          <div className="ratings-board-members-table-wrap">
            <table className="ratings-board-members-table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {pagedBoardMembersDraft.map(({ member, index }) => (
                  <tr key={`board-member-${index}`}>
                    <td>{index + 1}</td>
                    <td>
                      <input
                        type="text"
                        value={member}
                        onChange={(event) => {
                          const next = [...boardMembersDraft]
                          next[index] = event.target.value
                          setBoardMembersDraft(next)
                        }}
                        placeholder="Enter board member name"
                      />
                    </td>
                    <td>
                      <button
                        type="button"
                        className="ratings-table-remove-btn"
                        onClick={() => {
                          setConfirmDeleteBoardMember({
                            index,
                            name: String(member || '').trim()
                          })
                        }}
                      >
                        Remove
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="ratings-table-pager">
              <span>
                Page {boardMembersPage} of {boardMembersPageCount}
              </span>
              <div>
                <button
                  type="button"
                  onClick={() => setBoardMembersPage((page) => Math.max(1, page - 1))}
                  disabled={boardMembersPage === 1}
                >
                  Previous
                </button>
                <button
                  type="button"
                  onClick={() => setBoardMembersPage((page) => Math.min(boardMembersPageCount, page + 1))}
                  disabled={boardMembersPage === boardMembersPageCount}
                >
                  Next
                </button>
              </div>
            </div>
          </div>
          <button
            type="button"
            className="ratings-add-member-btn"
            onClick={() => {
              setBoardMembersDraft((prev) => {
                const next = [...prev, '']
                setBoardMembersPage(Math.ceil(next.length / boardMembersPageSize))
                return next
              })
            }}
          >
            Add Board Member
          </button>
        </div>

        <div className="ratings-form-footer">
          <button type="button" className="btn btn-secondary" onClick={resetCriteriaDraft}>
            Reset Defaults
          </button>
          <button type="button" className="btn btn-secondary" onClick={() => setCriteriaEditorOpen(false)}>
            Cancel
          </button>
          <button type="button" className="btn" onClick={requestSaveCriteriaDraft}>
            Save Settings
          </button>
        </div>
      </section>
    )
  }

  if (selectedApplicant) {
    const applicantRatings = Array.isArray(selectedApplicant.ratings) ? selectedApplicant.ratings : []
    const getSavedMaxScore = (rating) => {
      const total = Number(rating.totalScore ?? rating.total_score ?? 0)
      const percentage = Number(rating.percentageScore ?? rating.percentage_score ?? 0)
      if (total > 0 && percentage > 0) {
        return Math.round(total / (percentage / 100))
      }
      const savedScores = rating.scores || {}
      return Math.max(1, Object.values(savedScores).filter((score) => Number(score) > 0).length) * 5
    }
    const getRatingGroupStats = (formType) => {
      const ratings = applicantRatings.filter((rating) => getSavedRatingFormType(rating) === formType)
      const count = ratings.length
      const average = count
        ? ratings.reduce((total, rating) => total + Number(rating.percentageScore ?? rating.percentage_score ?? 0), 0) / count
        : 0
      return {
        ratings,
        count,
        label: count ? `${average.toFixed(2)}%` : 'No rating'
      }
    }
    const interviewStats = getRatingGroupStats('interview')
    const demonstrationStats = getRatingGroupStats('demonstration')
    const canOpenRatingForm = ratingStarted
    const isDemonstrationForm = ratingFormType === 'demonstration'
    const scheduledInterviewDate = formatInterviewDate(getScheduledInterviewDateValue(selectedApplicant))
    const interviewPlace = getInterviewPlaceValue(selectedApplicant).trim()
    const interviewTime = formatTimeLabel(getInterviewTimeValue(selectedApplicant))
    const interviewPreparationNotes = getInterviewPreparationNotesValue(selectedApplicant).trim()
    const demonstrationDate = formatInterviewDate(getDemonstrationDateValue(selectedApplicant))
    const demonstrationTime = formatTimeLabel(getDemonstrationTimeValue(selectedApplicant))
    const demonstrationPlace = getDemonstrationPlaceValue(selectedApplicant).trim()
    const demonstrationPreparationNotes = getDemonstrationPreparationNotesValue(selectedApplicant).trim()
    const selectedBoardMemberAlreadyRated = hasBoardMemberRated(selectedApplicant, selectedBoardMember, ratingFormType)
    const saveRatingConfirmNode = confirmSaveRating ? (
      <div
        className="modal-overlay delete-confirm-overlay"
        onClick={(event) => {
          if (event.target === event.currentTarget) {
            closeSaveConfirmation()
          }
        }}
      >
        <div className="modal-card delete-confirm-card ratings-save-confirm-card">
          <h3>Save Rating</h3>
          <p>
            Save {selectedBoardMember || 'this board member'}'s rating for {selectedApplicant.name || 'this applicant'}?
          </p>
          <div className="ratings-save-confirm-summary">
            <span>Board Member</span>
            <strong>{selectedBoardMember || '-'}</strong>
            <span>Board Type</span>
            <strong>{getBoardTypeLabel(selectedBoardType)}</strong>
            <span>Total Score</span>
            <strong>{totalRatingScore}/{activeMaxScore}</strong>
          </div>
          <div className="modal-actions">
            <button type="button" className="btn btn-secondary" onClick={closeSaveConfirmation}>
              Cancel
            </button>
            <button
              type="button"
              className="btn"
              onClick={async () => {
                closeSaveConfirmation()
                await saveRating()
              }}
            >
              Confirm Save
            </button>
          </div>
        </div>
      </div>
    ) : null

    if (canOpenRatingForm) {
      return (
        <section className="ratings-form-page" aria-label={isDemonstrationForm ? 'Application demonstration form' : 'Interview rating form'}>
          {ratingNoticeNode}
          {saveRatingConfirmNode}
          <div className="ratings-form-header">
            <div>
              <button
                type="button"
                className="ratings-back-link"
                onClick={() => {
          setSelectedBoardMember('')
          setSelectedBoardType(getDefaultBoardType(currentUser))
          setDemonstrationDetails(demonstrationDetailDefaults)
          setRatingRemarks('')
          setRatingFormType('interview')
          setRatingStarted(false)
                }}
              >
                Back to Application Summary
              </button>
              <h2>{isDemonstrationForm ? 'Application Demonstration Form' : 'Interview Rating Form'}</h2>
            </div>
            <div className="ratings-total-box">
              <span>Total Score</span>
              <strong>{totalRatingScore}/{activeMaxScore}</strong>
            </div>
          </div>

          <div className="ratings-form-details">
            <dl className="ratings-applicant-details" aria-label="Application interview details">
              <div className="ratings-detail-row">
                <dt>Name:</dt>
                <dd>{selectedApplicant.name || '(No name)'}</dd>
              </div>
              <div className="ratings-detail-row">
                <dt>Position Applied:</dt>
                <dd>{getPosition(selectedApplicant)}</dd>
              </div>
              {!isDemonstrationForm ? (
                <>
                  <div className="ratings-detail-row">
                    <dt>Date of Interview:</dt>
                    <dd>{scheduledInterviewDate}</dd>
                  </div>
                  <div className="ratings-detail-row">
                    <dt>Time of Interview:</dt>
                    <dd>{interviewTime}</dd>
                  </div>
                  <div className="ratings-detail-row">
                    <dt>Place of Interview:</dt>
                    <dd>{interviewPlace || '-'}</dd>
                  </div>
                </>
              ) : (
                <>
                  <div className="ratings-detail-row">
                    <dt>Date of Demo:</dt>
                    <dd>{demonstrationDate}</dd>
                  </div>
                  <div className="ratings-detail-row">
                    <dt>Time of Demo:</dt>
                    <dd>{demonstrationTime}</dd>
                  </div>
                  <div className="ratings-detail-row">
                    <dt>Place of Demo:</dt>
                    <dd>{demonstrationPlace || '-'}</dd>
                  </div>
                </>
              )}
            </dl>

            <div className="ratings-board-block">
              <span className="ratings-board-label">Selection Board</span>
              <CustomDropdown
                className="ratings-board-dropdown"
                options={boardTypeOptions}
                value={selectedBoardType}
                onChange={setSelectedBoardType}
                placeholder="Select board type"
              />
              <div
                ref={boardMemberRef}
                className="ratings-board-member-combobox"
                onClick={(event) => event.stopPropagation()}
              >
                <input
                  className="ratings-board-input"
                  type="text"
                  value={selectedBoardMember}
                  onChange={(event) => {
                    setSelectedBoardMember(event.target.value)
                    setIsBoardMemberOpen(true)
                  }}
                  onFocus={() => setIsBoardMemberOpen(true)}
                  placeholder="Select or type board member"
                />
                <button
                  type="button"
                  className="ratings-board-member-toggle"
                  aria-label="Show board member names"
                  onClick={() => setIsBoardMemberOpen((current) => !current)}
                  disabled={ratingBoardMemberOptions.length === 0}
                >
                  {isBoardMemberOpen ? '▴' : '▾'}
                </button>
                {isBoardMemberOpen && filteredBoardMemberOptions.length > 0 && (
                  <div className="ratings-board-member-menu">
                    {filteredBoardMemberOptions.map((option) => (
                      <button
                        key={option.value}
                        type="button"
                        className={`ratings-board-member-option ${option.value === selectedBoardMember ? 'active' : ''}`}
                        onMouseDown={(event) => {
                          event.preventDefault()
                          setSelectedBoardMember(option.value)
                          setIsBoardMemberOpen(false)
                        }}
                      >
                        {option.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              {selectedBoardMemberAlreadyRated && (
                <p className="ratings-board-warning">
                  Showing {selectedBoardMember}'s saved {isDemonstrationForm ? 'demonstration' : 'interview'} rating. This rating cannot be edited.
                </p>
              )}
            </div>
          </div>

          {isDemonstrationForm ? (
            <div className="demonstration-form-shell">
              <div className="demonstration-form-title">
                <h3>Application Demonstration Form</h3>
                <span>Instructor / Lecture / Demo</span>
              </div>
              <div className="demonstration-meta-grid">
                {[
                  ['teacher', 'Teacher'],
                  ['date', 'Date'],
                  ['subject', 'Subject'],
                  ['time', 'Time'],
                  ['building', 'Building'],
                  ['room', 'Room'],
                  ['matterLesson', 'Subject Matter / Lesson']
                ].map(([key, label]) => (
                  <label key={key} className={key === 'matterLesson' ? 'wide' : ''}>
                    <span>{label}</span>
                    <input
                      type={key === 'date' ? 'date' : key === 'time' ? 'time' : 'text'}
                      value={demonstrationDetails[key]}
                      disabled={isViewingSavedBoardMemberRating}
                      onChange={(event) => setDemonstrationDetails((prev) => ({
                        ...prev,
                        [key]: event.target.value
                      }))}
                    />
                  </label>
                ))}
              </div>
              <div className="demonstration-table-scroll">
                <table className="demonstration-rating-table">
                  <thead>
                    <tr>
                      <th className="demonstration-section-head">Criteria</th>
                      <th colSpan={demonstrationRatingColumns.length}>Rating</th>
                    </tr>
                    <tr className="demonstration-rating-legend-row">
                      <th />
                      {demonstrationRatingColumns.map((column) => (
                        <th key={column.value}>
                          <div className="demonstration-rating-head-content">
                            <strong>{column.value}</strong>
                            <span>{column.label}</span>
                          </div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {demonstrationSections.map((section) => (
                      <React.Fragment key={section.key}>
                        <tr className="demonstration-section-row">
                          <td colSpan={demonstrationRatingColumns.length + 1}>{section.label}</td>
                        </tr>
                        {section.criteria.map((criterion, index) => {
                          const criterionKey = getDemonstrationCriterionKey(section.key, criterion)
                          return (
                            <tr key={criterionKey}>
                              <td className="demonstration-criterion">
                                <span>{index + 1}</span>
                                <strong>{criterion}</strong>
                              </td>
                              {demonstrationRatingColumns.map((column) => (
                                <td key={`${criterionKey}-${column.value}`} className="ratings-radio-cell">
                                  <label className="ratings-radio-choice">
                                    <input
                                      type="radio"
                                      name={`demo-${criterionKey}`}
                                      value={column.value}
                                      disabled={isViewingSavedBoardMemberRating}
                                      checked={Number(ratingScores[criterionKey] ?? -1) === (column.value === 'NA' ? 0 : column.value)}
                                      onChange={() => {
                                        if (isViewingSavedBoardMemberRating) return
                                        setRatingScores((prev) => ({
                                          ...prev,
                                          [criterionKey]: column.value === 'NA' ? 0 : column.value
                                        }))
                                      }}
                                    />
                                    <span aria-hidden="true" />
                                  </label>
                                </td>
                              ))}
                            </tr>
                          )
                        })}
                        <tr className="demonstration-subtotal-row">
                          <td>Total</td>
                          <td colSpan={demonstrationRatingColumns.length}>
                            {section.criteria.reduce((total, criterion) => (
                              total + Number(ratingScores[getDemonstrationCriterionKey(section.key, criterion)] || 0)
                            ), 0)}
                          </td>
                        </tr>
                      </React.Fragment>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="demonstration-overall-grid">
                <label>
                  <span>Overall Rating</span>
                  <input value={demonstrationMean ? demonstrationMean.toFixed(2) : ''} readOnly />
                </label>
                <label>
                  <span>Descriptive Rating</span>
                  <input value={getDemonstrationDescription(demonstrationMean)} readOnly />
                </label>
                <label className="demonstration-observer-field">
                  <span>Observer</span>
                  <input
                    type="text"
                    value={demonstrationDetails.observer}
                    disabled={isViewingSavedBoardMemberRating}
                    onChange={(event) => setDemonstrationDetails((prev) => ({
                      ...prev,
                      observer: event.target.value
                    }))}
                  />
                </label>
              </div>
            </div>
          ) : (
            <div className="ratings-form-shell">
              <div className="ratings-form-scroll">
                <table className="ratings-form-table">
                  <thead>
                    <tr>
                      <th className="ratings-form-criteria-head" rowSpan={2}>Criteria</th>
                      <th className="ratings-form-score-head" colSpan={ratingBands.length}>Rate / Score</th>
                    </tr>
                    <tr>
                      {ratingBands.map((band) => (
                        <th key={band.value}>
                          <span>{band.label}</span>
                          <small>({band.range})</small>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {ratingCriteria.map((criterion, index) => (
                      <tr key={criterion}>
                        <td className="ratings-form-criterion">
                          <span>{index + 1}.</span>
                          <strong>{criterion}</strong>
                        </td>
                        {ratingBands.map((band) => (
                          <td key={`${criterion}-${band.value}`} className="ratings-radio-cell">
                            <label className="ratings-radio-choice">
                              <input
                                type="radio"
                                name={`rating-${index}`}
                                value={band.value}
                                disabled={isViewingSavedBoardMemberRating}
                                checked={Number(ratingScores[criterion] || 0) === band.value}
                                onChange={() => {
                                  if (isViewingSavedBoardMemberRating) return
                                  setRatingScores((prev) => ({
                                    ...prev,
                                    [criterion]: band.value
                                  }))
                                }}
                              />
                              <span aria-hidden="true" />
                            </label>
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          <label className="ratings-remarks-field">
            <span>Remarks <small>(Optional)</small></span>
            <textarea
              value={ratingRemarks}
              readOnly={isViewingSavedBoardMemberRating}
              onChange={(event) => setRatingRemarks(event.target.value)}
              placeholder={isViewingSavedBoardMemberRating ? "No remarks saved." : "Add any comments here..."}
              maxLength={1000}
              rows={4}
            />
          </label>

          <div className="ratings-form-footer">
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => {
                setSelectedBoardMember('')
                setSelectedBoardType(getDefaultBoardType(currentUser))
                setDemonstrationDetails(demonstrationDetailDefaults)
                setRatingRemarks('')
                setRatingFormType('interview')
                setRatingStarted(false)
              }}
            >
              Cancel
            </button>
            <button
              type="button"
              className="btn"
              disabled={isViewingSavedBoardMemberRating}
              onClick={requestSaveRating}
            >
              {isViewingSavedBoardMemberRating ? 'Saved Rating' : 'Save Rating'}
            </button>
          </div>
        </section>
      )
    }

    return (
      <section className="ratings-applicant-view">
        {ratingNoticeNode}
        {ratingStarted && (
          <div className="ratings-started-banner">
            Rating started for {selectedApplicant.name || 'this applicant'}.
          </div>
        )}
        <div className="ratings-top-actions">
          <button
            type="button"
            className="ratings-start-btn"
            onClick={() => {
              setSelectedApplicant(null)
              setRatingStarted(false)
              setRatingScores({})
              setDemonstrationDetails(demonstrationDetailDefaults)
              setRatingRemarks('')
              setSelectedBoardMember('')
              setSelectedBoardType(getDefaultBoardType(currentUser))
              setRatingFormType('interview')
            }}
          >
            Back to Ratings
          </button>
          <button
            type="button"
            className="ratings-start-btn"
            onClick={() => {
              setRatingFormType('interview')
              setRatingScores({})
              setDemonstrationDetails(demonstrationDetailDefaults)
              setRatingRemarks('')
              setSelectedBoardMember('')
              setSelectedBoardType(getDefaultBoardType(currentUser))
              setRatingStarted(true)
            }}
          >
            Start Interview Rating
          </button>
          <button
            type="button"
            className="ratings-start-btn ratings-start-demo-btn"
            onClick={() => {
              setRatingFormType('demonstration')
              setRatingScores({})
              setDemonstrationDetails(demonstrationDetailDefaults)
              setRatingRemarks('')
              setSelectedBoardMember('')
              setSelectedBoardType(getDefaultBoardType(currentUser))
              setRatingStarted(true)
            }}
          >
            Start Demonstration
          </button>
        </div>
        <div className="ratings-result-grid">
          {[
            ['interview', 'Interview Rating', interviewStats],
            ['demonstration', 'Demonstration Rating', demonstrationStats]
          ].map(([formType, title, stats]) => (
            <section key={formType} className={`ratings-result-card ${formType}`}>
              <div>
                <h3>{title}</h3>
                <p>
                  {stats.count
                    ? `${stats.count} board member${stats.count === 1 ? '' : 's'} rated this ${formType}.`
                    : `No board member has rated this ${formType} yet.`}
                </p>
              </div>
              <div className="ratings-result-score">
                <span>Total Score</span>
                <strong>{stats.label}</strong>
              </div>
              {stats.ratings.length > 0 && (
                <div className="ratings-rater-list">
                  {stats.ratings.map((rating) => {
                    const raterName = rating.raterName || rating.rater_name || 'Board member'
                    return (
                      <button
                        key={rating.id}
                        type="button"
                        className={`ratings-rater-chip ${formType}`}
                        onClick={() => {
                          setRatingFormType(formType)
                          setRatingScores(rating.scores || {})
                          setDemonstrationDetails(demonstrationDetailDefaults)
                          setRatingRemarks(rating.remarks || '')
                          setSelectedBoardMember(raterName)
                          setSelectedBoardType(getDefaultBoardType(currentUser))
                          setRatingStarted(true)
                        }}
                      >
                        {raterName} · {Number(rating.totalScore ?? rating.total_score ?? 0)}/{getSavedMaxScore(rating)} · {Number(rating.percentageScore ?? rating.percentage_score ?? 0).toFixed(0)}%
                      </button>
                    )
                  })}
                </div>
              )}
            </section>
          ))}
        </div>
        <section className="ratings-interview-summary" aria-label="Interview schedule summary">
          <div>
            <h3>Interview Schedule</h3>
            <p>{interviewPreparationNotes || 'No preparation notes added yet.'}</p>
          </div>
          <dl>
            <div>
              <dt>Date</dt>
              <dd>{scheduledInterviewDate}</dd>
            </div>
            <div>
              <dt>Time</dt>
              <dd>{interviewTime}</dd>
            </div>
            <div>
              <dt>Place</dt>
              <dd>{interviewPlace || '-'}</dd>
            </div>
          </dl>
        </section>
        <section className="ratings-interview-summary demonstration" aria-label="Demonstration schedule summary">
          <div>
            <h3>Demonstration Schedule</h3>
            <p>{demonstrationPreparationNotes || 'No preparation notes added yet.'}</p>
          </div>
          <dl>
            <div>
              <dt>Date</dt>
              <dd>{demonstrationDate}</dd>
            </div>
            <div>
              <dt>Time</dt>
              <dd>{demonstrationTime}</dd>
            </div>
            <div>
              <dt>Place</dt>
              <dd>{demonstrationPlace || '-'}</dd>
            </div>
          </dl>
        </section>
        <ApplicantViewPage
          viewItem={selectedApplicant}
          onBack={null}
        />
      </section>
    )
  }

    return (
      <section className="ratings-page" aria-label="Ratings / Evaluation">
      {ratingNoticeNode}
      {ratingConfirmNode}
      {interviewDateNode}
      {demonstrationDateNode}
      {examinationNode}
      <div className="ratings-header">
        <div>
          <h2>Ratings / Evaluation</h2>
        </div>
        <button type="button" className="ratings-edit-criteria-btn" onClick={openCriteriaEditor}>
          Edit Criteria
        </button>
      </div>

      <div className="ratings-toolbar">
        <div className="ratings-search-wrap">
          <span className="ratings-search-icon" aria-hidden="true" />
          <input
            className="ratings-search"
            type="text"
            placeholder="Search applicant..."
            value={searchTerm}
            onChange={(event) => setSearchTerm(event.target.value)}
          />
        </div>
        <select
          className="ratings-position-select"
          value={positionFilter}
          onChange={(event) => setPositionFilter(event.target.value)}
        >
          {positionOptions.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        <button type="button" className="ratings-export-btn" onClick={exportRatingsOverallSummary}>
          Export Excel
        </button>
      </div>

      <div className="ratings-table-shell">
        <div className="ratings-table-scroll">
          <table className="ratings-table">
            <thead>
              <tr>
                <th>#</th>
                <th>Applicants Name</th>
                <th>Position Applied</th>
                <th>Date of Interview</th>
                <th>Date of Demo</th>
                <th>Exam Score</th>
                <th>Status</th>
                <th>Score</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr>
                  <td colSpan={9} className="ratings-empty">
                    <span className="loading-indicator"><span className="loading-spinner" aria-hidden="true" />Loading applicants...</span>
                  </td>
                </tr>
              ) : filteredUploads.length === 0 ? (
                <tr>
                  <td colSpan={9} className="ratings-empty">No applicants found.</td>
                </tr>
              ) : (
                paginatedUploads.map((item, index) => (
                  <tr
                    key={item.id || `${item.email}-${index}`}
                    className="ratings-clickable-row"
                    role="button"
                    tabIndex={0}
                    onClick={() => openApplicantView(item)}
                    onKeyDown={(event) => {
                      if (event.key === 'Enter' || event.key === ' ') {
                        event.preventDefault()
                        openApplicantView(item)
                      }
                    }}
                  >
                    <td>{((applicantsPage - 1) * applicantsPageSize) + index + 1}</td>
                    <td className="ratings-name">{item.name || '(No name)'}</td>
                    <td>{getPosition(item)}</td>
                    <td>{formatInterviewDate(getInterviewDateValue(item))}</td>
                    <td>{formatInterviewDate(getDemonstrationDateValue(item))}</td>
                    <td>{getExaminationScoreLabel(item)}</td>
                    <td>
                      <span className={`ratings-status ${getEvaluationStatus(item)}`}>
                        {getEvaluationStatusLabel(item)}
                      </span>
                    </td>
                    <td>
                      <span className={`ratings-score-chip ${(item.ratingCount || item.rating_count) ? 'has-rating' : ''}`}>
                        {item.ratingLabel || item.rating_label || 'No rating'}
                      </span>
                    </td>
                    <td className="ratings-action-cell">
                      <button
                        type="button"
                        className="action-btn action-trigger"
                        aria-label={`Open actions for ${item.name || 'applicant'}`}
                        onClick={(event) => {
                          event.stopPropagation()
                          if (actionsMenu?.item?.id === item.id) {
                            setActionsMenu(null)
                            return
                          }
                          openActionsMenu(event, item)
                        }}
                      >
                        ...
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        {filteredUploads.length > applicantsPageSize && (
          <div className="ratings-table-pager ratings-applicants-pager">
            <span>Page {applicantsPage} of {applicantsPageCount}</span>
            <div>
              <button
                type="button"
                onClick={() => setApplicantsPage((page) => Math.max(1, page - 1))}
                disabled={applicantsPage === 1}
              >
                Previous
              </button>
              <button
                type="button"
                onClick={() => setApplicantsPage((page) => Math.min(applicantsPageCount, page + 1))}
                disabled={applicantsPage === applicantsPageCount}
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>

      <p className="ratings-count">
        Showing {applicantsStart}-{applicantsEnd} of {filteredUploads.length} entries
      </p>

      {actionsMenu && (
        <div
          className="actions-menu actions-menu-floating"
          style={{ top: `${actionsMenu.top}px`, left: `${actionsMenu.left}px` }}
          onClick={(event) => event.stopPropagation()}
        >
          <button
            type="button"
            className="actions-menu-item"
            onClick={() => openApplicantView(actionsMenu.item)}
          >
            View
          </button>
          <button
            type="button"
            className="actions-menu-item"
            disabled={!String(actionsMenu.item?.email || '').trim()}
            onClick={() => {
              const target = actionsMenu.item
              setActionsMenu(null)
              emailApplicant(target)
            }}
          >
            Send Email
          </button>
          <button
            type="button"
            className="actions-menu-item"
            onClick={() => openInterviewDateModal(actionsMenu.item)}
          >
            Set Interview Date
          </button>
          <button
            type="button"
            className="actions-menu-item"
            onClick={() => openDemonstrationDateModal(actionsMenu.item)}
          >
            Set Demo Date
          </button>
          <button
            type="button"
            className="actions-menu-item"
            onClick={() => openExaminationModal(actionsMenu.item)}
          >
            Add Examination Score
          </button>
          {hasSavedFormRating(actionsMenu.item, 'interview') && (
            <button
              type="button"
              className="actions-menu-item"
              onClick={() => exportRatingSummary(actionsMenu.item)}
            >
              Export Interview Excel
            </button>
          )}
          {hasSavedFormRating(actionsMenu.item, 'demonstration') && (
            <button
              type="button"
              className="actions-menu-item"
              onClick={() => exportDemonstrationSummary(actionsMenu.item)}
            >
              Export Demonstration Excel
            </button>
          )}
          <button
            type="button"
            className="actions-menu-item danger"
            onClick={() => openCancelConfirmation(actionsMenu.item)}
          >
            {isRatedApplicant(actionsMenu.item) ? 'Delete' : 'Cancel Interview'}
          </button>
        </div>
      )}
    </section>
  )
}

export default RatingsPage
