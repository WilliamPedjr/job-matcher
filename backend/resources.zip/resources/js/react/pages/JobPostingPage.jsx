import React from 'react'
import { useEffect, useMemo, useRef, useState } from 'react'
import '../styles/JobPostingPage.css'
import CustomDropdown from '../components/CustomDropdown'
import { getArchiveActorHeaders } from '../utils/archiveActor'

const defaultJobEligibility = "Open to all qualified applicants"
const otherEligibilityOption = "Other Eligibility"
const jobEligibilityLabels = [
  defaultJobEligibility,
  "Career Service Eligibility - Preference Rating (CSE-PR)",
  "Career Service Eligibility - Sub Professional (CSE-Sub)",
  "Career Service Eligibility - Professional (CSE-Prof)",
  "Bar/Board Eligibility (RA 1080)",
  "Barangay Health Worker Eligibility (RA 7883)",
  "Barangay Nutrition Scholar Eligibility (PD 1569)",
  "Barangay Official Eligibility (RA 7160)",
  "Electronic Data Processing Specialist Eligibility (CSC Res. 90-083)",
  "Foreign School Honor Graduate Eligibility (CSC Res. 1302714)",
  "Honor Graduate Eligibility (PD 907)",
  "Sanggunian Member Eligibility (RA 10156)",
  "Scientific and Technological Specialist Eligibility (PD 997)",
  "Skills Eligibility - Category II (CSC MC 11, s. 1996, as Amended)",
  "Veteran Preference Rating (EO 132/790)",
  otherEligibilityOption
]
const jobEligibilityOptions = jobEligibilityLabels.map((eligibility) => ({ value: eligibility, label: eligibility }))
const defaultScoringWeights = {
  skills: "20",
  training: "20",
  education: "20",
  experience: "20",
  eligibility: "20"
}
const scoringCriteria = [
  { key: "skills", label: "Skills" },
  { key: "training", label: "Training" },
  { key: "education", label: "Education" },
  { key: "experience", label: "Experience" },
  { key: "eligibility", label: "Eligibility" }
]

const scoringWeightsFromRecord = (record = {}) => ({
  skills: String(record.skillsWeight ?? record.skills_weight ?? defaultScoringWeights.skills),
  training: String(record.trainingWeight ?? record.training_weight ?? defaultScoringWeights.training),
  education: String(record.educationWeight ?? record.education_weight ?? defaultScoringWeights.education),
  experience: String(record.experienceWeight ?? record.experience_weight ?? defaultScoringWeights.experience),
  eligibility: String(record.eligibilityWeight ?? record.eligibility_weight ?? defaultScoringWeights.eligibility)
})

const resolveJobEligibilitySelection = (value) => {
  const cleaned = String(value || "").trim()
  if (!cleaned) {
    return { selected: defaultJobEligibility, custom: "" }
  }
  if (jobEligibilityLabels.includes(cleaned)) {
    return { selected: cleaned, custom: "" }
  }
  return { selected: otherEligibilityOption, custom: cleaned }
}

function getApplicationStatus(item) {
  const status = String(item?.application_status || item?.applicationStatus || item?.evaluation_status || item?.evaluationStatus || "")
    .trim()
    .toLowerCase()
  if (status === "for_evaluation") return "interview"
  if (status === "rated") return "hired"
  return ["pending", "reviewed", "shortlisted", "interview", "rejected", "hired", "cancelled"].includes(status) ? status : "pending"
}

function getApplicationStatusLabel(item) {
  return getApplicationStatus(item)
    .split("-")
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ")
}

function JobPostingPage({ uploads = [], isEmployer = false, isJobSeeker = false, currentUser = null, jobSeekerId, jobSeekerResume, onViewApplicant, onDeleteApplicant, onJobsChanged, onViewJob }) {
  const JOB_FORM_DRAFT_KEY = "lnu-hire-job-form-draft"
  const [jobs, setJobs] = useState([])
  const [templates, setTemplates] = useState([])
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [jobPositionTypeFilter, setJobPositionTypeFilter] = useState("all")
  const [matchFilter, setMatchFilter] = useState("all")
  const [jobsViewMode, setJobsViewMode] = useState("table")
  const [cardPage, setCardPage] = useState(1)
  const [tablePage, setTablePage] = useState(1)
  const [selectedJobTitle, setSelectedJobTitle] = useState("")
  const [modalSortConfig, setModalSortConfig] = useState({ key: "date", direction: "desc" })
  const [actionsJobId, setActionsJobId] = useState(null)
  const [actionsJobMenu, setActionsJobMenu] = useState(null)
  const [isPositioningJobActionsMenu, setIsPositioningJobActionsMenu] = useState(false)
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  const [editingJobId, setEditingJobId] = useState(null)
  const [newJobTitle, setNewJobTitle] = useState("")
  const [newJobDescription, setNewJobDescription] = useState("")
  const [newJobDepartment, setNewJobDepartment] = useState("")
  const [newJobPositionType, setNewJobPositionType] = useState("Teaching")
  const [newJobItemNo, setNewJobItemNo] = useState("")
  const [newJobLocation, setNewJobLocation] = useState("Leyte Normal University")
  const [isJobPositionOpen, setIsJobPositionOpen] = useState(false)
  const [isDepartmentOpen, setIsDepartmentOpen] = useState(false)
  const [expandedDepartments, setExpandedDepartments] = useState({})
  const defaultJobLocation = "Leyte Normal University"
  const [newJobType, setNewJobType] = useState("Full-time")
  const [newJobStatus, setNewJobStatus] = useState("active")
  const [newJobDeadline, setNewJobDeadline] = useState("")
  const [newJobEligibility, setNewJobEligibility] = useState(defaultJobEligibility)
  const [newJobCustomEligibility, setNewJobCustomEligibility] = useState("")
  const [newRequiredSkills, setNewRequiredSkills] = useState("")
  const [newUniversalMatchMode, setNewUniversalMatchMode] = useState("")
  const [newMinimumEducation, setNewMinimumEducation] = useState("Bachelor's Degree")
  const [newMinimumExperienceYears, setNewMinimumExperienceYears] = useState("0")
  const [newApplicationThresholdScore, setNewApplicationThresholdScore] = useState("50")
  const [newScoringWeights, setNewScoringWeights] = useState(defaultScoringWeights)
  const [newSalaryMin, setNewSalaryMin] = useState("")
  const [newSalaryMax, setNewSalaryMax] = useState("")
  const [newPositionsTotal, setNewPositionsTotal] = useState("1")
  const [isCreatingJob, setIsCreatingJob] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [createJobStatus, setCreateJobStatus] = useState("")
  const [createJobNotice, setCreateJobNotice] = useState("")
  const [showJobFormErrors, setShowJobFormErrors] = useState(false)
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const [isSkillsOpen, setIsSkillsOpen] = useState(false)
  const [skillDraft, setSkillDraft] = useState("")
  const [confirmDeleteJobId, setConfirmDeleteJobId] = useState(null)
  const [hasSavedJobDraft, setHasSavedJobDraft] = useState(false)
  const [isUsingSavedJobDraft, setIsUsingSavedJobDraft] = useState(false)
  const [jobMatches, setJobMatches] = useState({})
  const [jobMatchStatus, setJobMatchStatus] = useState("idle")
  const [jobSkillCatalog, setJobSkillCatalog] = useState([])
  const [jobSkillStatus, setJobSkillStatus] = useState("idle")
  const [globalSkillCatalog, setGlobalSkillCatalog] = useState([])
  const [globalSkillStatus, setGlobalSkillStatus] = useState("idle")
  const [templateSkillCatalog, setTemplateSkillCatalog] = useState([])
  const [templateSkillStatus, setTemplateSkillStatus] = useState("idle")
  const [deleteToast, setDeleteToast] = useState(null)
  const deleteToastTimerRef = useRef(null)
  const isEditingJob = editingJobId != null
  const scoringTotal = scoringCriteria.reduce((sum, item) => sum + (Number(newScoringWeights[item.key]) || 0), 0)
  const scoringTotalIsValid = scoringTotal <= 100
  const CARD_PAGE_SIZE = 6
  const TABLE_PAGE_SIZE = 10
  const descriptionRef = useRef(null)
  const createJobModalRef = useRef(null)
  const jobPositionRef = useRef(null)
  const departmentRef = useRef(null)
  const skillsPickerRef = useRef(null)
  const skipTemplateApplyRef = useRef(false)

  useEffect(() => {
    if (!createJobStatus) return
    const timer = setTimeout(() => {
      setCreateJobStatus("")
      setCreateJobNotice("")
    }, 2600)
    return () => clearTimeout(timer)
  }, [createJobStatus])

  useEffect(() => {
    return () => {
      if (deleteToastTimerRef.current) {
        window.clearTimeout(deleteToastTimerRef.current)
      }
    }
  }, [])

  useEffect(() => {
    try {
      setHasSavedJobDraft(Boolean(window.localStorage.getItem(JOB_FORM_DRAFT_KEY)))
    } catch {
      setHasSavedJobDraft(false)
    }
  }, [])

  useEffect(() => {
    if (!descriptionRef.current) return
    descriptionRef.current.style.height = "auto"
    descriptionRef.current.style.height = `${descriptionRef.current.scrollHeight}px`
  }, [newJobDescription, isCreateModalOpen])

  const showCreateJobNotice = (status, notice) => {
    setCreateJobStatus(status)
    setCreateJobNotice(notice)
  }

  const requiredInputClass = (value, extraClass = "") => {
    const isMissing = String(value ?? "").trim() === ""
    return `input ${extraClass} ${showJobFormErrors && isMissing ? "is-invalid" : ""}`.trim()
  }

  const requiredDropdownClass = (value, extraClass = "input-dropdown") => {
    const isMissing = String(value ?? "").trim() === ""
    return `${extraClass} ${showJobFormErrors && isMissing ? "is-invalid" : ""}`.trim()
  }

  const scrollCreateJobModalToTop = () => {
    window.requestAnimationFrame(() => {
      createJobModalRef.current?.scrollTo({ top: 0, behavior: "smooth" })
    })
  }

  const apiErrorMessage = (payload, fallback) => {
    const firstError = payload?.errors && Object.values(payload.errors)
      .flat()
      .find(Boolean)
    return firstError || payload?.message || fallback
  }

  const classificationLabel = (value, fallback = "Not Qualified") => {
    const label = String(value || "").trim()
    if (!label) return fallback
    return label.toLowerCase().includes("lowly") ? "Not Qualified" : label
  }

  const integerInputValue = (value) => String(value ?? "").replace(/\D/g, "")
  const integerRecordValue = (value) => {
    const text = String(value ?? "").trim()
    return /^\d+$/.test(text) ? text : ""
  }
  const isManySlotsRecord = (record = {}) => {
    const rawTotal = record.positionsTotal ?? record.positions_total
    return Boolean(record.positionsMany ?? record.positions_many) || Number(rawTotal) === 0
  }
  const positionsTotalFormValue = (value, record = {}) => {
    const text = String(value ?? "").trim().toLowerCase()
    if (text === "many" || text === "unlimited" || isManySlotsRecord(record)) {
      return "many"
    }
    return integerRecordValue(value) || "1"
  }
  const isManySlotsValue = (value) => String(value ?? "").trim().toLowerCase() === "many"
  const getPositionsPayloadValue = () => (isManySlotsValue(newPositionsTotal) ? 0 : Number(newPositionsTotal))
  const getJobAvailableSlotsLabel = (job = {}) => {
    if (isManySlotsRecord(job)) return "Many"
    const value = Number(job.positionsAvailable ?? job.positions_available ?? job.positionsTotal ?? job.positions_total ?? 1)
    return String(Math.max(0, value))
  }
  const getJobAvailableSlotsText = (job = {}) => {
    const label = getJobAvailableSlotsLabel(job)
    return label === "Many" ? "Many slots" : `${label} slots left`
  }

  const showDeleteToast = (message, type = "success", duration = 2600) => {
    if (deleteToastTimerRef.current) {
      window.clearTimeout(deleteToastTimerRef.current)
      deleteToastTimerRef.current = null
    }
    setDeleteToast({ message, type })
    if (duration > 0) {
      deleteToastTimerRef.current = window.setTimeout(() => {
        setDeleteToast(null)
        deleteToastTimerRef.current = null
      }, duration)
    }
  }

  const normalizeSalaryRange = (minValue, maxValue) => {
    if (maxValue < minValue) {
      return { salaryMin: minValue, salaryMax: minValue }
    }
    return { salaryMin: minValue, salaryMax: maxValue }
  }

  const fetchJobs = async ({ silent = false } = {}) => {
    if (!silent) {
      setIsLoading(true)
    }
    setError("")
    try {
      const response = await fetch("http://localhost:5000/jobs")
      if (!response.ok) {
        throw new Error("Failed to load jobs.")
      }
      const data = await response.json()
      setJobs(Array.isArray(data) ? data : [])
    } catch (err) {
      setError(err.message || "Could not fetch job postings.")
    } finally {
      if (!silent) {
        setIsLoading(false)
      }
    }
  }

  const fetchTemplates = async () => {
    try {
      const response = await fetch("http://localhost:5000/job-templates")
      if (!response.ok) {
        throw new Error("Failed to load templates.")
      }
      const data = await response.json()
      setTemplates(Array.isArray(data) ? data : [])
    } catch {
      setTemplates([])
    }
  }

  useEffect(() => {
    fetchJobs()
    fetchTemplates()
  }, [])

  useEffect(() => {
    if (actionsJobId == null) return
    const closeMenu = () => {
      setActionsJobId(null)
      setActionsJobMenu(null)
      setIsPositioningJobActionsMenu(false)
    }
    const onDocClick = () => closeMenu()
    const onScrollOrResize = () => closeMenu()
    document.addEventListener("click", onDocClick)
    document.addEventListener("scroll", onScrollOrResize, true)
    window.addEventListener("resize", onScrollOrResize)
    return () => {
      document.removeEventListener("click", onDocClick)
      document.removeEventListener("scroll", onScrollOrResize, true)
      window.removeEventListener("resize", onScrollOrResize)
    }
  }, [actionsJobId])

  const getJobActionsMenuPosition = (button) => {
    const rect = button.getBoundingClientRect()
    const menuWidth = 168
    const viewportWidth = window.innerWidth || document.documentElement.clientWidth

    return {
      top: rect.bottom + 8,
      left: Math.min(
        Math.max(12, rect.left),
        Math.max(12, viewportWidth - menuWidth - 12)
      )
    }
  }

  const openJobActionsMenu = (event, job, actionKey) => {
    event.stopPropagation()
    if (actionsJobId === actionKey) {
      setActionsJobId(null)
      setActionsJobMenu(null)
      setIsPositioningJobActionsMenu(false)
      return
    }

    const button = event.currentTarget
    const menuHeight = job.source === "template" ? 48 : 176
    setActionsJobId(null)
    setActionsJobMenu(null)
    setIsPositioningJobActionsMenu(true)

    window.requestAnimationFrame(() => {
      const rect = button.getBoundingClientRect()
      const viewportHeight = window.innerHeight || document.documentElement.clientHeight
      const overflow = rect.bottom + 8 + menuHeight + 12 - viewportHeight
      const scrollContainer = button.closest(".page") || document.scrollingElement

      if (overflow > 0 && scrollContainer) {
        scrollContainer.scrollBy({ top: overflow, behavior: "auto" })
      }

      window.requestAnimationFrame(() => {
        setActionsJobId(actionKey)
        setActionsJobMenu({
          ...getJobActionsMenuPosition(button),
          job
        })
        setIsPositioningJobActionsMenu(false)
      })
    })
  }

  useEffect(() => {
    if (!selectedJobTitle) {
      return
    }

    setActionsJobId(null)
    setActionsJobMenu(null)
    setIsPositioningJobActionsMenu(false)
  }, [selectedJobTitle])

  useEffect(() => {
    if (!isJobPositionOpen) return
    const onDocClick = (event) => {
      if (!jobPositionRef.current) return
      if (!jobPositionRef.current.contains(event.target)) {
        setIsJobPositionOpen(false)
      }
    }
    document.addEventListener("mousedown", onDocClick)
    return () => document.removeEventListener("mousedown", onDocClick)
  }, [isJobPositionOpen])

  useEffect(() => {
    if (!isDepartmentOpen) return
    const onDocClick = (event) => {
      if (!departmentRef.current) return
      if (!departmentRef.current.contains(event.target)) {
        setIsDepartmentOpen(false)
      }
    }
    document.addEventListener("mousedown", onDocClick)
    return () => document.removeEventListener("mousedown", onDocClick)
  }, [isDepartmentOpen])

  useEffect(() => {
    if (!isSkillsOpen) return
    const onDocClick = (event) => {
      if (!skillsPickerRef.current) return
      if (!skillsPickerRef.current.contains(event.target)) {
        setIsSkillsOpen(false)
      }
    }
    document.addEventListener("mousedown", onDocClick)
    return () => document.removeEventListener("mousedown", onDocClick)
  }, [isSkillsOpen])

  useEffect(() => {
    if (isJobSeeker && isCreateModalOpen) {
      setIsCreateModalOpen(false)
    }
  }, [isJobSeeker, isCreateModalOpen])

  useEffect(() => {
    if (isEditingJob) return
    const title = newJobTitle.trim()
    if (!title) {
      setTemplateSkillCatalog([])
      setTemplateSkillStatus("idle")
      return
    }
    let isMounted = true
    const controller = new AbortController()
    setTemplateSkillStatus("loading")
    const fetchCatalog = async () => {
      try {
        const response = await fetch(`http://localhost:5000/skills/catalog?title=${encodeURIComponent(title)}`, {
          signal: controller.signal
        })
        if (!response.ok) {
          throw new Error("Failed to load skill catalog.")
        }
        const payload = await response.json()
        if (!isMounted) return
        setTemplateSkillCatalog(Array.isArray(payload?.skills) ? payload.skills : [])
        setTemplateSkillStatus("ready")
      } catch (error) {
        if (!isMounted || error?.name === "AbortError") return
        setTemplateSkillCatalog([])
        setTemplateSkillStatus("error")
      }
    }
    fetchCatalog()
    return () => {
      isMounted = false
      controller.abort()
    }
  }, [isEditingJob, newJobTitle])

  useEffect(() => {
    let isMounted = true
    const controller = new AbortController()
    setGlobalSkillStatus("loading")
    const fetchGlobalSkills = async () => {
      try {
        const response = await fetch("http://localhost:5000/skills", { signal: controller.signal })
        if (!response.ok) {
          throw new Error("Failed to load skills.")
        }
        const payload = await response.json()
        if (!isMounted) return
        setGlobalSkillCatalog(Array.isArray(payload?.skills) ? payload.skills : [])
        setGlobalSkillStatus("ready")
      } catch (error) {
        if (!isMounted || error?.name === "AbortError") return
        setGlobalSkillCatalog([])
        setGlobalSkillStatus("error")
      }
    }
    fetchGlobalSkills()
    return () => {
      isMounted = false
      controller.abort()
    }
  }, [])

  useEffect(() => {
    if (!editingJobId) {
      setJobSkillCatalog([])
      setJobSkillStatus("idle")
      return
    }
    let isMounted = true
    const controller = new AbortController()
    setJobSkillStatus("loading")
    const fetchCatalog = async () => {
      try {
        const response = await fetch(`http://localhost:5000/jobs/${editingJobId}/skills`, {
          signal: controller.signal
        })
        if (!response.ok) {
          throw new Error("Failed to load job skills.")
        }
        const payload = await response.json()
        if (!isMounted) return
        setJobSkillCatalog(Array.isArray(payload?.skills) ? payload.skills : [])
        setJobSkillStatus("ready")
      } catch (error) {
        if (!isMounted || error?.name === "AbortError") return
        setJobSkillCatalog([])
        setJobSkillStatus("error")
      }
    }
    fetchCatalog()
    return () => {
      isMounted = false
      controller.abort()
    }
  }, [editingJobId])

  const listedJobs = useMemo(() => (
    jobs.length > 0
      ? jobs.map((item) => ({ ...item, source: "job" }))
      : templates.map((item) => ({ ...item, source: "template" }))
  ), [jobs, templates])

  useEffect(() => {
    if (!isJobSeeker || !jobSeekerId) {
      setJobMatches({})
      setJobMatchStatus("idle")
      return
    }
    if (!jobSeekerResume) {
      setJobMatches({})
      setJobMatchStatus("no-resume")
      return
    }
    if (!listedJobs.length) {
      setJobMatches({})
      setJobMatchStatus("idle")
      return
    }

    let isMounted = true
    const controller = new AbortController()
    setJobMatchStatus("loading")

    const fetchMatches = async () => {
      try {
        const matchJobs = listedJobs
          .map((job) => ({
            id: job.source === "job" ? job.id : null,
            title: String(job.title || "").trim()
          }))
          .filter((job) => job.title)

        const response = await fetch(
          `http://localhost:5000/job-seekers/${jobSeekerId}/resume/match/batch`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Accept": "application/json",
            },
            signal: controller.signal,
            body: JSON.stringify({
              jobTitles: matchJobs.map((job) => job.title),
              jobIds: matchJobs.map((job) => job.id)
            }),
          }
        )

        if (!response.ok) {
          throw new Error("Failed to check Personal Data Sheet(PDS) matches.")
        }

        const payload = await response.json()
        const results = Array.isArray(payload?.matches) ? payload.matches : []

        if (!isMounted) return
        const next = {}
        results.filter(Boolean).forEach((item) => {
          const key = String(item.key || "").trim().toLowerCase()
          if (!key) return
          const score = Number(item.score)
          const minimumScore = Number(item.minimumScore ?? 50)
          const normalizedMinimumScore = Number.isFinite(minimumScore) ? minimumScore : 50
          const normalizedScore = Number.isFinite(score) ? score : null
          next[key] = {
            score: normalizedScore,
            qualifies: normalizedScore != null ? normalizedScore >= normalizedMinimumScore : false,
            minimumScore: normalizedMinimumScore
          }
        })
        setJobMatches(next)
        setJobMatchStatus("ready")
      } catch (error) {
        if (error?.name === "AbortError") return
        if (!isMounted) return
        setJobMatches({})
        setJobMatchStatus("error")
      }
    }

    fetchMatches()
    return () => {
      isMounted = false
      controller.abort()
    }
  }, [isJobSeeker, jobSeekerId, jobSeekerResume, listedJobs])

  const filteredJobs = useMemo(() => {
    return listedJobs.filter((job) => {
      const query = searchTerm.trim().toLowerCase()
      const status = String(job.status || "active").toLowerCase()

      if (isJobSeeker && status === "closed") return false

      const matchesStatus = statusFilter === "all" ? true : status === statusFilter
      if (!matchesStatus) return false

      const jobPositionType = String(job.jobPosition || job.job_position || "").toLowerCase()
      const matchesJobPositionType = jobPositionTypeFilter === "all"
        ? true
        : jobPositionType === jobPositionTypeFilter
      if (!matchesJobPositionType) return false

      if (isJobSeeker && matchFilter !== "all") {
        const key = String(job.title || "").trim().toLowerCase()
        const match = key ? jobMatches[key] : null
        if (!match || match.score == null) return false
        if (matchFilter === "match" && !match.qualifies) return false
        if (matchFilter === "not-match" && match.qualifies) return false
      }

      if (!query) return true
      const haystack = `${job.title || ""} ${job.description || ""} ${job.department || ""} ${job.jobPosition || job.job_position || ""} ${job.itemNo || job.item_no || ""} ${job.location || ""} ${job.deadline || ""} ${job.eligibility || ""}`.toLowerCase()
      return haystack.includes(query)
    })
  }, [listedJobs, searchTerm, statusFilter, jobPositionTypeFilter, isJobSeeker, matchFilter, jobMatches])

  const fifoJobs = useMemo(() => {
    return [...filteredJobs].sort((a, b) => {
      const aId = Number(a.id)
      const bId = Number(b.id)
      if (Number.isFinite(aId) && Number.isFinite(bId)) {
        return aId - bId
      }
      if (Number.isFinite(aId)) return -1
      if (Number.isFinite(bId)) return 1
      return String(a.title || "").localeCompare(String(b.title || ""))
    })
  }, [filteredJobs])

  const cardPageCount = Math.max(1, Math.ceil(fifoJobs.length / CARD_PAGE_SIZE))
  const activeCardPage = Math.min(cardPage, cardPageCount)
  const cardStartIndex = (activeCardPage - 1) * CARD_PAGE_SIZE
  const cardPageJobs = useMemo(
    () => fifoJobs.slice(cardStartIndex, cardStartIndex + CARD_PAGE_SIZE),
    [fifoJobs, cardStartIndex]
  )
  const tablePageCount = Math.max(1, Math.ceil(fifoJobs.length / TABLE_PAGE_SIZE))
  const activeTablePage = Math.min(tablePage, tablePageCount)
  const tableStartIndex = (activeTablePage - 1) * TABLE_PAGE_SIZE
  const tablePageJobs = useMemo(
    () => fifoJobs.slice(tableStartIndex, tableStartIndex + TABLE_PAGE_SIZE),
    [fifoJobs, tableStartIndex]
  )

  useEffect(() => {
    setCardPage(1)
    setTablePage(1)
  }, [searchTerm, statusFilter, jobPositionTypeFilter, matchFilter, jobsViewMode])

  useEffect(() => {
    if (cardPage > cardPageCount) {
      setCardPage(cardPageCount)
    }
  }, [cardPage, cardPageCount])

  useEffect(() => {
    if (tablePage > tablePageCount) {
      setTablePage(tablePageCount)
    }
  }, [tablePage, tablePageCount])

  const normalizeJobPositionType = (value) => (
    String(value || "").trim().toLowerCase().replace(/\s+/g, "-")
  )

  const isTeachingJobPositionType = normalizeJobPositionType(newJobPositionType) === "teaching"

  const jobCategoryGroups = useMemo(() => {
    const map = new Map()
    const selectedType = normalizeJobPositionType(newJobPositionType)
    const sourceJobs = [...templates, ...listedJobs]
    sourceJobs.forEach((item) => {
      const itemType = normalizeJobPositionType(item.jobPosition || item.job_position)
      if (selectedType && itemType !== selectedType) return
      const title = String(item.title || "").trim()
      if (!title) return
      const department = String(item.department || "Other").trim() || "Other"
      if (!map.has(department)) {
        map.set(department, new Set())
      }
      map.get(department).add(title)
    })
    return Array.from(map.entries())
      .map(([department, titles]) => ({
        department,
        titles: Array.from(titles).sort((a, b) => a.localeCompare(b))
      }))
      .sort((a, b) => a.department.localeCompare(b.department))
  }, [isTeachingJobPositionType, listedJobs, newJobPositionType, templates])

  const departmentSuggestions = useMemo(() => {
    return jobCategoryGroups.map((group) => group.department)
  }, [jobCategoryGroups])

  const filteredDepartmentSuggestions = useMemo(() => {
    const query = newJobDepartment.trim().toLowerCase()
    if (!query) return departmentSuggestions
    return departmentSuggestions.filter((department) => department.toLowerCase().includes(query))
  }, [departmentSuggestions, newJobDepartment])

  const filteredJobCategoryGroups = useMemo(() => {
    const query = newJobTitle.trim().toLowerCase()
    const departmentKey = newJobDepartment.trim().toLowerCase()
    if (!departmentKey) return []
    const groups = jobCategoryGroups.filter((group) => group.department.toLowerCase() === departmentKey)
    if (!query) return groups
    return groups
      .map((group) => ({
        department: group.department,
        titles: group.titles.filter((title) => title.toLowerCase().includes(query))
      }))
      .filter((group) => group.titles.length > 0)
  }, [jobCategoryGroups, newJobDepartment, newJobTitle])

  const jobTitleSuggestions = useMemo(() => (
    filteredJobCategoryGroups.flatMap((group) => (
      group.titles.map((title) => ({ department: group.department, title }))
    ))
  ), [filteredJobCategoryGroups])

  const jobPositionLabel = useMemo(() => {
    if (!newJobTitle) return ""
    return newJobTitle
  }, [newJobTitle])

  const searchSuggestions = useMemo(() => {
    const tokens = [
      ...jobs.map((job) => String(job.title || "").trim()),
      ...jobs.map((job) => String(job.department || "").trim()),
      ...jobs.map((job) => String(job.jobPosition || job.job_position || "").trim()),
      ...jobs.map((job) => String(job.itemNo || job.item_no || "").trim()),
      ...jobs.map((job) => String(job.location || "").trim())
    ].filter(Boolean)
    return Array.from(new Set(tokens))
  }, [jobs])

  const parseSkills = (value) => {
    if (!value) return []
    if (Array.isArray(value)) {
      return value.map((item) => String(item).trim()).filter(Boolean)
    }

    const normalized = String(value).trim()
    if (!normalized) return []

    if (normalized.startsWith("[") && normalized.endsWith("]")) {
      try {
        const parsed = JSON.parse(normalized)
        if (Array.isArray(parsed)) {
          return parsed.map((item) => String(item).trim()).filter(Boolean)
        }
      } catch {
        // Fall back to delimiter parsing.
      }
    }

    return normalized
      .split(/[,;\n|]+/)
      .map((item) => item.trim())
      .filter(Boolean)
  }

  const templateByTitle = useMemo(() => {
    const map = new Map()
    const candidates = [
      ...templates.map((item) => ({ ...item, source: "template" })),
      ...listedJobs
    ]
    candidates.forEach((item) => {
      const title = String(item.title || "").trim()
      if (!title) return
      const key = title.toLowerCase()
      if (map.has(key)) return
      map.set(key, item)
    })
    return map
  }, [listedJobs, templates])

  const allSkillSuggestions = useMemo(() => {
    const collected = [
      ...listedJobs.map((job) => job.requiredSkills)
    ]
      .flatMap((text) => parseSkills(text))
      .filter(Boolean)
    return Array.from(new Set(collected)).sort((a, b) => a.localeCompare(b))
  }, [listedJobs])

  const templateSkills = useMemo(() => {
    const key = newJobTitle.trim().toLowerCase()
    if (!key) return []
    const matched = templateByTitle.get(key)
    return parseSkills(matched?.requiredSkills || "")
  }, [newJobTitle, templateByTitle])

  const degreeMap = useMemo(() => ({
    "Chief Administrative Officer": { bachelor: "Bachelor's Degree relevant to the job with Master's Degree", master: "Master's Degree relevant to the job" },
    "Administrative Officer III": { bachelor: "Bachelor's Degree relevant to the job", master: "Master's Degree relevant to the job" },
    "Senior Administrative Assistant I": { bachelor: "Completion of two years studies in college", master: "Bachelor's Degree" },
    "Accountant I": { bachelor: "BS Accountancy", master: "Master's Degree in Accountancy" },
    "Administrative Officer II": { bachelor: "Bachelor's Degree relevant to the job", master: "Master's Degree relevant to the job" },
    "Administrative Officer I": { bachelor: "Bachelor's Degree relevant to the job", master: "Master's Degree relevant to the job" },
    "Administrative Aide III (Utility Worker II A)": { bachelor: "Must be able to read and write", master: "High School Graduate" },
    "English Instructor": { bachelor: "BSEd major in English", master: "Master's Degree in English Education" },
    "Math Instructor": { bachelor: "BSEd major in Mathematics", master: "Master's Degree in Mathematics Education" },
    "Social Studies Instructor": { bachelor: "BSEd major in Social Studies", master: "Master's Degree in Social Studies Education" },
    "Values Education Instructor": { bachelor: "BSEd major in Values Education", master: "Master's Degree in Values Education" },
    "Professional Education Instructor": { bachelor: "Education Graduate", master: "Master's Degree in Education" },
    "Special Needs Education Instructor": { bachelor: "BSEd major in Special Needs Education", master: "Master's Degree in Special Needs Education" },
    "Technology and Livelihood Education Instructor": { bachelor: "BSEd major in TLE", master: "Master's Degree in TLE" },
    "Tourism Management Instructor": { bachelor: "BS Tourism Management", master: "Master's Degree in Tourism Management" },
    "Hospitality Management Instructor": { bachelor: "BS Hospitality Management", master: "Master's Degree in Hospitality Management" },
    "Entrepreneurship Instructor": { bachelor: "BS Entrepreneurship", master: "Master's Degree in Entrepreneurship" },
    "Biotechnology Instructor": { bachelor: "BS Biology", master: "Master's Degree in Biology" },
    "Social Work Instructor": { bachelor: "BS Social Work", master: "Master's Degree in Social Work" },
    "English Language Instructor": { bachelor: "BA English Language", master: "Master's Degree in English Language" },
    "Faculty Member - Environmental Biology": { bachelor: "BS Biology", master: "Master's Degree in Biology" },
    "Faculty Member - Medical Biology": { bachelor: "BS Biology", master: "Master's Degree in Medical Biology" },
    "Faculty Member - Chemistry": { bachelor: "BS Chemistry", master: "Master's Degree in Chemistry" },
    "Instructor": { bachelor: "Bachelor's Degree in Education", master: "Master's Degree in Education" }
  }), [])

  const educationMapping = useMemo(() => {
    const title = String(newJobTitle || "").trim()
    if (!title) return null
    let mapping = degreeMap[title]
    if (!mapping && /instructor/i.test(title)) {
      mapping = degreeMap["Instructor"]
    }
    return mapping || null
  }, [newJobTitle, degreeMap])

  const educationOptions = useMemo(() => {
    const extraEducationOptions = [
      { value: "College Graduate", label: "College Graduate" },
      { value: "High School Graduate", label: "High School Graduate" },
      { value: "Doctorate", label: "Doctorate" },
      { value: "Researcher", label: "Researcher" },
      { value: "Not Graduate", label: "Not Graduate" }
    ]

    if (!educationMapping) {
      return [
        { value: "Bachelor's Degree", label: "Bachelor's Degree" },
        { value: "Master's Degree", label: "Master's Degree" },
        ...extraEducationOptions
      ]
    }
    return [
      { value: educationMapping.bachelor, label: educationMapping.bachelor },
      { value: educationMapping.master, label: educationMapping.master },
      ...extraEducationOptions
    ]
  }, [educationMapping])

  useEffect(() => {
    if (!educationMapping) return
    const current = String(newMinimumEducation || "")
    const isGeneric = current === "Bachelor's Degree" || current === "Master's Degree" || !current
    if (isGeneric) {
      setNewMinimumEducation(educationMapping.bachelor)
    }
  }, [educationMapping, newMinimumEducation])

  const filteredSkillSuggestions = useMemo(() => {
    const existing = new Set(parseSkills(newRequiredSkills).map((item) => item.toLowerCase()))
    const templatePool = templateSkillCatalog.length ? templateSkillCatalog : templateSkills
    const contextualPool = isEditingJob ? jobSkillCatalog : templatePool
    const pool = Array.from(new Set([...contextualPool, ...allSkillSuggestions]))
      .filter((skill) => !existing.has(String(skill).toLowerCase()))
    if (!pool.length) return []
    const query = String(skillDraft || "").trim().toLowerCase()
    if (!query) return pool
    return pool
      .filter((skill) => skill.toLowerCase().includes(query))
      .slice(0)
  }, [newRequiredSkills, isEditingJob, jobSkillCatalog, templateSkills, templateSkillCatalog, allSkillSuggestions, skillDraft])

  const selectedRequiredSkills = useMemo(() => parseSkills(newRequiredSkills), [newRequiredSkills])

  const addRequiredSkill = (rawSkill) => {
    const skill = String(rawSkill || "").trim()
    if (!skill) return
    const current = parseSkills(newRequiredSkills)
    const exists = current.some((item) => item.toLowerCase() === skill.toLowerCase())
    if (exists) {
      setSkillDraft("")
      return
    }
    setNewRequiredSkills([...current, skill].join(", "))
    setSkillDraft("")
    setIsSkillsOpen(false)
  }

  const removeRequiredSkill = (skillToRemove) => {
    const next = parseSkills(newRequiredSkills).filter((item) => item !== skillToRemove)
    setNewRequiredSkills(next.join(", "))
  }

  const filteredSearchSuggestions = useMemo(() => {
    const query = searchTerm.trim().toLowerCase()
    if (!query) return searchSuggestions.slice(0, 8)
    return searchSuggestions
      .filter((token) => token.toLowerCase().includes(query))
      .slice(0, 8)
  }, [searchSuggestions, searchTerm])

  const handleJobPositionTypeChange = (nextType) => {
    const nextTypeKey = normalizeJobPositionType(nextType)
    const selectedTemplate = templateByTitle.get(newJobTitle.trim().toLowerCase())
    const selectedTemplateTypeKey = normalizeJobPositionType(selectedTemplate?.jobPosition || selectedTemplate?.job_position)
    setNewJobPositionType(nextType)
    setExpandedDepartments({})
    setIsJobPositionOpen(false)
    setIsDepartmentOpen(false)

    if (newJobTitle.trim() && selectedTemplateTypeKey && selectedTemplateTypeKey !== nextTypeKey) {
      setNewJobTitle("")
      setNewJobDepartment("")
      setNewJobItemNo("")
    }
  }

  const handleSelectDepartment = (department) => {
    setNewJobDepartment(department)
    setNewJobTitle("")
    setNewJobItemNo("")
    setExpandedDepartments({ [department]: true })
    setIsDepartmentOpen(false)
    setIsJobPositionOpen(true)
  }

  const setJobEligibilityFromValue = (value) => {
    const resolved = resolveJobEligibilitySelection(value)
    setNewJobEligibility(resolved.selected)
    setNewJobCustomEligibility(resolved.custom)
  }

  const handleJobEligibilityChange = (value) => {
    setNewJobEligibility(value)
    if (value !== otherEligibilityOption) {
      setNewJobCustomEligibility("")
    }
  }

  const applyTemplate = (templateId) => {
    const selected = templates.find((item) => String(item.id) === String(templateId))
    if (!selected) return
    setNewJobDescription(selected.description || "")
    setNewJobDepartment(selected.department || "")
    setNewJobPositionType(selected.jobPosition || selected.job_position || "Teaching")
    setNewJobItemNo(selected.itemNo || selected.item_no || "")
    setNewJobLocation(selected.location || defaultJobLocation)
    setNewJobType(selected.type || "Full-time")
    setNewJobDeadline(selected.deadline || "")
    setJobEligibilityFromValue(selected.eligibility || defaultJobEligibility)
    setNewRequiredSkills(selected.requiredSkills || "")
    setNewUniversalMatchMode(selected.universalMatchMode || selected.universal_match_mode || "")
    setNewMinimumEducation(selected.minimumEducation || "")
    setNewMinimumExperienceYears(String(selected.minimumExperienceYears ?? 0))
    setNewApplicationThresholdScore(String(selected.applicationThresholdScore ?? selected.application_threshold_score ?? 50))
    setNewScoringWeights(scoringWeightsFromRecord(selected))
    setNewSalaryMin(integerRecordValue(selected.salaryMin))
    setNewSalaryMax(selected.salaryMax != null ? String(selected.salaryMax) : "")
    setNewPositionsTotal(positionsTotalFormValue(selected.positionsTotal ?? selected.positions_total, selected))
  }

  const applyTemplateFromRecord = (record) => {
    if (!record) return
    setNewJobDescription(record.description || "")
    setNewJobDepartment(record.department || "")
    setNewJobPositionType(record.jobPosition || record.job_position || "Teaching")
    setNewJobItemNo(record.itemNo || record.item_no || "")
    setNewJobLocation(record.location || defaultJobLocation)
    setNewJobType(record.type || "Full-time")
    setNewJobDeadline(record.deadline || "")
    setJobEligibilityFromValue(record.eligibility || defaultJobEligibility)
    setNewRequiredSkills(record.requiredSkills || "")
    setNewUniversalMatchMode(record.universalMatchMode || record.universal_match_mode || "")
    setNewMinimumEducation(record.minimumEducation || "")
    setNewMinimumExperienceYears(String(record.minimumExperienceYears ?? 0))
    setNewApplicationThresholdScore(String(record.applicationThresholdScore ?? record.application_threshold_score ?? 50))
    setNewScoringWeights(scoringWeightsFromRecord(record))
    setNewSalaryMin(integerRecordValue(record.salaryMin))
    setNewSalaryMax(record.salaryMax != null ? String(record.salaryMax) : "")
    setNewPositionsTotal(positionsTotalFormValue(record.positionsTotal ?? record.positions_total, record))
  }

  useEffect(() => {
    const key = newJobTitle.trim().toLowerCase()
    if (!key) return
    if (isEditingJob) return
    if (skipTemplateApplyRef.current) {
      skipTemplateApplyRef.current = false
      return
    }
    const matched = templateByTitle.get(key)
    if (!matched) return
    if (matched.source === "template") {
      applyTemplate(matched.id)
      return
    }
    applyTemplateFromRecord(matched)
  }, [newJobTitle, templateByTitle])

  const selectedJobApplicants = useMemo(() => {
    if (!selectedJobTitle) return []
    return uploads
      .filter((item) => {
        const applied = String(item.applied_job_title || "").toLowerCase()
        const matched = String(item.matched_job_title || "").toLowerCase()
        return applied === selectedJobTitle.toLowerCase() || matched === selectedJobTitle.toLowerCase()
      })
  }, [uploads, selectedJobTitle])

  const sortedSelectedJobApplicants = useMemo(() => {
    const direction = modalSortConfig.direction === "asc" ? 1 : -1
    return [...selectedJobApplicants].sort((a, b) => {
      if (modalSortConfig.key === "name") {
        return (String(a.name || "").localeCompare(String(b.name || ""))) * direction
      }
      if (modalSortConfig.key === "score") {
        return (Number(a.match_score || 0) - Number(b.match_score || 0)) * direction
      }
      return (new Date(a.uploaded_at || 0) - new Date(b.uploaded_at || 0)) * direction
    })
  }, [selectedJobApplicants, modalSortConfig])

  const toggleModalSort = (key) => {
    setModalSortConfig((prev) => {
      if (prev.key === key) {
        return { key, direction: prev.direction === "asc" ? "desc" : "asc" }
      }
      const defaultDirection = key === "date" || key === "score" ? "desc" : "asc"
      return { key, direction: defaultDirection }
    })
  }

  const statusOptions = [
    { value: "all", label: "All Status" },
    { value: "active", label: "Active" },
    { value: "closed", label: "Closed" }
  ]

  useEffect(() => {
    if (isJobSeeker && statusFilter === "closed") {
      setStatusFilter("all")
    }
  }, [isJobSeeker, statusFilter])

  const matchOptions = [
    { value: "all", label: "All" },
    { value: "match", label: "Match" },
    { value: "not-match", label: "Not match" }
  ]

  const jobPositionTypeFilterOptions = [
    { value: "all", label: "All Positions" },
    { value: "teaching", label: "Teaching" },
    { value: "non-teaching", label: "Non-Teaching" }
  ]

  const jobStatusOptions = [
    { value: "active", label: "Active" },
    { value: "closed", label: "Closed" }
  ]

  const jobPositionTypeOptions = [
    { value: "Teaching", label: "Teaching" },
    { value: "Non-Teaching", label: "Non-Teaching" }
  ]

  const teachingEmploymentTypeOptions = [
    { value: "Full-time", label: "Full-time" },
    { value: "Part-time", label: "Part-time" },
    { value: "Contract of Service", label: "Contract of Service" },
    { value: "Internship", label: "Internship" }
  ]

  const nonTeachingEmploymentTypeOptions = [
    { value: "Permanent", label: "Permanent" },
    { value: "Casual", label: "Casual" },
    { value: "Contract of Service", label: "Contract of Service" },
    { value: "Conterminous", label: "Conterminous" }
  ]

  const employmentTypeOptions = normalizeJobPositionType(newJobPositionType) === "non-teaching"
    ? nonTeachingEmploymentTypeOptions
    : teachingEmploymentTypeOptions

  useEffect(() => {
    if (employmentTypeOptions.some((option) => option.value === newJobType)) return
    setNewJobType(employmentTypeOptions[0]?.value || "")
  }, [employmentTypeOptions, newJobType])

  const normalizeJobIdentityValue = (value) => (
    String(value || "").trim().replace(/\s+/g, " ").toLowerCase()
  )

  const findDuplicateJobPost = (itemNo, ignoredJobId = null) => {
    const normalizedItemNo = normalizeJobIdentityValue(itemNo)
    if (!normalizedItemNo) return null

    return jobs.find((job) => {
      const sameJob = ignoredJobId != null && String(job.id) === String(ignoredJobId)
      if (sameJob) return false
      return normalizeJobIdentityValue(job.itemNo || job.item_no) === normalizedItemNo
    }) || null
  }

  const updateJobStatus = async (jobId, status) => {
    try {
      const response = await fetch(`http://localhost:5000/jobs/${jobId}/status`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          ...getArchiveActorHeaders(currentUser)
        },
        body: JSON.stringify({ status })
      })
      if (!response.ok) {
        throw new Error("Failed to update status.")
      }
      setActionsJobId(null)
      await fetchJobs({ silent: true })
      await onJobsChanged?.()
    } catch (err) {
      setError(err.message || "Failed to update job status.")
    }
  }

  const performDeleteJobPost = async (jobId) => {
    try {
      const response = await fetch(`http://localhost:5000/jobs/${jobId}`, {
        method: "DELETE",
        headers: getArchiveActorHeaders(currentUser)
      })
      if (!response.ok) {
        throw new Error("Failed to delete job post.")
      }
      setActionsJobId(null)
      await fetchJobs({ silent: true })
      await onJobsChanged?.()
      showDeleteToast("Job post deleted.", "success")
    } catch (err) {
      setError(err.message || "Failed to delete job post.")
      showDeleteToast(err.message || "Failed to delete job post.", "fail")
    }
  }

  const deleteJobPost = (jobId) => {
    setActionsJobId(null)
    setConfirmDeleteJobId(jobId)
  }

  const handleApplyJob = (job) => {
    if (!job) return
    onViewJob?.(job)
  }

  const isOtherEligibilitySelected = newJobEligibility === otherEligibilityOption
  const resolvedJobEligibility = isOtherEligibilitySelected
    ? newJobCustomEligibility.trim()
    : newJobEligibility.trim()

  const setScoringWeight = (key, value) => {
    const normalizedValue = String(value || "").replace(/[^\d]/g, "")
    setNewScoringWeights((prev) => {
      if (normalizedValue === "") {
        return { ...prev, [key]: "" }
      }
      const otherTotal = scoringCriteria.reduce((sum, item) => {
        if (item.key === key) return sum
        return sum + (Number(prev[item.key]) || 0)
      }, 0)
      const maxForField = Math.max(0, 100 - otherTotal)
      return {
        ...prev,
        [key]: String(Math.min(maxForField, Number(normalizedValue)))
      }
    })
  }

  const resetJobForm = () => {
    setNewJobTitle("")
    setNewJobDescription("")
    setNewJobDepartment("")
    setNewJobPositionType("Teaching")
    setNewJobItemNo("")
    setNewJobLocation(defaultJobLocation)
    setExpandedDepartments({})
    setNewJobType("Full-time")
    setNewJobStatus("active")
    setNewJobDeadline("")
    setNewJobEligibility(defaultJobEligibility)
    setNewJobCustomEligibility("")
    setNewRequiredSkills("")
    setNewUniversalMatchMode("")
    setNewMinimumEducation("")
    setNewMinimumExperienceYears("0")
    setNewApplicationThresholdScore("50")
    setNewScoringWeights(defaultScoringWeights)
    setNewSalaryMin("")
    setNewSalaryMax("")
    setNewPositionsTotal("1")
    setSkillDraft("")
    setIsSkillsOpen(false)
    setIsDepartmentOpen(false)
    setIsJobPositionOpen(false)
  }

  const getJobFormDraftPayload = () => ({
    title: newJobTitle,
    description: newJobDescription,
    department: newJobDepartment,
    jobPosition: newJobPositionType,
    itemNo: newJobItemNo,
    location: newJobLocation,
    type: newJobType,
    status: newJobStatus,
    deadline: newJobDeadline,
    eligibility: resolvedJobEligibility || newJobEligibility,
    requiredSkills: newRequiredSkills,
    universalMatchMode: newUniversalMatchMode,
    minimumEducation: newMinimumEducation,
    minimumExperienceYears: newMinimumExperienceYears,
    applicationThresholdScore: newApplicationThresholdScore,
    scoringWeights: newScoringWeights,
    salaryMin: newSalaryMin,
    salaryMax: newSalaryMax,
    positionsTotal: newPositionsTotal,
    savedAt: new Date().toISOString()
  })

  const jobFormHasDraftData = (draft = getJobFormDraftPayload()) => {
    return [
      draft.title,
      draft.description,
      draft.department,
      draft.jobPosition,
      draft.itemNo,
      draft.deadline,
      draft.requiredSkills,
      draft.minimumEducation,
      draft.minimumExperienceYears !== "0" ? draft.minimumExperienceYears : "",
      draft.applicationThresholdScore !== "50" ? draft.applicationThresholdScore : "",
      JSON.stringify(draft.scoringWeights || {}) !== JSON.stringify(defaultScoringWeights) ? "scoring" : "",
      draft.salaryMin,
      draft.salaryMax,
      draft.positionsTotal !== "1" ? draft.positionsTotal : ""
    ].some((value) => String(value ?? "").trim())
  }

  const saveJobFormDraft = () => {
    if (isEditingJob) return
    const draft = getJobFormDraftPayload()
    try {
      if (jobFormHasDraftData(draft)) {
        window.localStorage.setItem(JOB_FORM_DRAFT_KEY, JSON.stringify(draft))
        setHasSavedJobDraft(true)
        return
      }
      window.localStorage.removeItem(JOB_FORM_DRAFT_KEY)
      setHasSavedJobDraft(false)
      setIsUsingSavedJobDraft(false)
    } catch {
      // Local storage can be unavailable in private browser modes.
    }
  }

  const clearSavedJobDraft = () => {
    try {
      window.localStorage.removeItem(JOB_FORM_DRAFT_KEY)
    } catch {
      // Local storage can be unavailable in private browser modes.
    }
    setHasSavedJobDraft(false)
    setIsUsingSavedJobDraft(false)
  }

  const applyJobFormDraft = (draft) => {
    skipTemplateApplyRef.current = Boolean(String(draft?.title || "").trim())
    setNewJobTitle(draft?.title || "")
    setNewJobDescription(draft?.description || "")
    setNewJobDepartment(draft?.department || "")
    setNewJobPositionType(draft?.jobPosition || "Teaching")
    setNewJobItemNo(draft?.itemNo || "")
    setNewJobLocation(draft?.location || defaultJobLocation)
    setExpandedDepartments({})
    setNewJobType(draft?.type || "Full-time")
    setNewJobStatus(draft?.status === "closed" ? "closed" : "active")
    setNewJobDeadline(draft?.deadline || "")
    setJobEligibilityFromValue(draft?.eligibility || defaultJobEligibility)
    setNewRequiredSkills(draft?.requiredSkills || "")
    setNewUniversalMatchMode(draft?.universalMatchMode || "")
    setNewMinimumEducation(draft?.minimumEducation || "")
    setNewMinimumExperienceYears(String(draft?.minimumExperienceYears ?? 0))
    setNewApplicationThresholdScore(String(draft?.applicationThresholdScore ?? 50))
    setNewScoringWeights({ ...defaultScoringWeights, ...(draft?.scoringWeights || {}) })
    setNewSalaryMin(integerRecordValue(draft?.salaryMin))
    setNewSalaryMax(draft?.salaryMax != null ? String(draft.salaryMax) : "")
    setNewPositionsTotal(positionsTotalFormValue(draft?.positionsTotal, draft))
    setSkillDraft("")
    setIsSkillsOpen(false)
    setIsDepartmentOpen(false)
    setIsJobPositionOpen(false)
  }

  const loadSavedJobDraft = () => {
    try {
      const rawDraft = window.localStorage.getItem(JOB_FORM_DRAFT_KEY)
      if (!rawDraft) return false
      applyJobFormDraft(JSON.parse(rawDraft))
      setHasSavedJobDraft(true)
      setIsUsingSavedJobDraft(true)
      return true
    } catch {
      clearSavedJobDraft()
      return false
    }
  }

  const startNewJobForm = () => {
    clearSavedJobDraft()
    resetJobForm()
    setEditingJobId(null)
    setShowJobFormErrors(false)
    setIsCreateModalOpen(true)
  }

  const openCreateJobModal = () => {
    if (isJobSeeker) return
    setEditingJobId(null)
    setShowJobFormErrors(false)
    const didLoadDraft = loadSavedJobDraft()
    if (!didLoadDraft) {
      resetJobForm()
    }
    setIsCreateModalOpen(true)
  }

  const openEditJobModal = (job) => {
    if (!job?.id) return
    setIsUsingSavedJobDraft(false)
    setShowJobFormErrors(false)
    setEditingJobId(job.id)
    setNewJobTitle(job.title || "")
    setNewJobDescription(job.description || "")
    setNewJobDepartment(job.department || "")
    setNewJobPositionType(job.jobPosition || job.job_position || "Teaching")
    setNewJobItemNo(job.itemNo || job.item_no || "")
    setNewJobLocation(job.location || defaultJobLocation)
    setExpandedDepartments({})
    setNewJobType(job.type || "Full-time")
    setNewJobStatus(job.status || "active")
    setNewJobDeadline(job.deadline || "")
    setJobEligibilityFromValue(job.eligibility || defaultJobEligibility)
    setNewRequiredSkills(job.requiredSkills || "")
    setNewUniversalMatchMode(job.universalMatchMode || job.universal_match_mode || "")
    setNewMinimumEducation(job.minimumEducation || "")
    setNewMinimumExperienceYears(String(job.minimumExperienceYears ?? 0))
    setNewApplicationThresholdScore(String(job.applicationThresholdScore ?? job.application_threshold_score ?? 50))
    setNewScoringWeights(scoringWeightsFromRecord(job))
    setNewSalaryMin(integerRecordValue(job.salaryMin))
    setNewSalaryMax(job.salaryMax != null ? String(job.salaryMax) : "")
    setNewPositionsTotal(positionsTotalFormValue(job.positionsTotal ?? job.positions_total, job))
    setSkillDraft("")
    setIsSkillsOpen(false)
    setIsCreateModalOpen(true)
  }

  const closeCreateModal = ({ saveDraft = true } = {}) => {
    if (saveDraft) {
      saveJobFormDraft()
    }
    setIsCreateModalOpen(false)
    setEditingJobId(null)
    setShowJobFormErrors(false)
    setIsUsingSavedJobDraft(false)
    setSkillDraft("")
    setIsSkillsOpen(false)
  }

  const salaryLabel = useMemo(() => {
    const type = String(newJobType || "").toLowerCase()
    if (type.includes("part")) {
      return { min: "Salary Grade", max: "Hourly Rate" }
    }
    return { min: "Salary Grade", max: "Salary per Month" }
  }, [newJobType])

  const createJobPost = async () => {
    const hasMissingField = (
      !newJobTitle.trim() ||
      !newJobDescription.trim() ||
      !newJobDepartment.trim() ||
      !newJobPositionType.trim() ||
      !newJobItemNo.trim() ||
      !newJobLocation.trim() ||
      !newJobType.trim() ||
      !newJobStatus.trim() ||
      !newJobDeadline.trim() ||
      !resolvedJobEligibility ||
      !newRequiredSkills.trim() ||
      !newMinimumEducation.trim() ||
      newMinimumExperienceYears === "" ||
      !scoringTotalIsValid ||
      newSalaryMin === "" ||
      newSalaryMax === "" ||
      newPositionsTotal === ""
    )

    if (hasMissingField) {
      setShowJobFormErrors(true)
      showCreateJobNotice("fail", "Please fill in all fields before creating the job post.")
      scrollCreateJobModalToTop()
      return
    }

    const minExp = newMinimumExperienceYears === "" ? 0 : Number(newMinimumExperienceYears)
    const salaryGradeIsInteger = /^\d+$/.test(String(newSalaryMin))
    const positionsTotalIsMany = isManySlotsValue(newPositionsTotal)
    const positionsTotalIsInteger = positionsTotalIsMany || /^\d+$/.test(String(newPositionsTotal))
    const parsedSalaryMin = Number(newSalaryMin)
    const parsedSalaryMax = Number(newSalaryMax)
    const parsedPositionsTotal = getPositionsPayloadValue()

    if (Number.isNaN(minExp) || minExp < 0) {
      showCreateJobNotice("fail", "Minimum experience must be a valid non-negative number.")
      scrollCreateJobModalToTop()
      return
    }

    if (!scoringTotalIsValid) {
      showCreateJobNotice("fail", "Scoring weights must not exceed 100%.")
      scrollCreateJobModalToTop()
      return
    }

    if (!salaryGradeIsInteger) {
      showCreateJobNotice("fail", "Salary grade must be a valid whole number.")
      scrollCreateJobModalToTop()
      return
    }

    if (Number.isNaN(parsedSalaryMin) || parsedSalaryMin < 0 || Number.isNaN(parsedSalaryMax) || parsedSalaryMax < 0) {
      showCreateJobNotice("fail", "Salary grade and salary amount must be valid non-negative numbers.")
      scrollCreateJobModalToTop()
      return
    }

    if (!positionsTotalIsInteger || (!positionsTotalIsMany && parsedPositionsTotal < 1)) {
      showCreateJobNotice("fail", "Position slots must be a valid whole number of at least 1, or choose Many.")
      scrollCreateJobModalToTop()
      return
    }
    const { salaryMin, salaryMax } = normalizeSalaryRange(parsedSalaryMin, parsedSalaryMax)
    const duplicateJob = findDuplicateJobPost(newJobItemNo)
    if (duplicateJob) {
      showCreateJobNotice("fail", "This Plantilla Item No. is already used by another job post.")
      scrollCreateJobModalToTop()
      return
    }

    setIsCreatingJob(true)
    setError("")
    try {
      const response = await fetch("http://localhost:5000/jobs", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...getArchiveActorHeaders(currentUser)
        },
        body: JSON.stringify({
          title: newJobTitle.trim(),
          description: newJobDescription.trim(),
          department: newJobDepartment.trim(),
          jobPosition: newJobPositionType,
          itemNo: newJobItemNo.trim(),
          location: newJobLocation.trim(),
          type: newJobType.trim(),
          status: newJobStatus,
          deadline: newJobDeadline || null,
          eligibility: resolvedJobEligibility,
          requiredSkills: newRequiredSkills.trim(),
          universalMatchMode: newUniversalMatchMode,
          minimumEducation: newMinimumEducation,
          minimumExperienceYears: minExp,
          skillsWeight: Number(newScoringWeights.skills) || 0,
          trainingWeight: Number(newScoringWeights.training) || 0,
          educationWeight: Number(newScoringWeights.education) || 0,
          experienceWeight: Number(newScoringWeights.experience) || 0,
          eligibilityWeight: Number(newScoringWeights.eligibility) || 0,
          salaryMin,
          salaryMax,
          positionsTotal: parsedPositionsTotal
        })
      })

      if (!response.ok) {
        const payload = await response.json().catch(() => null)
        throw new Error(apiErrorMessage(payload, "Failed to create job post."))
      }

      clearSavedJobDraft()
      closeCreateModal({ saveDraft: false })
      resetJobForm()
      showCreateJobNotice("success", "Job post created successfully.")
      await fetchJobs()
      await onJobsChanged?.()
    } catch (err) {
      showCreateJobNotice("fail", err.message || "Failed to create job post.")
    } finally {
      setIsCreatingJob(false)
    }
  }

  const updateJobPost = async () => {
    if (!editingJobId) return
    const hasMissingField = (
      !newJobTitle.trim() ||
      !newJobDescription.trim() ||
      !newJobDepartment.trim() ||
      !newJobPositionType.trim() ||
      !newJobItemNo.trim() ||
      !newJobLocation.trim() ||
      !newJobType.trim() ||
      !newJobStatus.trim() ||
      !newJobDeadline.trim() ||
      !resolvedJobEligibility ||
      !newRequiredSkills.trim() ||
      !newMinimumEducation.trim() ||
      newMinimumExperienceYears === "" ||
      !scoringTotalIsValid ||
      newSalaryMin === "" ||
      newSalaryMax === "" ||
      newPositionsTotal === ""
    )

    if (hasMissingField) {
      setShowJobFormErrors(true)
      showCreateJobNotice("fail", "Please fill in all fields before saving changes.")
      scrollCreateJobModalToTop()
      return
    }

    const minExp = newMinimumExperienceYears === "" ? 0 : Number(newMinimumExperienceYears)
    const salaryGradeIsInteger = /^\d+$/.test(String(newSalaryMin))
    const positionsTotalIsMany = isManySlotsValue(newPositionsTotal)
    const positionsTotalIsInteger = positionsTotalIsMany || /^\d+$/.test(String(newPositionsTotal))
    const parsedSalaryMin = Number(newSalaryMin)
    const parsedSalaryMax = Number(newSalaryMax)
    const parsedPositionsTotal = getPositionsPayloadValue()

    if (Number.isNaN(minExp) || minExp < 0) {
      showCreateJobNotice("fail", "Minimum experience must be a valid non-negative number.")
      scrollCreateJobModalToTop()
      return
    }

    if (!scoringTotalIsValid) {
      showCreateJobNotice("fail", "Scoring weights must not exceed 100%.")
      scrollCreateJobModalToTop()
      return
    }

    if (!salaryGradeIsInteger) {
      showCreateJobNotice("fail", "Salary grade must be a valid whole number.")
      scrollCreateJobModalToTop()
      return
    }

    if (Number.isNaN(parsedSalaryMin) || parsedSalaryMin < 0 || Number.isNaN(parsedSalaryMax) || parsedSalaryMax < 0) {
      showCreateJobNotice("fail", "Salary grade and salary amount must be valid non-negative numbers.")
      scrollCreateJobModalToTop()
      return
    }

    if (!positionsTotalIsInteger || (!positionsTotalIsMany && parsedPositionsTotal < 1)) {
      showCreateJobNotice("fail", "Position slots must be a valid whole number of at least 1, or choose Many.")
      scrollCreateJobModalToTop()
      return
    }
    const { salaryMin, salaryMax } = normalizeSalaryRange(parsedSalaryMin, parsedSalaryMax)
    const duplicateJob = findDuplicateJobPost(newJobItemNo, editingJobId)
    if (duplicateJob) {
      showCreateJobNotice("fail", "This Plantilla Item No. is already used by another job post.")
      scrollCreateJobModalToTop()
      return
    }

    setIsCreatingJob(true)
    setError("")
    try {
      const response = await fetch(`http://localhost:5000/jobs/${editingJobId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          ...getArchiveActorHeaders(currentUser)
        },
        body: JSON.stringify({
          title: newJobTitle.trim(),
          description: newJobDescription.trim(),
          department: newJobDepartment.trim(),
          jobPosition: newJobPositionType,
          itemNo: newJobItemNo.trim(),
          location: newJobLocation.trim(),
          type: newJobType.trim(),
          status: newJobStatus,
          deadline: newJobDeadline || null,
          eligibility: resolvedJobEligibility,
          requiredSkills: newRequiredSkills.trim(),
          universalMatchMode: newUniversalMatchMode,
          minimumEducation: newMinimumEducation,
          minimumExperienceYears: minExp,
          skillsWeight: Number(newScoringWeights.skills) || 0,
          trainingWeight: Number(newScoringWeights.training) || 0,
          educationWeight: Number(newScoringWeights.education) || 0,
          experienceWeight: Number(newScoringWeights.experience) || 0,
          eligibilityWeight: Number(newScoringWeights.eligibility) || 0,
          salaryMin,
          salaryMax,
          positionsTotal: parsedPositionsTotal
        })
      })

      if (!response.ok) {
        const payload = await response.json().catch(() => null)
        throw new Error(apiErrorMessage(payload, "Failed to update job post."))
      }

      closeCreateModal({ saveDraft: false })
      resetJobForm()
      showCreateJobNotice("success", "Job post updated successfully.")
      await fetchJobs()
      await onJobsChanged?.()
    } catch (err) {
      showCreateJobNotice("fail", err.message || "Failed to update job post.")
    } finally {
      setIsCreatingJob(false)
    }
  }

  const getJobActionKey = (job) => `${job.source || "job"}-${job.id}`

  const formatJobDeadline = (job) => (
    job.deadline
      ? new Date(job.deadline).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })
      : "-"
  )

  const openJobRecord = (job) => {
    if (isJobSeeker) {
      onViewJob?.(job)
      return
    }
    if (job.source === "template") {
      setEditingJobId(null)
      setShowJobFormErrors(false)
      setNewJobTitle(job.title || "")
      applyTemplateFromRecord(job)
      setIsUsingSavedJobDraft(false)
      setIsCreateModalOpen(true)
      return
    }
    openEditJobModal(job)
  }

  const handleJobRecordKeyDown = (event, job) => {
    if (event.key !== "Enter" && event.key !== " ") return
    event.preventDefault()
    openJobRecord(job)
  }

  const getJobMatchContent = (job) => {
    if (!isJobSeeker) return null
    if (!jobSeekerResume) {
      return <span className="job-chip chip-warning">Upload PDS</span>
    }
    if (jobMatchStatus === "loading") {
      return <span className="job-chip chip-muted">Checking</span>
    }

    const matchKey = String(job.title || "").trim().toLowerCase()
    const match = matchKey ? jobMatches[matchKey] : null
    if (jobMatchStatus === "error" || !match || match.score == null) {
      return <span className="job-chip chip-warning">Unavailable</span>
    }

    return (
      <span className={`job-chip ${match.qualifies ? "chip-good" : "chip-bad"}`}>
        <span className="job-chip-label">{match.qualifies ? "match" : "not match"}</span>
      </span>
    )
  }

  const renderJobActions = (job, actionKey) => {
    if (isJobSeeker || job.id == null) return null

    return (
      <>
        <button
          className="action-btn action-trigger job-more job-action-trigger"
          type="button"
          onClick={(e) => {
            openJobActionsMenu(e, job, actionKey)
          }}
          aria-label="Job actions"
        >
          ...
        </button>
      </>
    )
  }

  return (
    <section className={`jobs-panel jobs-panel-modern ${actionsJobId || isPositioningJobActionsMenu ? "jobs-menu-open" : ""}`}>
      <div className="jobs-hero">
        <div>
          <p className="jobs-kicker">Job Posting</p>
          <h1 className="jobs-title">New Jobs</h1>
        </div>
        {!isJobSeeker && (
          <button
            type="button"
            className="btn jobs-create-btn"
            onClick={openCreateJobModal}
          >
            + Create Job
          </button>
        )}
      </div>

      <div className={`jobs-controls jobs-controls-modern ${isJobSeeker ? "jobs-controls-jobseeker" : ""}`}>
        <div className="autocomplete jobs-search">
          <input
            className="input"
            type="text"
            placeholder="Search jobs.."
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value)
              setIsSearchOpen(true)
            }}
            onFocus={() => setIsSearchOpen(true)}
            onBlur={() => setTimeout(() => setIsSearchOpen(false), 0)}
          />
          {isSearchOpen && filteredSearchSuggestions.length > 0 && (
            <div className="autocomplete-menu">
              {filteredSearchSuggestions.map((token) => (
                <button
                  key={`job-search-${token}`}
                  type="button"
                  className="autocomplete-item"
                  onMouseDown={(e) => {
                    e.preventDefault()
                    setSearchTerm(token)
                    setIsSearchOpen(false)
                  }}
                >
                  {token}
                </button>
              ))}
            </div>
          )}
        </div>
        {!isJobSeeker && (
          <CustomDropdown
            className="jobs-filter"
            options={statusOptions}
            value={statusFilter}
            onChange={setStatusFilter}
            placeholder="All Status"
          />
        )}
        <CustomDropdown
          className="jobs-filter"
          options={jobPositionTypeFilterOptions}
          value={jobPositionTypeFilter}
          onChange={setJobPositionTypeFilter}
          placeholder="All Positions"
        />
        {isJobSeeker && (
          <CustomDropdown
            className="jobs-filter"
            options={matchOptions}
            value={matchFilter}
            onChange={setMatchFilter}
            placeholder="All Match"
          />
        )}
        <div className="jobs-view-toggle" role="group" aria-label="Job list view">
          <button
            type="button"
            className={`jobs-view-btn ${jobsViewMode === "table" ? "active" : ""}`}
            onClick={() => setJobsViewMode("table")}
            aria-pressed={jobsViewMode === "table"}
            title="Table view"
          >
            <span className="jobs-view-icon table-icon" aria-hidden="true" />
            <span className="jobs-view-text">Table</span>
          </button>
          <button
            type="button"
            className={`jobs-view-btn ${jobsViewMode === "cards" ? "active" : ""}`}
            onClick={() => setJobsViewMode("cards")}
            aria-pressed={jobsViewMode === "cards"}
            title="Card view"
          >
            <span className="jobs-view-icon cards-icon" aria-hidden="true" />
            <span className="jobs-view-text">Cards</span>
          </button>
        </div>
      </div>

      <div className="table-wrap jobs-table-wrap">
        {isLoading ? (
          <p className="muted jobs-table-message">
            <span className="loading-indicator"><span className="loading-spinner" aria-hidden="true" />Loading jobs...</span>
          </p>
        ) : error ? (
          <p className="muted jobs-table-message">{error}</p>
        ) : fifoJobs.length === 0 ? (
          <p className="muted jobs-table-message">No jobs found.</p>
        ) : jobsViewMode === "cards" ? (
          <>
            <div className="jobs-grid jobs-card-view">
              {cardPageJobs.map((job, index) => {
                const actionKey = getJobActionKey(job)
                const skillItems = parseSkills(job.requiredSkills || job.required_skills || "").slice(0, 5)
                const remainingSlotsText = getJobAvailableSlotsText(job)
                return (
                  <article
                    key={`${job.source || "job"}-${job.id ?? job.title}`}
                    className="job-card job-card-modern job-card-clickable jobs-list-card"
                    role="button"
                    tabIndex={0}
                    onClick={() => openJobRecord(job)}
                    onKeyDown={(event) => handleJobRecordKeyDown(event, job)}
                  >
                    <div className="job-card-head">
                      <div>
                        <p className="job-card-index">#{cardStartIndex + index + 1}</p>
                        <h2>{job.title || "-"}</h2>
                      </div>
                      <div className="job-card-actions">
                        <span className={`job-status ${String(job.status || "active").toLowerCase()}`}>
                          {String(job.status || "active").toLowerCase()}
                        </span>
                        <span className="job-chip chip-outline">{remainingSlotsText}</span>
                        {renderJobActions(job, actionKey)}
                      </div>
                    </div>

                    <p className="job-description">{job.description || "-"}</p>

                    <div className="job-card-skill-preview">
                      <span className="job-card-skill-label">Required Skills</span>
                      <div className="job-card-chips job-card-skill-chips">
                        {skillItems.length ? (
                          skillItems.map((skill) => (
                            <span key={skill} className="job-chip chip-outline">{skill}</span>
                          ))
                        ) : (
                          <span className="job-chip chip-muted">No listed skills</span>
                        )}
                      </div>
                    </div>
                  </article>
                )
              })}
            </div>
            {cardPageCount > 1 && (
              <div className="jobs-card-pagination" aria-label="Job cards pagination">
                <button
                  type="button"
                  className="jobs-page-btn"
                  onClick={() => setCardPage((page) => Math.max(1, page - 1))}
                  disabled={activeCardPage <= 1}
                >
                  Previous
                </button>
                <span className="jobs-page-status">
                  Page {activeCardPage} of {cardPageCount}
                </span>
                <button
                  type="button"
                  className="jobs-page-btn"
                  onClick={() => setCardPage((page) => Math.min(cardPageCount, page + 1))}
                  disabled={activeCardPage >= cardPageCount}
                >
                  Next
                </button>
              </div>
            )}
          </>
        ) : (
          <>
            <table className="records-table jobs-table">
              <thead>
                <tr>
                  <th className="jobs-order-col">#</th>
                  <th className="jobs-title-col">Job Position</th>
                  <th className="jobs-dept-col">Department/Units</th>
                  <th className="jobs-type-col">Type</th>
                  <th className="jobs-deadline-col">Post Deadline</th>
                  {isJobSeeker && <th className="jobs-match-col">Match</th>}
                  {!isJobSeeker && <th className="jobs-applicants-col">Applications</th>}
                  <th className="jobs-slots-col">Slots</th>
                  <th className="jobs-status-col">Status</th>
                  {!isJobSeeker && <th className="actions-col jobs-actions-col">Actions</th>}
                </tr>
              </thead>
              <tbody>
                {tablePageJobs.map((job, index) => {
                const actionKey = getJobActionKey(job)
                const deadline = formatJobDeadline(job)
                const matchContent = getJobMatchContent(job)
                const remainingSlotsLabel = getJobAvailableSlotsLabel(job)

                return (
                  <tr
                    key={`${job.source || "job"}-${job.id ?? job.title}`}
                    className="job-table-row"
                    role="button"
                    tabIndex={0}
                    onClick={() => openJobRecord(job)}
                    onKeyDown={(event) => handleJobRecordKeyDown(event, job)}
                  >
                    <td className="jobs-order-cell" data-label="#">
                      {tableStartIndex + index + 1}
                    </td>
                    <td data-label="Job Position">
                      <button
                        type="button"
                        className="job-table-title"
                        onClick={(event) => {
                          event.stopPropagation()
                          openJobRecord(job)
                        }}
                      >
                        {job.title || "-"}
                      </button>
                    </td>
                    <td className="jobs-dept-cell" data-label="Department/Units">{job.department || "-"}</td>
                    <td className="jobs-type-cell" data-label="Type">{job.type || "-"}</td>
                    <td className="jobs-deadline-cell" data-label="Post Deadline">{deadline}</td>
                    {isJobSeeker && <td className="jobs-match-cell" data-label="Match">{matchContent}</td>}
                    {!isJobSeeker && (
                      <td className="jobs-applicants-cell" data-label="Applications">
                        <button
                          className="job-applicants"
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation()
                            setActionsJobId(null)
                            setActionsJobMenu(null)
                            setIsPositioningJobActionsMenu(false)
                            setSelectedJobTitle(job.title)
                          }}
                        >
                          {Number(job.applicants || 0)}
                        </button>
                      </td>
                    )}
                    <td className="jobs-slots-cell" data-label="Slots">
                      <strong>{remainingSlotsLabel}</strong>
                    </td>
                    <td className="jobs-status-cell" data-label="Status">
                      <span className={`job-status ${String(job.status || "active").toLowerCase()}`}>
                        {String(job.status || "active").toLowerCase()}
                      </span>
                    </td>
                    {!isJobSeeker && (
                      <td className="actions-cell job-table-actions" data-label="Actions">
                        {renderJobActions(job, actionKey)}
                      </td>
                    )}
                  </tr>
                )
                })}
              </tbody>
            </table>
            {tablePageCount > 1 && (
              <div className="jobs-card-pagination" aria-label="Job table pagination">
                <button
                  type="button"
                  className="jobs-page-btn"
                  onClick={() => setTablePage((page) => Math.max(1, page - 1))}
                  disabled={activeTablePage <= 1}
                >
                  Previous
                </button>
                <span className="jobs-page-status">
                  Page {activeTablePage} of {tablePageCount}
                </span>
                <button
                  type="button"
                  className="jobs-page-btn"
                  onClick={() => setTablePage((page) => Math.min(tablePageCount, page + 1))}
                  disabled={activeTablePage >= tablePageCount}
                >
                  Next
                </button>
              </div>
            )}
          </>
        )}
      </div>

      {actionsJobId && actionsJobMenu && (
        <div
          className="job-actions-menu job-actions-menu-floating"
          style={{ top: `${actionsJobMenu.top}px`, left: `${actionsJobMenu.left}px` }}
          onClick={(e) => e.stopPropagation()}
        >
          {actionsJobMenu.job?.source === "template" ? (
            <button
              type="button"
              className="actions-menu-item"
              onClick={() => {
                const targetJob = actionsJobMenu.job
                setActionsJobId(null)
                setActionsJobMenu(null)
                setEditingJobId(null)
                setShowJobFormErrors(false)
                setNewJobTitle(targetJob.title || "")
                applyTemplateFromRecord(targetJob)
                setIsUsingSavedJobDraft(false)
                setIsCreateModalOpen(true)
              }}
            >
              Use Template
            </button>
          ) : (
            <>
              <button
                type="button"
                className="actions-menu-item"
                onClick={() => {
                  const targetJob = actionsJobMenu.job
                  setActionsJobId(null)
                  setActionsJobMenu(null)
                  openEditJobModal(targetJob)
                }}
              >
                Edit Details
              </button>
              <button
                type="button"
                className="actions-menu-item"
                onClick={() => {
                  const targetJob = actionsJobMenu.job
                  setActionsJobId(null)
                  setActionsJobMenu(null)
                  updateJobStatus(targetJob.id, "active")
                }}
              >
                Set Active
              </button>
              <button
                type="button"
                className="actions-menu-item"
                onClick={() => {
                  const targetJob = actionsJobMenu.job
                  setActionsJobId(null)
                  setActionsJobMenu(null)
                  updateJobStatus(targetJob.id, "closed")
                }}
              >
                Set Closed
              </button>
              <button
                type="button"
                className="actions-menu-item danger"
                onClick={() => {
                  const targetJob = actionsJobMenu.job
                  setActionsJobId(null)
                  setActionsJobMenu(null)
                  deleteJobPost(targetJob.id)
                }}
              >
                Delete Post
              </button>
            </>
          )}
        </div>
      )}

      {selectedJobTitle && !isJobSeeker && (
        <div className="modal-overlay" onClick={() => setSelectedJobTitle("")}>
          <div className="modal-card modal-modern job-applicants-modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Applications for {selectedJobTitle}</h3>
              <button type="button" className="close-x" onClick={() => {
                setSelectedJobTitle("")
              }}>×</button>
            </div>

            {selectedJobApplicants.length === 0 ? (
              <p className="muted">No analyzed applicants found for this job.</p>
            ) : (
              <div>
                <div className="panel-meta">
                  <p>Showing {sortedSelectedJobApplicants.length} applicants</p>
                  <div className="sort-wrap">
                    <span>Sort by:</span>
                    <button
                      className={`sort-btn ${modalSortConfig.key === "name" ? "active" : ""}`}
                      onClick={() => toggleModalSort("name")}
                    >
                      Name {modalSortConfig.key === "name" ? (modalSortConfig.direction === "asc" ? "↑" : "↓") : ""}
                    </button>
                    <button
                      className={`sort-btn ${modalSortConfig.key === "date" ? "active" : ""}`}
                      onClick={() => toggleModalSort("date")}
                    >
                      Date {modalSortConfig.key === "date" ? (modalSortConfig.direction === "asc" ? "↑" : "↓") : ""}
                    </button>
                    <button
                      className={`sort-btn ${modalSortConfig.key === "score" ? "active" : ""}`}
                      onClick={() => toggleModalSort("score")}
                    >
                      Score {modalSortConfig.key === "score" ? (modalSortConfig.direction === "asc" ? "↑" : "↓") : ""}
                    </button>
                  </div>
                </div>
                <div className="table-wrap job-applicants-table-wrap">
                  <table className="records-table">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Application</th>
                        <th>Phone</th>
                        <th>Job Applied</th>
                        <th>Score</th>
                        <th>Status</th>
                        <th>Classification</th>
                        <th>Uploaded File</th>
                        <th>Uploaded At</th>
                        <th className="actions-col">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sortedSelectedJobApplicants.map((item, index) => (
                        <tr key={item.id}>
                          <td>{index + 1}</td>
                          <td>
                            <div className="applicant-cell">
                              <strong>{item.name || "(No name)"}</strong>
                              <span>{item.idNumber || item.id_number || item.jobSeekerIdNumber || item.job_seeker_id_number || item.email || "No ID number"}</span>
                            </div>
                          </td>
                          <td>{item.phone || "No phone"}</td>
                          <td>{item.applied_job_title || item.matched_job_title || selectedJobTitle || "-"}</td>
                          <td>{item.match_score != null ? `${Number(item.match_score).toFixed(2)}%` : "-"}</td>
                          <td>
                            <span className={`application-status status-${getApplicationStatus(item)}`}>
                              {getApplicationStatusLabel(item)}
                            </span>
                          </td>
                          <td>
                            <span className={`table-classification ${(item.classification || "Not Qualified").toLowerCase().replace(/\s+/g, "-")}`}>
                              {classificationLabel(item.classification)}
                            </span>
                          </td>
                          <td>{item.original_name || "-"}</td>
                          <td>{item.uploaded_at ? new Date(item.uploaded_at).toLocaleDateString(undefined, { month: "long", day: "numeric", year: "numeric" }) : "-"}</td>
                          <td className="actions-cell actions-col">
                            <button
                              type="button"
                              className="action-btn job-applicant-view-btn"
                              aria-label="View applicant"
                              onClick={(e) => {
                                e.stopPropagation()
                                setSelectedJobTitle("")
                                onViewApplicant?.(item)
                              }}
                            >
                              View
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {confirmDeleteJobId != null && (
        <div
          className="modal-overlay delete-confirm-overlay"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              setConfirmDeleteJobId(null)
            }
          }}
        >
          <div className="modal-card delete-confirm-card">
            <h3>Delete Job Post</h3>
            <p>Are you sure you want to delete this job post? This action cannot be undone.</p>
            <div className="modal-actions">
              <button type="button" className="btn btn-secondary" onClick={() => setConfirmDeleteJobId(null)}>
                Cancel
              </button>
              <button
                type="button"
                className="btn btn-danger"
                onClick={async () => {
                  const idToDelete = confirmDeleteJobId
                  setConfirmDeleteJobId(null)
                  if (idToDelete != null) {
                    await performDeleteJobPost(idToDelete)
                  }
                }}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {isCreateModalOpen && !isJobSeeker && (
        <div className="modal-overlay" onClick={closeCreateModal}>
          <div ref={createJobModalRef} className="modal-card modal-modern create-job-modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header create-job-header">
              <div>
                <h3>{isEditingJob ? "Edit Job Details" : "Job Details"}</h3>
                <p className="create-job-subtitle">
                  {isUsingSavedJobDraft ? "Continuing your saved draft" : "Basic information about the position"}
                </p>
              </div>
              <div className="create-job-header-actions">
                {!isEditingJob && hasSavedJobDraft && (
                  <button
                    type="button"
                    className="create-job-new-btn"
                    onClick={startNewJobForm}
                  >
                    New Job
                  </button>
                )}
                <button type="button" className="close-x" onClick={closeCreateModal}>×</button>
              </div>
            </div>
            {createJobStatus && (
              <div className={`create-job-notice create-job-notice-${createJobStatus === "success" ? "success" : "fail"}`}>
                {createJobNotice || (createJobStatus === "success" ? "Success" : "Fail")}
              </div>
            )}

            <div className="create-job-layout">
              <div className="create-job-left">
                <section className="create-job-panel">
                  <div className="create-job-panel-head">
                    <div>
                      <h4>Role Overview</h4>
                      <p>Define the core details for this opening.</p>
                    </div>
                    <span className="create-job-chip">Required</span>
                  </div>

                  <div className="modal-grid">
                    <div className="field-group">
                      <label>Job Position Type</label>
                      <CustomDropdown
                        className={requiredDropdownClass(newJobPositionType)}
                        options={jobPositionTypeOptions}
                        value={newJobPositionType}
                        onChange={handleJobPositionTypeChange}
                        placeholder="Teaching"
                      />
                    </div>

                    <div className="field-group">
                      <label>Department/Units</label>
                      <div
                        ref={departmentRef}
                        className="autocomplete"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="job-position-input">
                          <input
                            className={requiredInputClass(newJobDepartment)}
                            type="text"
                            value={newJobDepartment}
                            onChange={(e) => {
                              setNewJobDepartment(e.target.value)
                              setIsDepartmentOpen(true)
                            }}
                            onFocus={() => setIsDepartmentOpen(true)}
                            placeholder="Select or type department"
                          />
                          <span className="dropdown-caret">▾</span>
                        </div>
                        {isDepartmentOpen && filteredDepartmentSuggestions.length > 0 && (
                          <div className="autocomplete-menu">
                            {filteredDepartmentSuggestions.map((department) => (
                              <button
                                key={`department-${department}`}
                                type="button"
                                className="autocomplete-item"
                                onMouseDown={(e) => {
                                  e.preventDefault()
                                  handleSelectDepartment(department)
                                }}
                              >
                                {department}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="field-group">
                      <label>Job Position</label>
                      <div
                        ref={jobPositionRef}
                        className="autocomplete"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="job-position-input">
                          <input
                            className={requiredInputClass(newJobTitle)}
                            type="text"
                            value={newJobTitle}
                            onChange={(e) => {
                              setNewJobTitle(e.target.value)
                              setIsJobPositionOpen(true)
                            }}
                            onFocus={() => setIsJobPositionOpen(true)}
                            placeholder="Select or type job title"
                          />
                          <span className="dropdown-caret">▾</span>
                        </div>
                        {isJobPositionOpen && jobTitleSuggestions.length > 0 && (
                          <div className="autocomplete-menu">
                            {jobTitleSuggestions.map(({ department, title }) => (
                              <button
                                key={`job-title-${department}-${title}`}
                                type="button"
                                className="autocomplete-item"
                                onMouseDown={(e) => {
                                  e.preventDefault()
                                  setNewJobTitle(title)
                                  setNewJobDepartment(department || "")
                                  setIsJobPositionOpen(false)
                                }}
                              >
                                {title}
                              </button>
                            ))}
                        </div>
                      )}
                    </div>
                    </div>

                    <div className="field-group">
                      <label>Plantilla Item No.</label>
                      <input
                        className={requiredInputClass(newJobItemNo)}
                        type="text"
                        value={newJobItemNo}
                        onChange={(e) => setNewJobItemNo(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="modal-grid">
                    <div className="field-group">
                      <label>Employment Type</label>
                      <CustomDropdown
                        className={requiredDropdownClass(newJobType)}
                        options={employmentTypeOptions}
                        value={newJobType}
                        onChange={setNewJobType}
                        placeholder={employmentTypeOptions[0]?.label || "Employment type"}
                      />
                    </div>

                    <div className="field-group">
                      <label>Post Deadline</label>
                      <input
                        className={requiredInputClass(newJobDeadline)}
                        type="date"
                        value={newJobDeadline}
                        onChange={(e) => setNewJobDeadline(e.target.value)}
                      />
                    </div>

                    <div className="field-group">
                      <label>Position Slots</label>
                      <div className="position-slots-control">
                        <select
                          className={requiredInputClass(newPositionsTotal, "position-slots-select")}
                          value={isManySlotsValue(newPositionsTotal) ? "many" : "specific"}
                          onChange={(e) => setNewPositionsTotal(e.target.value === "many" ? "many" : "1")}
                        >
                          <option value="specific">Specific number</option>
                          <option value="many">Many</option>
                        </select>
                        {!isManySlotsValue(newPositionsTotal) && (
                          <input
                            className={requiredInputClass(newPositionsTotal)}
                            type="number"
                            min="1"
                            step="1"
                            inputMode="numeric"
                            pattern="[0-9]*"
                            value={newPositionsTotal}
                            onChange={(e) => setNewPositionsTotal(integerInputValue(e.target.value))}
                            placeholder="e.g., 5"
                          />
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="modal-grid">
                    <div className="field-group create-job-status-wrap">
                      <label>Status</label>
                      <CustomDropdown
                        className={requiredDropdownClass(newJobStatus, "input-dropdown create-job-status")}
                        options={jobStatusOptions}
                        value={newJobStatus}
                        onChange={setNewJobStatus}
                        placeholder="Active"
                      />
                    </div>

                    <div className="field-group">
                      <label>Eligibility</label>
                      <CustomDropdown
                        className={requiredDropdownClass(newJobEligibility, "input-dropdown create-job-eligibility-dropdown")}
                        options={jobEligibilityOptions}
                        value={newJobEligibility}
                        onChange={handleJobEligibilityChange}
                        placeholder="Select eligibility"
                      />
                      {isOtherEligibilitySelected && (
                        <input
                          className={requiredInputClass(newJobCustomEligibility, "create-job-other-eligibility")}
                          type="text"
                          value={newJobCustomEligibility}
                          onChange={(e) => setNewJobCustomEligibility(e.target.value)}
                          placeholder="Enter other eligibility"
                        />
                      )}
                    </div>
                  </div>
                </section>

                <section className="create-job-panel">
                  <div className="create-job-panel-head">
                    <div>
                      <h4>Role Description</h4>
                      <p>What should applicants know about the role?</p>
                    </div>
                  </div>
                  <div className="field-group">
                    <label>Description</label>
                    <textarea
                      className={requiredInputClass(newJobDescription, "create-job-description")}
                      rows={4}
                      ref={descriptionRef}
                      value={newJobDescription}
                      onChange={(e) => setNewJobDescription(e.target.value)}
                      placeholder="Describe the role, responsibilities and what you're looking for...."
                    />
                  </div>
                </section>

                <section className="create-job-panel">
                  <div className="create-job-panel-head">
                    <div>
                      <h4>Requirements</h4>
                      <p>Define qualifications for applicant matching.</p>
                    </div>
                  </div>

                  <div className="field-group">
                    <label>Required Skills</label>
                    <div
                      ref={skillsPickerRef}
                      className="autocomplete create-skills-picker"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <div className="create-skills-input-row">
                        <input
                          className={requiredInputClass(newRequiredSkills, "create-skills-input")}
                          type="text"
                          value={skillDraft}
                          onChange={(e) => {
                            setSkillDraft(e.target.value)
                          }}
                          onFocus={() => setIsSkillsOpen(true)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              e.preventDefault()
                              addRequiredSkill(skillDraft)
                            }
                          }}
                          placeholder="Type a skill and click Add"
                        />
                        <button
                          type="button"
                          className="btn create-skill-add-btn"
                          onClick={() => setIsSkillsOpen((prev) => !prev)}
                        >
                          Add
                        </button>
                      </div>

                      {isSkillsOpen && (
                        <div className="autocomplete-menu create-skills-menu">
                          {skillDraft.trim() && (
                            <button
                              type="button"
                              className="autocomplete-item create-skill-custom"
                              onMouseDown={(e) => {
                                e.preventDefault()
                                addRequiredSkill(skillDraft)
                              }}
                            >
                              Add "{skillDraft.trim()}"
                            </button>
                          )}

                          {filteredSkillSuggestions.length > 0 ? (
                            filteredSkillSuggestions.map((skill) => (
                              <button
                                key={`skill-${skill}`}
                                type="button"
                                className="autocomplete-item"
                                onMouseDown={(e) => {
                                  e.preventDefault()
                                  addRequiredSkill(skill)
                                }}
                              >
                                {skill}
                              </button>
                            ))
                          ) : (
                            <p className="create-skills-empty">No skills found.</p>
                          )}
                        </div>
                      )}
                    </div>

                    {selectedRequiredSkills.length > 0 && (
                      <div className="create-skills-selected">
                        {selectedRequiredSkills.map((skill) => (
                          <span key={`selected-skill-${skill}`} className="create-skill-tag">
                            {skill}
                            <button
                              type="button"
                              className="create-skill-remove"
                              onClick={() => removeRequiredSkill(skill)}
                              aria-label={`Remove ${skill}`}
                            >
                              ×
                            </button>
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="modal-grid">
                    <div className="field-group">
                      <label>Minimum Education</label>
                      <CustomDropdown
                        className={requiredDropdownClass(newMinimumEducation)}
                        options={educationOptions}
                        value={newMinimumEducation}
                        onChange={setNewMinimumEducation}
                        placeholder="Select education level"
                      />
                    </div>

                    <div className="field-group">
                      <label>Minimum Experience (Years)</label>
                      <input
                        className={requiredInputClass(newMinimumExperienceYears)}
                        type="number"
                        min="0"
                        value={newMinimumExperienceYears}
                        onChange={(e) => setNewMinimumExperienceYears(e.target.value)}
                      />
                    </div>

                  </div>

                  <div className="field-group">
                    <label>Scoring Criteria</label>
                    <div className="scoring-weight-grid">
                      {scoringCriteria.map((criterion) => (
                        <div key={criterion.key} className="scoring-weight-field">
                          <span>{criterion.label}</span>
                          <input
                            className={requiredInputClass(newScoringWeights[criterion.key])}
                            type="number"
                            min="0"
                            max="100"
                            value={newScoringWeights[criterion.key]}
                            onChange={(e) => setScoringWeight(criterion.key, e.target.value)}
                          />
                        </div>
                      ))}
                    </div>
                    <div className={`scoring-weight-total ${scoringTotalIsValid ? "valid" : "invalid"}`}>
                      Total: {scoringTotal}% {scoringTotal >= 100 ? "(reduce another criterion to add more)" : ""}
                    </div>
                  </div>

                  <div className="modal-grid">
                    <div className="field-group">
                      <label>{salaryLabel.min}</label>
                      <input
                        className={requiredInputClass(newSalaryMin)}
                        type="number"
                        min="0"
                        step="1"
                        inputMode="numeric"
                        pattern="[0-9]*"
                        value={newSalaryMin}
                        onChange={(e) => setNewSalaryMin(integerInputValue(e.target.value))}
                        placeholder="e.g., 15"
                      />
                    </div>

                    <div className="field-group">
                      <label>{salaryLabel.max}</label>
                      <input
                        className={requiredInputClass(newSalaryMax)}
                        type="number"
                        min="0"
                        value={newSalaryMax}
                        onChange={(e) => setNewSalaryMax(e.target.value)}
                        placeholder={String(newJobType || "").toLowerCase().includes("part") ? "e.g., 150" : "e.g., 30000"}
                      />
                    </div>
                  </div>
                </section>
              </div>
            </div>

            <div className="modal-actions">
              <button className="btn" onClick={isEditingJob ? updateJobPost : createJobPost} disabled={isCreatingJob}>
                {isCreatingJob ? (isEditingJob ? "Saving..." : "Creating...") : (isEditingJob ? "Save Changes" : "Create Job")}
              </button>
              <button className="btn btn-secondary" onClick={closeCreateModal}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}


      {createJobStatus && !isCreateModalOpen && (
        <div className={`toast ${createJobStatus === "success" ? "toast-success" : "toast-fail"}`}>
          {createJobNotice || (createJobStatus === "success" ? "Success" : "Fail")}
        </div>
      )}

      {deleteToast && (
        <div className={`toast ${deleteToast.type === "success" ? "toast-success" : "toast-fail"}`}>
          {deleteToast.message}
        </div>
      )}
    </section>
  )
}

export default JobPostingPage
