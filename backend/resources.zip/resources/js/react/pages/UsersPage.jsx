import React from 'react'
import { useCallback, useEffect, useRef, useState } from "react"
import "../styles/UsersPage.css"
import eyeSolidIcon from "../assets/eye-solid-full.svg"
import eyeRegularIcon from "../assets/eye-regular-full.svg"
import { getArchiveActorHeaders } from "../utils/archiveActor"

const usersPageSize = 10
const positionOptions = [
  { value: "personnel", label: "Personnel" },
  { value: "board", label: "Board" }
]
const pageAccessOptions = [
  { value: "dashboard", label: "Dashboard" },
  { value: "jobs", label: "Jobs" },
  { value: "applicants", label: "Applications" },
  { value: "ratings", label: "Ratings / Evaluation" },
  { value: "profile", label: "Profile" },
  { value: "users", label: "Users" },
  { value: "archive", label: "Archive" },
  { value: "help", label: "Help" }
]
const allPageAccess = pageAccessOptions.map((option) => option.value)
const boardDefaultAccess = ["ratings", "profile", "help"]

function normalizePositionType(value) {
  const normalized = String(value || "").trim().toLowerCase()
  return normalized === "board" ? "board" : "personnel"
}

function getPositionTypeLabel(value) {
  return positionOptions.find((option) => option.value === normalizePositionType(value))?.label || "Personnel"
}

function defaultPageAccessForPosition(value) {
  return normalizePositionType(value) === "board" ? boardDefaultAccess : allPageAccess
}

function normalizePageAccess(value, positionType = "personnel") {
  if (!Array.isArray(value) || value.length === 0) {
    return defaultPageAccessForPosition(positionType)
  }
  const allowed = new Set(allPageAccess)
  const cleaned = Array.from(new Set(value.map((page) => String(page || "").trim().toLowerCase()).filter((page) => allowed.has(page))))
  return cleaned.length ? cleaned : defaultPageAccessForPosition(positionType)
}

function selectedPageAccess(value, positionType = "personnel") {
  if (!Array.isArray(value)) return defaultPageAccessForPosition(positionType)
  const allowed = new Set(allPageAccess)
  return Array.from(new Set(value.map((page) => String(page || "").trim().toLowerCase()).filter((page) => allowed.has(page))))
}

function UsersPage({ currentUser = null, onUsersChanged }) {
  const [jobSeekerUsers, setJobSeekerUsers] = useState([])
  const [employerUsers, setEmployerUsers] = useState([])
  const [isLoadingUsers, setIsLoadingUsers] = useState(false)
  const [jobSeekerSearch, setJobSeekerSearch] = useState("")
  const [employerSearch, setEmployerSearch] = useState("")
  const [activeUserTab, setActiveUserTab] = useState("jobseekers")
  const [jobSeekerPage, setJobSeekerPage] = useState(1)
  const [employerPage, setEmployerPage] = useState(1)
  const [userEditContext, setUserEditContext] = useState(null)
  const [userForm, setUserForm] = useState({
    fullName: "",
    username: "",
    email: "",
    phone: "",
    companyName: "",
    contactName: "",
    idNumber: "",
    positionType: "personnel",
    pageAccess: allPageAccess
  })
  const [confirmDeleteUser, setConfirmDeleteUser] = useState(null)
  const [isEmployerModalOpen, setIsEmployerModalOpen] = useState(false)
  const [showEmployerPassword, setShowEmployerPassword] = useState(false)
  const [employerForm, setEmployerForm] = useState({
    companyName: "",
    contactName: "",
    accountIdentifier: "",
    username: "",
    email: "",
    idNumber: "",
    phone: "",
    password: "",
    positionType: "personnel",
    pageAccess: allPageAccess
  })
  const [toast, setToast] = useState(null)
  const toastTimerRef = useRef(null)

  const showToast = useCallback((message, type = "info", duration = 2600) => {
    if (toastTimerRef.current) {
      window.clearTimeout(toastTimerRef.current)
      toastTimerRef.current = null
    }
    setToast({ message, type })
    if (duration > 0) {
      toastTimerRef.current = window.setTimeout(() => {
        setToast(null)
        toastTimerRef.current = null
      }, duration)
    }
  }, [])

  useEffect(() => {
    return () => {
      if (toastTimerRef.current) {
        window.clearTimeout(toastTimerRef.current)
      }
    }
  }, [])

  const fetchUsers = useCallback(async () => {
    setIsLoadingUsers(true)
    try {
      const [jobSeekerResponse, employerResponse] = await Promise.all([
        fetch("http://localhost:5000/job-seekers/all"),
        fetch("http://localhost:5000/employers")
      ])
      if (!jobSeekerResponse.ok) {
        const payload = await jobSeekerResponse.json().catch(() => null)
        throw new Error(payload?.message || "Failed to load job seekers.")
      }
      if (!employerResponse.ok) {
        const payload = await employerResponse.json().catch(() => null)
        throw new Error(payload?.message || "Failed to load employers.")
      }
      const jobSeekerData = await jobSeekerResponse.json()
      const employerData = await employerResponse.json()
      setJobSeekerUsers(Array.isArray(jobSeekerData) ? jobSeekerData : [])
      setEmployerUsers(Array.isArray(employerData) ? employerData : [])
    } catch (error) {
      showToast(error.message || "Failed to load users.", "fail")
      setJobSeekerUsers([])
      setEmployerUsers([])
    } finally {
      setIsLoadingUsers(false)
    }
  }, [showToast])

  useEffect(() => {
    fetchUsers()
  }, [fetchUsers])

  const formatDate = (value) => {
    const d = new Date(value)
    if (Number.isNaN(d.getTime())) return "-"
    return d.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })
  }

  const isEmailVerified = (user) => Boolean(user.emailVerifiedAt || user.email_verified_at)

  const filteredJobSeekers = jobSeekerUsers.filter((user) => {
    const query = jobSeekerSearch.trim().toLowerCase()
    if (!query) return true
    const haystack = [
      user.fullName,
      user.email,
      user.username,
      user.phone,
      isEmailVerified(user) ? "verified" : "not verified"
    ]
      .filter(Boolean)
      .join(" ")
      .toLowerCase()
    return haystack.includes(query)
  })

  const filteredEmployers = employerUsers.filter((user) => {
    const query = employerSearch.trim().toLowerCase()
    if (!query) return true
    const haystack = [
      user.companyName,
      user.contactName,
      user.email,
      user.username,
      user.idNumber,
      user.id_number,
      user.phone,
      getPositionTypeLabel(user.positionType || user.position_type || user.contactName),
      ...(Array.isArray(user.pageAccess || user.page_access) ? (user.pageAccess || user.page_access) : [])
    ]
      .filter(Boolean)
      .join(" ")
      .toLowerCase()
    return haystack.includes(query)
  })

  const jobSeekerPageCount = Math.max(1, Math.ceil(filteredJobSeekers.length / usersPageSize))
  const employerPageCount = Math.max(1, Math.ceil(filteredEmployers.length / usersPageSize))
  const paginatedJobSeekers = filteredJobSeekers.slice(
    (jobSeekerPage - 1) * usersPageSize,
    jobSeekerPage * usersPageSize
  )
  const paginatedEmployers = filteredEmployers.slice(
    (employerPage - 1) * usersPageSize,
    employerPage * usersPageSize
  )

  useEffect(() => {
    setJobSeekerPage(1)
  }, [jobSeekerSearch])

  useEffect(() => {
    setEmployerPage(1)
  }, [employerSearch])

  useEffect(() => {
    setJobSeekerPage((page) => Math.min(page, jobSeekerPageCount))
  }, [jobSeekerPageCount])

  useEffect(() => {
    setEmployerPage((page) => Math.min(page, employerPageCount))
  }, [employerPageCount])

  const openEditUser = (type, user) => {
    setUserEditContext({ type, user })
    if (type === "jobseeker") {
      setUserForm({
        fullName: user.fullName || "",
        username: user.username || "",
        email: user.email || "",
        phone: user.phone || "",
        companyName: "",
        contactName: "",
        idNumber: "",
        positionType: "personnel",
        pageAccess: allPageAccess
      })
    } else {
      const positionType = normalizePositionType(user.positionType || user.position_type || user.contactName || user.fullName || user.full_name)
      const digitsOnly = String(user.phone || "").replace(/\D/g, "")
      const withoutCountryPrefix = digitsOnly.startsWith("63") ? digitsOnly.slice(2) : digitsOnly
      const withoutLocalPrefix = withoutCountryPrefix.startsWith("0")
        ? withoutCountryPrefix.slice(1)
        : withoutCountryPrefix
      setUserForm({
        fullName: "",
        username: user.username || "",
        email: user.email || "",
        phone: withoutLocalPrefix.slice(0, 10),
        companyName: user.companyName || "",
        contactName: user.contactName || "",
        idNumber: user.idNumber || user.id_number || "",
        positionType,
        pageAccess: normalizePageAccess(user.pageAccess || user.page_access, positionType)
      })
    }
    setToast(null)
  }

  const closeEditUser = () => {
    setUserEditContext(null)
  }

  const saveEditedUser = async () => {
    if (!userEditContext?.user?.id) return
    showToast("Saving...", "info", 1800)
    try {
      if (userEditContext.type === "jobseeker") {
        const response = await fetch(`http://localhost:5000/job-seekers/${userEditContext.user.id}/admin`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            ...getArchiveActorHeaders(currentUser)
          },
          body: JSON.stringify({
            fullName: userForm.fullName,
            username: userForm.username,
            email: userForm.email,
            phone: userForm.phone
          })
        })
        if (!response.ok) {
          const payload = await response.json().catch(() => null)
          throw new Error(payload?.message || "Failed to update job seeker.")
        }
      } else {
        if (!userForm.pageAccess.length) {
          showToast("Select at least one page this personnel account can access.", "fail")
          return
        }
        const response = await fetch(`http://localhost:5000/employers/${userEditContext.user.id}`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            ...getArchiveActorHeaders(currentUser)
          },
          body: JSON.stringify({
            companyName: userForm.companyName,
            contactName: getPositionTypeLabel(userForm.positionType),
            positionType: userForm.positionType,
            pageAccess: userForm.pageAccess,
            username: userForm.username,
            email: userForm.email,
            idNumber: userForm.idNumber,
            phone: userForm.phone
          })
        })
        if (!response.ok) {
          const payload = await response.json().catch(() => null)
          throw new Error(payload?.message || "Failed to update employer.")
        }
      }
      await fetchUsers()
      await onUsersChanged?.()
      showToast("Personnel account updated successfully.", "success")
      setTimeout(() => {
        closeEditUser()
      }, 600)
    } catch (error) {
      showToast(error.message || "Failed to save.", "fail")
    }
  }

  const confirmDelete = (type, user) => {
    setConfirmDeleteUser({ type, user })
  }

  const restoreScrollPosition = (scrollX, scrollY) => {
    window.requestAnimationFrame(() => {
      window.scrollTo(scrollX, scrollY)
    })
  }

  const openEmployerModal = () => {
    setEmployerForm({
      companyName: "",
      contactName: "",
      accountIdentifier: "",
      username: "",
      email: "",
      idNumber: "",
      phone: "",
      password: "",
      positionType: "personnel",
      pageAccess: allPageAccess
    })
    setShowEmployerPassword(false)
    setIsEmployerModalOpen(true)
  }

  const saveEmployer = async () => {
    const phoneDigits = String(employerForm.phone || "").replace(/\D/g, "")
    const withoutCountryPrefix = phoneDigits.startsWith("63") ? phoneDigits.slice(2) : phoneDigits
    const withoutLocalPrefix = withoutCountryPrefix.startsWith("0")
      ? withoutCountryPrefix.slice(1)
      : withoutCountryPrefix
    const normalizedPhone = withoutLocalPrefix ? `+63${withoutLocalPrefix.slice(0, 10)}` : ""
    const idNumber = employerForm.accountIdentifier.trim()
    const emailValue = employerForm.email.trim()
    if (!employerForm.pageAccess.length) {
      showToast("Select at least one page this personnel account can access.", "fail")
      return
    }
    const payload = {
      companyName: employerForm.companyName.trim(),
      contactName: getPositionTypeLabel(employerForm.positionType),
      positionType: employerForm.positionType,
      pageAccess: employerForm.pageAccess,
      username: emailValue,
      email: emailValue,
      idNumber,
      phone: normalizedPhone,
      password: employerForm.password.trim()
    }
    if (!payload.companyName || !idNumber || !emailValue || !payload.password) {
      showToast("Name, ID number, email, and password are required.", "fail")
      return
    }
    showToast("Saving...", "info", 1800)
    try {
      const response = await fetch("http://localhost:5000/employers", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...getArchiveActorHeaders(currentUser)
        },
        body: JSON.stringify(payload)
      })
      if (!response.ok) {
        const err = await response.json().catch(() => null)
        throw new Error(err?.message || "Failed to add Personnel.")
      }
      showToast("Personnel account created successfully.", "success")
      setIsEmployerModalOpen(false)
      await fetchUsers()
      await onUsersChanged?.()
    } catch (error) {
      showToast(error.message || "Failed to add Personnel.", "fail")
    }
  }

  const toggleUserPageAccess = (page) => {
    setUserForm((prev) => {
      const current = selectedPageAccess(prev.pageAccess, prev.positionType)
      const next = current.includes(page)
        ? current.filter((item) => item !== page)
        : [...current, page]
      return { ...prev, pageAccess: next }
    })
  }

  const toggleEmployerPageAccess = (page) => {
    setEmployerForm((prev) => {
      const current = selectedPageAccess(prev.pageAccess, prev.positionType)
      const next = current.includes(page)
        ? current.filter((item) => item !== page)
        : [...current, page]
      return { ...prev, pageAccess: next }
    })
  }


  return (
    <section className="users-page">
      <div className="users-hero">
        <div>
          <p className="users-kicker">User Management</p>
          <h2 className="users-title">Users</h2>
        </div>
      </div>

      <div className="users-tabs" role="tablist" aria-label="User tables">
        <button
          type="button"
          className={`users-tab ${activeUserTab === "jobseekers" ? "is-active" : ""}`}
          onClick={() => setActiveUserTab("jobseekers")}
          role="tab"
          aria-selected={activeUserTab === "jobseekers"}
        >
          Job Seekers
          <span>{jobSeekerUsers.length}</span>
        </button>
        <button
          type="button"
          className={`users-tab ${activeUserTab === "personnel" ? "is-active" : ""}`}
          onClick={() => setActiveUserTab("personnel")}
          role="tab"
          aria-selected={activeUserTab === "personnel"}
        >
          HR Personnel
          <span>{employerUsers.length}</span>
        </button>
      </div>

      {activeUserTab === "jobseekers" && (
      <section className="users-card users-card-employers">
        <div className="users-card-head">
          <h3>Job Seeker Users</h3>
          <input
            className="users-search"
            type="text"
            placeholder="Search job seekers..."
            value={jobSeekerSearch}
            onChange={(e) => setJobSeekerSearch(e.target.value)}
          />
        </div>
        <div className="table-wrap users-table-wrap users-table-inside">
          <div className="users-table-scroll">
            <table className="records-table">
            <thead>
              <tr>
                <th>#</th>
                <th>User</th>
                <th>ID Number</th>
                <th>Phone</th>
                <th>Username</th>
                <th>Email</th>
                <th>Status</th>
                <th>Created</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {isLoadingUsers ? (
                <tr>
                  <td colSpan={9} className="users-empty">
                    <span className="loading-indicator"><span className="loading-spinner" aria-hidden="true" />Loading job seekers...</span>
                  </td>
                </tr>
              ) : filteredJobSeekers.length === 0 ? (
                <tr>
                  <td colSpan={9} className="users-empty">No job seeker users found.</td>
                </tr>
              ) : (
                paginatedJobSeekers.map((user, index) => {
                  const verified = isEmailVerified(user)
                  return (
                    <tr key={`jobseeker-${user.id}`}>
                      <td>{((jobSeekerPage - 1) * usersPageSize) + index + 1}</td>
                      <td>
                        <div className="applicant-cell">
                          <strong>{user.fullName || "-"}</strong>
                          <span>{user.email || "-"}</span>
                        </div>
                      </td>
                      <td>{user.idNumber || user.id_number || "-"}</td>
                      <td>{user.phone || "-"}</td>
                      <td>{user.username || "-"}</td>
                      <td>{user.email || "-"}</td>
                      <td>
                        <span className={`users-status-badge ${verified ? "is-verified" : "is-unverified"}`}>
                          {verified ? "Verified" : "Not Verified"}
                        </span>
                        </td>
                        <td>{formatDate(user.createdAt)}</td>
                        <td className="actions-cell">
                          <button
                            type="button"
                            className="action-btn users-delete-action"
                            onClick={(e) => {
                              e.stopPropagation()
                              confirmDelete("jobseeker", user)
                            }}
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    )
                })
              )}
            </tbody>
          </table>
          </div>
        </div>
        {filteredJobSeekers.length > usersPageSize && (
          <div className="users-pagination">
            <span>Page {jobSeekerPage} of {jobSeekerPageCount}</span>
            <div>
              <button
                type="button"
                onClick={() => setJobSeekerPage((page) => Math.max(1, page - 1))}
                disabled={jobSeekerPage === 1}
              >
                Previous
              </button>
              <button
                type="button"
                onClick={() => setJobSeekerPage((page) => Math.min(jobSeekerPageCount, page + 1))}
                disabled={jobSeekerPage === jobSeekerPageCount}
              >
                Next
              </button>
            </div>
          </div>
        )}
      </section>
      )}

      {activeUserTab === "personnel" && (
      <section className="users-card users-card-employers">
        <div className="users-card-head">
          <h3>HR Personnel Users</h3>
          <div className="users-actions">
            <input
              className="users-search"
              type="text"
              placeholder="Search Personnel..."
              value={employerSearch}
              onChange={(e) => setEmployerSearch(e.target.value)}
            />
            <button type="button" className="js-outline-btn users-add-btn" onClick={openEmployerModal}>Add Personnel</button>
          </div>
        </div>
        <div className="table-wrap users-table-wrap users-table-inside">
          <div className="users-table-scroll">
            <table className="records-table">
            <thead>
              <tr>
                <th>#</th>
                <th>ID Number</th>
                <th>Name</th>
                <th>Position</th>
                <th>Phone</th>
                <th>Username</th>
                <th>Email</th>
                <th>Created</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {isLoadingUsers ? (
                <tr>
                  <td colSpan={9} className="users-empty">
                    <span className="loading-indicator"><span className="loading-spinner" aria-hidden="true" />Loading employers...</span>
                  </td>
                </tr>
              ) : filteredEmployers.length === 0 ? (
                <tr>
                  <td colSpan={9} className="users-empty">No Personnel users found.</td>
                </tr>
              ) : (
                paginatedEmployers.map((user, index) => (
                  <tr key={`employer-${user.id}`}>
                    <td>{((employerPage - 1) * usersPageSize) + index + 1}</td>
                    <td>{user.idNumber || user.id_number || "-"}</td>
                    <td>
                      <div className="applicant-cell">
                        <strong>{user.companyName || "-"}</strong>
                        <span>{user.email || "-"}</span>
                      </div>
                    </td>
                    <td>{getPositionTypeLabel(user.positionType || user.position_type || user.contactName)}</td>
                    <td>{user.phone || "-"}</td>
                    <td>{user.username || "-"}</td>
                    <td>{user.email || "-"}</td>
                    <td>{formatDate(user.createdAt)}</td>
                    <td className="actions-cell users-inline-actions">
                      <button
                        type="button"
                        className="action-btn users-edit-action"
                        onClick={(e) => {
                          e.stopPropagation()
                          openEditUser("employer", user)
                        }}
                      >
                        Edit
                      </button>
                      <button
                        type="button"
                        className="action-btn users-delete-action"
                        onClick={(e) => {
                          e.stopPropagation()
                          confirmDelete("employer", user)
                        }}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
            </table>
          </div>
        </div>
        {filteredEmployers.length > usersPageSize && (
          <div className="users-pagination">
            <span>Page {employerPage} of {employerPageCount}</span>
            <div>
              <button
                type="button"
                onClick={() => setEmployerPage((page) => Math.max(1, page - 1))}
                disabled={employerPage === 1}
              >
                Previous
              </button>
              <button
                type="button"
                onClick={() => setEmployerPage((page) => Math.min(employerPageCount, page + 1))}
                disabled={employerPage === employerPageCount}
              >
                Next
              </button>
            </div>
          </div>
        )}
      </section>
      )}

      {userEditContext && (
        <div className="modal-overlay" onClick={closeEditUser}>
          <div className="modal-card modal-modern js-edit-modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Edit {userEditContext.type === "jobseeker" ? "Job Seeker" : "Personnel"}</h3>
              <button type="button" className="close-x" onClick={closeEditUser}>×</button>
            </div>
            <div className="js-edit-body">
              {userEditContext.type === "jobseeker" ? (
                <>
                  <div className="modal-grid">
                    <div className="field-group">
                      <label>Full Name</label>
                      <input
                        className="input"
                        value={userForm.fullName}
                        onChange={(e) => setUserForm((prev) => ({ ...prev, fullName: e.target.value }))}
                      />
                    </div>
                    <div className="field-group">
                      <label>Username</label>
                      <input
                        className="input"
                        value={userForm.username}
                        onChange={(e) => setUserForm((prev) => ({ ...prev, username: e.target.value }))}
                      />
                    </div>
                  </div>
                  <div className="modal-grid">
                    <div className="field-group">
                      <label>Email</label>
                      <input
                        className="input"
                        type="email"
                        value={userForm.email}
                        onChange={(e) => setUserForm((prev) => ({ ...prev, email: e.target.value }))}
                      />
                    </div>
                    <div className="field-group">
                      <label>Phone</label>
                      <input
                        className="input"
                        value={userForm.phone}
                        onChange={(e) => setUserForm((prev) => ({ ...prev, phone: e.target.value }))}
                      />
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div className="modal-grid">
                    <div className="field-group">
                      <label>Name</label>
                      <input
                        className="input"
                        value={userForm.companyName}
                        onChange={(e) => setUserForm((prev) => ({ ...prev, companyName: e.target.value }))}
                      />
                    </div>
                    <div className="field-group">
                      <label>Position</label>
                      <select
                        className="input"
                        value={userForm.positionType}
                        onChange={(e) => {
                          const positionType = e.target.value
                          setUserForm((prev) => ({
                            ...prev,
                            positionType,
                            pageAccess: defaultPageAccessForPosition(positionType)
                          }))
                        }}
                      >
                        {positionOptions.map((option) => (
                          <option key={option.value} value={option.value}>{option.label}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div className="modal-grid">
                    <div className="field-group">
                      <label>ID Number</label>
                      <input
                        className="input"
                        value={userForm.idNumber}
                        onChange={(e) => setUserForm((prev) => ({ ...prev, idNumber: e.target.value }))}
                      />
                    </div>
                    <div className="field-group">
                      <label>Username</label>
                      <input
                        className="input"
                        type="text"
                        value={userForm.username}
                        onChange={(e) => setUserForm((prev) => ({ ...prev, username: e.target.value }))}
                      />
                    </div>
                  </div>
                  <div className="modal-grid">
                    <div className="field-group">
                      <label>Email</label>
                      <input
                        className="input"
                        type="email"
                        value={userForm.email}
                        onChange={(e) => setUserForm((prev) => ({ ...prev, email: e.target.value }))}
                      />
                    </div>
                    <div className="field-group">
                      <label>Phone</label>
                      <input
                        className="input"
                        inputMode="numeric"
                        value={`+63${userForm.phone}`}
                        onChange={(e) => {
                          const digitsOnly = String(e.target.value || "").replace(/\D/g, "")
                          const withoutCountryPrefix = digitsOnly.startsWith("63") ? digitsOnly.slice(2) : digitsOnly
                          const withoutLocalPrefix = withoutCountryPrefix.startsWith("0")
                            ? withoutCountryPrefix.slice(1)
                            : withoutCountryPrefix
                          setUserForm((prev) => ({ ...prev, phone: withoutLocalPrefix.slice(0, 10) }))
                        }}
                      />
                    </div>
                  </div>
                  <div className="field-group users-access-group">
                    <label>Page Access</label>
                    <div className="users-access-grid">
                      {pageAccessOptions.map((option) => (
                        <label key={`edit-access-${option.value}`} className="users-access-option">
                          <input
                            type="checkbox"
                            checked={selectedPageAccess(userForm.pageAccess, userForm.positionType).includes(option.value)}
                            onChange={() => toggleUserPageAccess(option.value)}
                          />
                          <span>{option.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
            <div className="modal-actions">
              <button className="btn" onClick={saveEditedUser}>Save</button>
              <button className="btn btn-secondary" onClick={closeEditUser}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {confirmDeleteUser && (
        <div
          className="modal-overlay"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              setConfirmDeleteUser(null)
            }
          }}
        >
          <div className="modal-card">
            <h3>Delete {confirmDeleteUser.type === "jobseeker" ? "Job Seeker" : "Personnel"}</h3>
            <p>Are you sure you want to delete this user? This action cannot be undone.</p>
            <div className="modal-actions">
              <button type="button" className="btn btn-secondary" onClick={() => setConfirmDeleteUser(null)}>
                Cancel
              </button>
              <button
                type="button"
                className="btn btn-danger"
                onClick={async () => {
                  const target = confirmDeleteUser
                  const scrollX = window.scrollX
                  const scrollY = window.scrollY
                  setConfirmDeleteUser(null)
                  if (!target?.user?.id) return
                  try {
                    if (target.type === "jobseeker") {
                      const response = await fetch(`http://localhost:5000/job-seekers/${target.user.id}`, {
                        method: "DELETE",
                        headers: getArchiveActorHeaders(currentUser)
                      })
                      if (!response.ok) {
                        const payload = await response.json().catch(() => null)
                        throw new Error(payload?.message || "Failed to delete job seeker.")
                      }
                    } else {
                      const response = await fetch(`http://localhost:5000/employers/${target.user.id}`, {
                        method: "DELETE",
                        headers: getArchiveActorHeaders(currentUser)
                      })
                      if (!response.ok) {
                        const payload = await response.json().catch(() => null)
                        throw new Error(payload?.message || "Failed to delete employer.")
                      }
                    }
                    await fetchUsers()
                    await onUsersChanged?.()
                    restoreScrollPosition(scrollX, scrollY)
                    showToast(
                      `${target.type === "jobseeker" ? "Job seeker" : "Personnel"} deleted successfully.`,
                      "success"
                    )
                  } catch (error) {
                    restoreScrollPosition(scrollX, scrollY)
                    showToast(error.message || "Failed to delete user.", "fail")
                  }
                }}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {isEmployerModalOpen && (
        <div className="modal-overlay" onClick={() => setIsEmployerModalOpen(false)}>
          <div className="modal-card modal-modern js-edit-modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Add HR Personnel</h3>
              <button type="button" className="close-x" onClick={() => setIsEmployerModalOpen(false)}>×</button>
            </div>
            <div className="js-edit-body">
              <div className="modal-grid">
                <div className="field-group">
                  <label>Name</label>
                  <input
                    placeholder="eg. John"
                    className="input"
                    value={employerForm.companyName}
                    onChange={(e) => setEmployerForm((prev) => ({ ...prev, companyName: e.target.value }))}
                  />
                </div>
                <div className="field-group">
                  <label>Position</label>
                  <select
                    className="input"
                    value={employerForm.positionType}
                    onChange={(e) => {
                      const positionType = e.target.value
                      setEmployerForm((prev) => ({
                        ...prev,
                        positionType,
                        pageAccess: defaultPageAccessForPosition(positionType)
                      }))
                    }}
                  >
                    {positionOptions.map((option) => (
                      <option key={option.value} value={option.value}>{option.label}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="modal-grid">
                <div className="field-group users-account-group">
                  <label>ID Number</label>
                  <input
                    className="input"
                    placeholder="Enter ID number"
                    value={employerForm.accountIdentifier}
                    onChange={(e) => setEmployerForm((prev) => ({ ...prev, accountIdentifier: e.target.value }))}
                  />
                </div>
                <div className="field-group">
                  <label>Email</label>
                  <input
                    className="input"
                    type="email"
                    placeholder="Enter email"
                    value={employerForm.email}
                    onChange={(e) => setEmployerForm((prev) => ({ ...prev, email: e.target.value }))}
                  />
                </div>
              </div>
              <div className="modal-grid users-contact-row">
                <div className="field-group">
                  <label>Phone</label>
                  <input
                    className="input"
                    inputMode="numeric"
                    value={`+63${employerForm.phone}`}
                    onChange={(e) => {
                      const digitsOnly = String(e.target.value || "").replace(/\D/g, "")
                      const withoutCountryPrefix = digitsOnly.startsWith("63") ? digitsOnly.slice(2) : digitsOnly
                      const withoutLocalPrefix = withoutCountryPrefix.startsWith("0")
                        ? withoutCountryPrefix.slice(1)
                        : withoutCountryPrefix
                      setEmployerForm((prev) => ({ ...prev, phone: withoutLocalPrefix.slice(0, 10) }))
                    }}
                  />
                </div>
                <div className="field-group">
                  <label>Password</label>
                  <div className={`password-field-row ${showEmployerPassword ? "is-visible" : ""}`}>
                    <input
                      className="input"
                      type={showEmployerPassword ? "text" : "password"}
                      value={employerForm.password}
                      onChange={(e) => setEmployerForm((prev) => ({ ...prev, password: e.target.value }))}
                    />
                    <span
                      className={`password-toggle-icon ${showEmployerPassword ? "is-active" : ""}`}
                      role="button"
                      tabIndex={0}
                      aria-label={showEmployerPassword ? "Hide password" : "Show password"}
                      onClick={() => setShowEmployerPassword((prev) => !prev)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" || e.key === " ") {
                          e.preventDefault()
                          setShowEmployerPassword((prev) => !prev)
                        }
                      }}
                      >
                        <img src={showEmployerPassword ? eyeSolidIcon : eyeRegularIcon} alt="" />
                      </span>
                  </div>
                </div>
              </div>
              <div className="field-group users-access-group">
                <label>Page Access</label>
                <div className="users-access-grid">
                  {pageAccessOptions.map((option) => (
                    <label key={`new-access-${option.value}`} className="users-access-option">
                      <input
                        type="checkbox"
                        checked={selectedPageAccess(employerForm.pageAccess, employerForm.positionType).includes(option.value)}
                        onChange={() => toggleEmployerPageAccess(option.value)}
                      />
                      <span>{option.label}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
            <div className="modal-actions">
              <button className="btn" onClick={saveEmployer}>Save</button>
              <button className="btn btn-secondary" onClick={() => setIsEmployerModalOpen(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div className={`toast ${toast.type === "success" ? "toast-success" : toast.type === "fail" ? "toast-fail" : "toast-info"}`}>
          {toast.message}
        </div>
      )}

    </section>
  )
}

export default UsersPage
