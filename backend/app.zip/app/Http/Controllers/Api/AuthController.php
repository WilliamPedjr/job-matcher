<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ActivityLog;
use App\Models\Employer;
use App\Models\JobSeeker;
use App\Models\User;
use App\Notifications\JobSeekerEmailVerificationNotification;
use App\Services\RecaptchaService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use Illuminate\Support\Str;

class AuthController extends Controller
{
    private const SESSION_GUARDS = ['web', 'employer', 'job_seeker'];

    public function session(Request $request): JsonResponse
    {
        if ($user = Auth::guard('web')->user()) {
            return response()->json([
                'authenticated' => true,
                'user' => $this->serializeStaff($user),
            ]);
        }

        if ($employer = Auth::guard('employer')->user()) {
            return response()->json([
                'authenticated' => true,
                'user' => [
                    ...$this->serializeEmployer($employer),
                    'role' => 'employer',
                ],
            ]);
        }

        if ($jobSeeker = Auth::guard('job_seeker')->user()) {
            return response()->json([
                'authenticated' => true,
                'user' => [
                    ...$this->serializeJobSeeker($jobSeeker),
                    'role' => 'jobseeker',
                ],
            ]);
        }

        return response()->json([
            'authenticated' => false,
            'user' => null,
        ]);
    }

    public function verifyRecaptcha(Request $request, RecaptchaService $recaptchaService): JsonResponse
    {
        $data = $request->validate([
            'token' => ['required', 'string'],
        ]);

        $result = $recaptchaService->verify(
            $data['token'],
            $request->ip()
        );

        return response()->json($result);
    }

    public function logout(Request $request): JsonResponse
    {
        foreach (self::SESSION_GUARDS as $guard) {
            $user = Auth::guard($guard)->user();
            if (!$user) {
                continue;
            }

            $role = match ($guard) {
                'web' => Str::lower(trim((string) ($user->role ?? 'staff'))) ?: 'staff',
                'employer' => 'employer',
                'job_seeker' => 'jobseeker',
                default => 'user',
            };
            $name = $user->name ?? $user->full_name ?? $user->company_name ?? $user->email ?? 'Account';

            ActivityLog::record('auth.logged_out', "{$name} logged out.", $request, [
                'subject_type' => $guard === 'job_seeker' ? 'job_seeker' : ($guard === 'employer' ? 'personnel' : 'user'),
                'subject_id' => $user->id ?? null,
                'subject_name' => $name,
                'actor_name' => $name,
                'actor_email' => $user->email ?? null,
                'actor_role' => $role,
            ]);

            break;
        }

        foreach (self::SESSION_GUARDS as $guard) {
            Auth::guard($guard)->logout();
        }

        if ($request->hasSession()) {
            $request->session()->invalidate();
            $request->session()->regenerateToken();
        }

        return response()->json([
            'message' => 'Logged out successfully.',
        ]);
    }

    public function employerLogin(Request $request): JsonResponse
    {
        $data = $request->validate([
            'identifier' => ['required', 'string'],
            'password' => ['required', 'string'],
            'remember' => ['nullable', 'boolean'],
        ]);

        $identifier = Str::lower(trim($data['identifier']));
        $employer = Employer::query()
            ->whereRaw('LOWER(email) = ?', [$identifier])
            ->orWhereRaw('LOWER(username) = ?', [$identifier])
            ->orWhereRaw('LOWER(id_number) = ?', [$identifier])
            ->orWhereRaw('LOWER(company_name) = ?', [$identifier])
            ->first();

        if (!$employer) {
            return response()->json(['message' => "Email or username doesn't exist."], 401);
        }

        if (!$this->passwordMatchesAndUpgrades($data['password'], $employer)) {
            return response()->json(['message' => 'Password is incorrect.'], 401);
        }

        $this->startSession($request, 'employer', $employer, (bool) ($data['remember'] ?? false));
        ActivityLog::record('auth.logged_in', "{$employer->company_name} logged in.", $request, [
            'subject_type' => 'personnel',
            'subject_id' => $employer->id,
            'subject_name' => $employer->company_name,
            'actor_name' => $employer->company_name,
            'actor_email' => $employer->email,
            'actor_role' => 'employer',
        ]);

        return response()->json([
            ...$this->serializeEmployer($employer),
            'role' => 'employer',
        ]);
    }

    public function staffRegister(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', 'string', 'min:8', 'max:72', 'confirmed'],
            'role' => ['nullable', 'string', Rule::in(['admin', 'staff', 'employer'])],
        ]);

        $user = User::query()->create([
            'name' => trim($data['name']),
            'email' => Str::lower(trim($data['email'])),
            'password' => Hash::make($data['password']),
            'role' => $data['role'] ?? 'staff',
        ]);

        ActivityLog::record('personnel.created', "Added personnel account for {$user->name}.", $request, [
            'subject_type' => 'personnel',
            'subject_id' => $user->id,
            'subject_name' => $user->name,
            'metadata' => [
                'email' => $user->email,
                'role' => $user->role,
            ],
        ]);

        return response()->json([
            'message' => 'Personnel registered successfully.',
            'user' => $this->serializeStaff($user),
        ], 201);
    }

    public function staffLogin(Request $request): JsonResponse
    {
        $data = $request->validate([
            'email' => ['required', 'string'],
            'password' => ['required', 'string'],
            'remember' => ['nullable', 'boolean'],
        ]);

        $identifier = Str::lower(trim($data['email']));

        $user = User::query()
            ->whereRaw('LOWER(email) = ?', [$identifier])
            ->orWhereRaw('LOWER(username) = ?', [$identifier])
            ->first();

        if ($user && Hash::check($data['password'], (string) $user->password)) {
            $this->startSession($request, 'web', $user, (bool) ($data['remember'] ?? false));
            $role = Str::lower(trim((string) ($user->role ?? 'staff'))) ?: 'staff';
            ActivityLog::record('auth.logged_in', "{$user->name} logged in.", $request, [
                'subject_type' => 'user',
                'subject_id' => $user->id,
                'subject_name' => $user->name,
                'actor_name' => $user->name,
                'actor_email' => $user->email,
                'actor_role' => $role,
            ]);

            return response()->json($this->serializeStaff($user));
        }

        $employer = Employer::query()
            ->whereRaw('LOWER(email) = ?', [$identifier])
            ->orWhereRaw('LOWER(username) = ?', [$identifier])
            ->orWhereRaw('LOWER(id_number) = ?', [$identifier])
            ->orWhereRaw('LOWER(company_name) = ?', [$identifier])
            ->first();

        if ($employer && $this->passwordMatchesAndUpgrades($data['password'], $employer)) {
            $this->startSession($request, 'employer', $employer, (bool) ($data['remember'] ?? false));
            ActivityLog::record('auth.logged_in', "{$employer->company_name} logged in.", $request, [
                'subject_type' => 'personnel',
                'subject_id' => $employer->id,
                'subject_name' => $employer->company_name,
                'actor_name' => $employer->company_name,
                'actor_email' => $employer->email,
                'actor_role' => 'employer',
            ]);

            return response()->json([
                ...$this->serializeEmployer($employer),
                'role' => 'employer',
            ]);
        }

        if (!$user && !$employer) {
            return response()->json(['message' => "Email or username doesn't exist."], 401);
        }

        return response()->json(['message' => 'Password is incorrect.'], 401);
    }

    public function staffMe(Request $request): JsonResponse
    {
        $id = (int) $request->query('id', 0);
        if ($id <= 0) {
            return response()->json(['message' => 'Missing personnel id.'], 422);
        }

        $user = User::query()->find($id);
        if (!$user) {
            return response()->json(['message' => 'Personnel not found.'], 404);
        }

        return response()->json($this->serializeStaff($user));
    }

    public function updateStaffMe(Request $request): JsonResponse
    {
        $id = (int) ($request->input('id') ?: $request->query('id', 0));
        if ($id <= 0) {
            return response()->json(['message' => 'Missing personnel id.'], 422);
        }

        $user = User::query()->find($id);
        if (!$user) {
            return response()->json(['message' => 'Personnel not found.'], 404);
        }

        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', Rule::unique('users', 'email')->ignore($user->id)],
            'username' => ['nullable', 'string', 'max:255', Rule::unique('users', 'username')->ignore($user->id)],
            'phone' => ['nullable', 'string', 'max:30'],
            'password' => ['nullable', 'string', 'min:8', 'max:72'],
        ]);

        $user->name = trim($data['name']);
        $user->email = Str::lower(trim($data['email']));
        $user->username = $this->nullableTrim($data['username'] ?? null);
        $user->phone = $data['phone'] ?? null;
        if (!empty($data['password'])) {
            $user->password = Hash::make($data['password']);
        }
        $user->save();

        ActivityLog::record('personnel.profile_updated', "Updated personnel profile for {$user->name}.", $request, [
            'subject_type' => 'personnel',
            'subject_id' => $user->id,
            'subject_name' => $user->name,
            'metadata' => [
                'email' => $user->email,
                'username' => $user->username,
                'phone' => $user->phone,
                'role' => $user->role,
            ],
        ]);

        return response()->json($this->serializeStaff($user));
    }

    public function jobSeekerRegister(Request $request): JsonResponse
    {
        $data = $request->validate([
            'fullName' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', 'unique:job_seekers,email'],
            'username' => ['nullable', 'string', 'max:255', 'unique:job_seekers,username'],
            'phone' => ['nullable', 'string', 'max:30'],
            'status' => ['nullable', 'string', 'max:255'],
            'address' => ['nullable', 'string', 'max:255'],
            'aboutText' => ['nullable', 'string'],
            'about_text' => ['nullable', 'string'],
            'password' => ['required', 'string', 'min:8', 'max:72'],
            'confirmPassword' => ['nullable', 'string'],
        ]);

        if (($data['confirmPassword'] ?? $data['password']) !== $data['password']) {
            return response()->json(['message' => 'Passwords do not match.'], 422);
        }

        if (
            !preg_match('/[A-Z]/', $data['password']) ||
            !preg_match('/\d/', $data['password']) ||
            !preg_match('/[^A-Za-z0-9]/', $data['password'])
        ) {
            return response()->json(['message' => 'Password must include a capital letter, a number, and a special character.'], 422);
        }

        $jobSeeker = JobSeeker::create([
            'full_name' => $data['fullName'],
            'email' => Str::lower(trim($data['email'])),
            'username' => $data['username'] ?? null,
            'phone' => $data['phone'] ?? null,
            'status' => 'active',
            'address' => $data['address'] ?? null,
            'about_text' => $data['about_text'] ?? $data['aboutText'] ?? null,
            'password' => Hash::make($data['password']),
        ]);
        $jobSeeker->forceFill([
            'id_number' => $this->formatJobSeekerIdNumber($jobSeeker->id),
            'email_verified_at' => null,
            'email_verification_token' => $this->makeJobSeekerEmailVerificationToken(),
            'email_verification_sent_at' => now(),
        ])->save();

        $jobSeeker->notify(new JobSeekerEmailVerificationNotification(
            url("/job-seeker/verify-email/{$jobSeeker->email_verification_token}")
        ));

        ActivityLog::record('job_seeker.created', "New job seeker account created for {$jobSeeker->full_name}.", $request, [
            'subject_type' => 'job_seeker',
            'subject_id' => $jobSeeker->id,
            'subject_name' => $jobSeeker->full_name,
            'actor_name' => $jobSeeker->full_name,
            'actor_email' => $jobSeeker->email,
            'actor_role' => 'jobseeker',
            'metadata' => [
                'email' => $jobSeeker->email,
            ],
        ]);

        return response()->json([
            'message' => 'Job seeker registered successfully.',
            'jobSeeker' => $this->serializeJobSeeker($jobSeeker),
        ], 201);
    }

    public function jobSeekerLogin(Request $request): JsonResponse
    {
        $data = $request->validate([
            'identifier' => ['required', 'string'],
            'password' => ['required', 'string'],
            'remember' => ['nullable', 'boolean'],
        ]);

        $identifier = Str::lower(trim($data['identifier']));
        $jobSeeker = JobSeeker::query()
            ->whereRaw('LOWER(email) = ?', [$identifier])
            ->orWhereRaw('LOWER(username) = ?', [$identifier])
            ->orWhereRaw('LOWER(id_number) = ?', [$identifier])
            ->first();

        if (!$jobSeeker) {
            return response()->json(['message' => "Email or username doesn't exist."], 401);
        }

        if (!$this->passwordMatchesAndUpgrades($data['password'], $jobSeeker)) {
            return response()->json(['message' => 'Password is incorrect.'], 401);
        }

        if (!$jobSeeker->email_verified_at) {
            return response()->json([
                'message' => 'Please verify your email before logging in.',
            ], 403);
        }

        if (Str::lower((string) $jobSeeker->status) !== 'active') {
            $jobSeeker->status = 'active';
            $jobSeeker->save();
        }

        $this->startSession($request, 'job_seeker', $jobSeeker, (bool) ($data['remember'] ?? false));

        return response()->json($this->serializeJobSeeker($jobSeeker));
    }

    public function verifyJobSeekerEmail(string $token)
    {
        $jobSeeker = JobSeeker::query()
            ->where('email_verification_token', $token)
            ->first();

        if (!$jobSeeker) {
            return redirect('/job-seeker/email-verification?status=invalid');
        }

        $jobSeeker->forceFill([
            'email_verified_at' => $jobSeeker->email_verified_at ?: now(),
            'email_verification_token' => null,
        ])->save();

        return redirect('/job-seeker/email-verification?status=verified');
    }

    private function startSession(Request $request, string $guard, object $user, bool $remember = false): void
    {
        foreach (self::SESSION_GUARDS as $sessionGuard) {
            Auth::guard($sessionGuard)->logout();
        }

        Auth::guard($guard)->login($user, $remember);

        if ($request->hasSession()) {
            $request->session()->regenerate();
        }
    }

    private function serializeEmployer(Employer $employer): array
    {
        return [
            'id' => $employer->id,
            'company_name' => $employer->company_name,
            'companyName' => $employer->company_name,
            'full_name' => $employer->full_name,
            'fullName' => $employer->full_name,
            'position_type' => $employer->position_type ?: 'personnel',
            'positionType' => $employer->position_type ?: 'personnel',
            'page_access' => $employer->page_access,
            'pageAccess' => $employer->page_access,
            'email' => $employer->email,
            'username' => $employer->username,
            'id_number' => $employer->id_number,
            'idNumber' => $employer->id_number,
            'phone' => $employer->phone,
        ];
    }

    private function serializeStaff(User $user): array
    {
        return [
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'username' => $user->username,
            'phone' => $user->phone,
            'role' => Str::lower(trim((string) ($user->role ?? 'staff'))) ?: 'staff',
            'created_at' => $user->created_at?->toISOString(),
            'createdAt' => $user->created_at?->toISOString(),
        ];
    }

    private function nullableTrim(mixed $value): ?string
    {
        if ($value === null) {
            return null;
        }

        $trimmed = trim((string) $value);
        return $trimmed === '' ? null : $trimmed;
    }

    private function serializeJobSeeker(JobSeeker $jobSeeker): array
    {
        return [
            'id' => $jobSeeker->id,
            'id_number' => $jobSeeker->id_number,
            'idNumber' => $jobSeeker->id_number,
            'full_name' => $jobSeeker->full_name,
            'fullName' => $jobSeeker->full_name,
            'email' => $jobSeeker->email,
            'email_verified_at' => $jobSeeker->email_verified_at?->toISOString(),
            'emailVerifiedAt' => $jobSeeker->email_verified_at?->toISOString(),
            'username' => $jobSeeker->username,
            'phone' => $jobSeeker->phone,
            'status' => $jobSeeker->status,
            'address' => $jobSeeker->address,
            'about_text' => $jobSeeker->about_text,
            'aboutText' => $jobSeeker->about_text,
            'created_at' => $jobSeeker->created_at?->toISOString(),
            'createdAt' => $jobSeeker->created_at?->toISOString(),
            'updated_at' => $jobSeeker->updated_at?->toISOString(),
            'updatedAt' => $jobSeeker->updated_at?->toISOString(),
        ];
    }

    private function formatJobSeekerIdNumber(int $id): string
    {
        return sprintf('LNU-%06d', $id);
    }

    private function makeJobSeekerEmailVerificationToken(): string
    {
        do {
            $token = Str::random(64);
        } while (JobSeeker::query()->where('email_verification_token', $token)->exists());

        return $token;
    }

    private function passwordMatchesAndUpgrades(string $plainPassword, object $user): bool
    {
        $storedPassword = (string) ($user->password ?? '');
        if ($storedPassword === '') {
            return false;
        }

        if (Hash::check($plainPassword, $storedPassword)) {
            return true;
        }

        if ($this->looksLikeHashedPassword($storedPassword)) {
            return false;
        }

        if (!hash_equals($storedPassword, $plainPassword)) {
            return false;
        }

        $user->password = Hash::make($plainPassword);
        $user->save();

        return true;
    }

    private function looksLikeHashedPassword(string $password): bool
    {
        return preg_match('/^(\\$2y\\$|\\$2a\\$|\\$2b\\$|\\$argon2i\\$|\\$argon2id\\$)/', $password) === 1;
    }
}
