<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Employer;
use App\Models\Job;
use App\Models\JobSeeker;
use App\Models\Upload;
use Illuminate\Http\JsonResponse;

class LandingController extends Controller
{
    public function summary(): JsonResponse
    {
        Job::closeExpiredActiveJobs();

        $jobsQuery = Job::query();
        $activeJobsQuery = Job::query()->whereRaw('LOWER(status) = ?', ['active']);

        $featuredJobs = $activeJobsQuery
            ->orderByDesc('id')
            ->limit(4)
            ->get()
            ->map(fn (Job $job) => $this->serializeJob($job))
            ->values();

        $activeJobs = $activeJobsQuery->count();
        $remoteOrHybridJobs = Job::query()
            ->where(function ($query) {
                $query->whereRaw('LOWER(location) LIKE ?', ['%remote%'])
                    ->orWhereRaw('LOWER(location) LIKE ?', ['%hybrid%']);
            })
            ->count();

        $applications = Upload::query()->applications()->count();
        $reviewedApplications = Upload::query()->applications()->whereNotNull('match_score')->count();
        $averageMatchScore = Upload::query()->applications()->whereNotNull('match_score')->avg('match_score');

        return response()->json([
            'summary' => [
                'total_jobs' => $jobsQuery->count(),
                'active_jobs' => $activeJobs,
                'total_job_seekers' => JobSeeker::query()->count(),
                'total_employers' => Employer::query()->count(),
                'total_applications' => $applications,
                'reviewed_applications' => $reviewedApplications,
                'remote_or_hybrid_jobs' => $remoteOrHybridJobs,
                'average_match_score' => round((float) ($averageMatchScore ?? 0), 2),
            ],
            'featured_jobs' => $featuredJobs,
        ]);
    }

    private function serializeJob(Job $job): array
    {
        $skills = array_values(array_filter(array_map(
            fn ($skill) => trim((string) $skill),
            preg_split('/[,;\n|]+/', (string) $job->required_skills) ?: []
        )));
        $publicSkills = array_values(array_filter(
            $skills,
            fn ($skill) => !in_array($skill, ['__MATCH_ALL__', '__MATCH_MODERATE__', '__MATCH_NOT_QUALIFIED__', '__MATCH_55_PERCENT__'], true)
        ));
        $requiredSkills = $publicSkills
            ? implode(', ', $publicSkills)
            : match (true) {
                in_array('__MATCH_ALL__', $skills, true) => 'Open qualifications',
                in_array('__MATCH_MODERATE__', $skills, true) => 'Open qualifications with review',
                in_array('__MATCH_NOT_QUALIFIED__', $skills, true) => 'Open qualifications with not qualified result',
                in_array('__MATCH_55_PERCENT__', $skills, true) => 'Open qualifications with fixed 55 percent match',
                default => $job->required_skills,
            };

        return [
            'id' => $job->id,
            'title' => $job->title,
            'description' => $job->description,
            'status' => $job->status,
            'department' => $job->department,
            'job_position' => $job->job_position,
            'jobPosition' => $job->job_position,
            'item_no' => $job->item_no,
            'itemNo' => $job->item_no,
            'location' => $job->location,
            'type' => $job->type,
            'deadline' => optional($job->deadline)->format('Y-m-d') ?? $job->deadline,
            'eligibility' => $job->eligibility,
            'required_skills' => $requiredSkills,
            'minimum_education' => $job->minimum_education,
            'minimum_experience_years' => (int) $job->minimum_experience_years,
        ];
    }
}
